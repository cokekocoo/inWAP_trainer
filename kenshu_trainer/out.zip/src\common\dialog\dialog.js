angular.module('dialog', [])
  .directive('dialog', function () {

    function link(scope, element, attrs) {

      if (attrs.wide) {
        element.find('.modal-dialog').addClass('modal-lg');
      }

      element.on('hidden.bs.modal', function () {
        scope.dialogShow = false;
        scope.onHide();
        scope.$apply();
      });

      scope.$watch('dialogShow', function (value) {
        if (value) {
          element.modal('show');
        } else {
          element.modal('hide');
        }
      });

    }

    return {
      restrict: 'E',
      replace: true,
      transclude: true,
      scope: {
        dialogShow: '=',
        onHide: '&',
        wide: '&'
      },
      link: link,
      templateUrl: 'dialog/dialog.tpl.html'
    };
  });
angular.module('updater.update.versions', ['ui.router', 'uiTools', 'dialog', 'updater'])
    .config(["$stateProvider", function config($stateProvider) {
        $stateProvider.state('update.versions', {
            url: '/versions',
            controller: 'versionsCtrl',
            templateUrl: 'update/versions/versions.tpl.html',
            data: {}
        });
    }])
    .factory('storageSvc',['$window', function($window){
        if(typeof(Storage) === "undefined"){
            var storageMgr = {};
            return {
                setItem: function (key, value){
                    storageMgr[key] = value;
                },
                getItem: function (key){
                    return storageMgr[key];
                },
                removeItem: function (key) {
                    delete storageMgr[key];
                },
                clear: function(){
                    storageMgr = {};
                }
            };
        }
        return{
            setItem: function (key, value){
                $window.localStorage.setItem(key, value);
            },
            getItem: function (key){
                return $window.localStorage.getItem(key);
            },
            removeItem: function (key) {
                $window.localStorage.removeItem(key);
            },
            clear: function(){
                $window.localStorage.clear();
            }
        };
    }])
    .controller('versionsCtrl', ["$scope", "$http", "$interval", "$state", "ws", "uiTools", "$q", "storageSvc", function ($scope, $http, $interval, $state, ws, uiTools, $q, storageSvc) {
        // progress step count
        if (!$scope.checkEnv()) {
            return;
        }
        $scope.setCurrentStep(1);

        var env = $scope.updateData.env;
        var product = $scope.updateData.product;
        $scope.showUpgradeCiuDialog = false;
        $scope.isDownloable = false;

        $scope.hideUpgradeCiuDialog = function() {
            $scope.showUpgradeCiuDialog = false;
        };
        $scope.hideDialog = function(){
            $scope.showErrorDialog = false;
        };
        var getCiuInfo = function () {
            $http.get('/self_update/ciu/latest').success(function (data) {
                $scope.ciulatest = data;
            });
            $http.get('/self_update/ciu/current').success(function (data) {
                $scope.ciucurrent = data;
            });
        };

        var applyUpdate = function (version) {
            $scope.disableButton = true;
            if (version.includedVersionLst.length <= 1) {
                version.includedVersionLst.push(createVersionObj(version));
            }
            loadCurrentAndAvailableData().then(function () {
                var isAvailable = $scope.available.map(function (obj) {
                        return obj.name;
                    }).indexOf(version.name) >= 0;
                if (version.includedVersionLst.length > 1) {
                    isAvailable = true;
                }
                if (isAvailable) {

                    uiTools.showConfirmDlg({
                        type: 'dialog-primary',
                        title: $scope.dict.pages.update.versions.sel_dlg.header,
                        content: $scope.dict.pages.update.versions.sel_dlg.text
                    }).then(function () {
                        // reset data to default state
                        $scope.version = version;
                        $scope.progressNow = 1;
                        $scope.progress = 'ct.connect';
                        $scope.showProgress = true;
                        // start the prepare process
                        $http.post('/start_update/' + env.id + '/' + product.code + '/' + version.id, version).success(function (data) {
                            if (data === '0') {
                                // success start do nothingbackend
                            }
                            if (data === '1') {
                                $scope.showProgress = false;
                                uiTools.showConfirmDlg({
                                    type: 'dialog-error',
                                    title: $scope.dict.pages.update.versions.no_exe_dlg.header,
                                    contentTitle: $scope.dict.pages.update.versions.no_exe_dlg.title,
                                    contentP: [
                                        $scope.dict.pages.update.versions.no_exe_dlg.p
                                    ]
                                });
                            }
                        });
                        $scope.updateData.version = version;
                        ws.resetProgress();
                    });
                    $scope.disableButton = false;
                } else if (!isAvailable) {
                    uiTools.showGrowl($scope.dict.pages.update.versions.no_update_package, "info", 6000);
                }

            });
        };

        $scope.downloadCiu = function(version){
            console.log("start downloading "+version);

            uiTools.showConfirmDlg({
                type: 'dialog-primary',
                title: $scope.dict.pages.update.versions.dl_dlg.header,
                content: $scope.dict.pages.update.versions.dl_dlg.text
            }).then(function () {
                $scope.showDownload = true;
                console.log(version);
                $http.post('/self_update/download/'+version,{})
                    .success(function (data) {

                        $scope.showDownload = false;
                        if (data) {
                            console.log("Successfully download!");
                            getCiuInfo();
                        } else {
                            uiTools.showConfirmDlg({
                                type: 'dialog-error',
                                title: $scope.dict.pages.update.versions.download_err_dlg.header,
                                contentTitle: $scope.dict.pages.update.versions.download_err_dlg.title,
                                contentP: [
                                    $scope.dict.pages.update.versions.download_err_dlg.p
                                ]
                            });

                        }
                    }).error(function (data, status) {
                    $scope.showDownload = false;
                    alert('fail, ' + ', ' + status);
                    console.log(data);
                });
            });

        };

        function setVersionTitle(versionLst) {
            versionLst.forEach(function (version) {
                if (!version.currentUserAccessible) {
                    version.title = $scope.dict.pages.update.versions.user_not_accessible;
                } else if (version.needUpgradedCiu) {
                    version.title = $scope.dict.pages.update.versions.need_higher_ciu;
                } else {
                    version.title = "";
                }
            });
        }

        var loadCurrentAndAvailableData = function(){
            return $http.get('/version_info/' + env.id + '/' + product.code).success(function (data) {
                $scope.current = data.current;
                $scope.available = data.available;
                setVersionTitle($scope.available);
                console.log(data.available);
                $scope.showDownload = false;
            });
        };

        // load data
        loadCurrentAndAvailableData().then(function(){
            return detectDownloadstatus();
        });

        var getEnvConfig = function(){
            return $http.get('/get_env_config/' + env.id + '/' + product.code).success(function (data) {
                $scope.debugState['NOT_BACKUP'] = data['NOT_BACKUP'];
            });
        };
        // load env config
        getEnvConfig();

        $scope.downloadableVersions = [];
        var loadDownloadableVersions = function () {
            $http.get('/downloadable_resource/' + env.id + '/' + product.code).success(
                function (data) {
                    $scope.downloadableVersions = data.available;
                    if ($scope.downloadableVersions.length > 0) {
                        $scope.isDownloable = true;
                        setVersionTitle($scope.downloadableVersions);
                        var filteredVersion = $scope.downloadableVersions.filter(function (ver) {
                            return ver.name.toLowerCase().indexOf('pre') < 0;
                        });
                        if (filteredVersion.length > 0) {
                            $scope.selectedVersion = filteredVersion[0];
                        }
                    } else {
                        $scope.isDownloable = false;
                        return loadMergableVersions();
                    }
                }
            ).error(
                function (err) {
                    console.log('failed during loading remote resource');
                }
            );
        };

        loadDownloadableVersions();

        var makeCtnDlgDspMsg = function(version){
          var dspMsg = '';
          dspMsg = dspMsg + "<h4>"+$scope.dict.pages.update.versions.continue_dlg.title_dl.replace('{0}', version)+"</h4>";
          dspMsg = dspMsg + "<h5>" + $scope.dict.pages.update.versions.continue_dlg.help1_dl + "</h5>";
          dspMsg = dspMsg + "<h5>" + $scope.dict.pages.update.versions.continue_dlg.help2_dl + "</h5>";
          return dspMsg;
        };

        var makeCtnMergeDspMsg = function(){
            var dspMsg = '';
            dspMsg = dspMsg + "<h4>"+$scope.dict.pages.update.versions.continue_dlg.title_merge + "</h4>";
            dspMsg = dspMsg + "<h5>" + $scope.dict.pages.update.versions.continue_dlg.help1_merge + "</h5>";
            dspMsg = dspMsg + "<h5>" + $scope.dict.pages.update.versions.continue_dlg.help2_merge + "</h5>";
            return dspMsg;
        };

        var delVersionInUpdatePackage = function(version){
            $('#waiting').show();
            return　$http.post('/delete_update_package_version/' + version, {}).success(function (data) {
                    if (data) {
                        resetMultiPtfDLMgr();
                        $('#waiting').hide();
                    } else {
                        resetMultiPtfDLMgr();
                        $('#waiting').hide();
                    }
                }).error(function(){
                    resetMultiPtfDLMgr();
                    $('#waiting').hide();
                });
        };

        var detectDownloadstatus = function(){
            if(!$scope.isDownloable){
                return;
            }
            var currentDownloadVersion = getProperty('currentVersion');
            if(getProperty('status') !== 'ready' && getProperty('status') === 'downloading'){
                var downloadVersionLst = convertVersionLst(getProperty('versionLst'));
                var currentIdx = getProperty('versionLst').indexOf(currentDownloadVersion);
                var leftVersionLst = downloadVersionLst.splice(currentIdx+1, downloadVersionLst.length);
                downloadVersionLst = convertVersionLst(getProperty('versionLst'));
                uiTools.showConfirmDlg({
                    type: 'dialog-primary',
                    title: $scope.dict.pages.update.versions.continue_dlg.header_dl,
                    content: makeCtnDlgDspMsg(currentDownloadVersion)
                }).then(function(){
                    $scope.dspDownloadProgress = makeDspDlProgressMsg(downloadVersionLst, currentDownloadVersion);
                    $scope.download_progress = "Downloading";
                    $scope.downloadStatus = 'Downloading';
                    $scope.showDownload = true;
                    return convertTheRemoteResource(currentDownloadVersion).then(function(){
                        downloadMultiplePtf(leftVersionLst);
                    });
                }, function(){
                    return delVersionInUpdatePackage(currentDownloadVersion);
                });
            }else if(getProperty('status') !== 'ready' && getProperty('status') === 'merging'){
                uiTools.showConfirmDlg({
                    type: 'dialog-primary',
                    title: $scope.dict.pages.update.versions.continue_dlg.header_merge,
                    content: makeCtnMergeDspMsg()
                }).then(function(res) {
                    $scope.downloadStatus = 'Merging';
                    $scope.showDownload = true;
                    $scope.mergeTimeMsg = makeDspMergeTimeMsg(convertVersionLst(getProperty('versionLst')));
                    return mergeMultipleVersions(convertVersionLst(getProperty('versionLst')));
                }, function(){
                    return resetMultiPtfDLMgr();
                });
            }
        };


        function loadMergableVersions() {
            $http.get('/mergeable_resource/' + env.id + '/' + product.code).then(function (res) {
                $scope.mergeableVersions = res.data.mergeable;
                if ($scope.mergeableVersions.length > 0) {
                    setVersionTitle($scope.mergeableVersions);
                    var filteredVersion = $scope.mergeableVersions.filter(function (ver) {
                        return ver.name.toLowerCase().indexOf('pre') < 0;
                    });
                    if (filteredVersion.length > 0) {
                        $scope.selectedVersion = filteredVersion[0];
                    }
                }
            });
        }

        var getToMergeVerLst = function () {
            var toMergeVersions = [];
            if ($scope.selectedVersion === 0) {
                return toMergeVersions;
            }
            $scope.mergeableVersions.forEach(
                function (version) {
                    var versionNumber = version.versionNumber.toString().split('_')[0];
                    var selectedVersionNumber = $scope.selectedVersion.versionNumber.toString().split('_')[0];
                    if (versionNumber / 100 <= selectedVersionNumber / 100) {
                        toMergeVersions.push(version.name);
                    }
                }
            );
            return toMergeVersions;
        };

        var mergeMultipleVersions = function(versionLst){
            return $http.post('/merge_remote_resource', JSON.stringify(versionLst)).then(function (res) {
                if (res.data === true) {
                    resetMultiPtfDLMgr();
                    $scope.showDownload = false;
                    return $q.all([loadMergedVersions(), loadCurrentAndAvailableData()]);
                } else {
                    $scope.showDownload = false;
                    return uiTools.showConfirmDlg({
                        type: 'dialog-error',
                        title: $scope.dict.pages.update.versions.merge_err_dlg.header,
                        contentTitle: $scope.dict.pages.update.versions.merge_err_dlg.title,
                        contentP: [
                            $scope.dict.pages.update.versions.merge_err_dlg.p
                        ]
                    });
                }
            });
        };

        $scope.startMergeVersions = function (versionLst) {
            if (!$scope.selectedVersion) {
                return;
            }
            var mergeVersions = [];
            if(!versionLst){
                mergeVersions = getToMergeVerLst();
            }else{
                mergeVersions = versionLst;
            }
            if (mergeVersions.filter($scope.preVersionFilter).length < 2) {
                return uiTools.showGrowl($scope.dict.pages.update.versions.download_err_msg, "info", 5000);
            }
            uiTools.showConfirmDlg({
                type: 'dialog-primary',
                title: $scope.dict.pages.update.versions.merge_dlg.header,
                text: $scope.dict.pages.update.versions.merge_dlg.text,
                content: makeDspDlgVersions(mergeVersions, false)
            }).then(function () {
                $scope.downloadStatus = 'Merging';
                $scope.showDownload = true;
                $scope.mergeTimeMsg = makeDspMergeTimeMsg(mergeVersions);
                setProperty('status', 'merging');
            }).then(function(){
                return mergeMultipleVersions(mergeVersions);
            });

        };

        $scope.mergedAvailableVersions = [];
        function loadMergedVersions() {
            //is there anything under merged folder
            return $http.get('/available_merged_versions/' + env.id + '/' + product.code, {}).then(function (res) {
                var mergedVersions = angular.fromJson(res).data.available;
                $scope.mergedAvailableVersions = makeDisplayMergedVersion(mergedVersions);

            });
        }

        loadMergedVersions();

        //make display version object
        var makeDisplayMergedVersion = function (versionLst) {
            var displayVersions = [];
            var displayNormalVersions = {}, displayPreVersions = {};
            var preVersions = [], normalVersions = [];
            var langReg = /PRE/i;
            versionLst.forEach(function (ver) {
                if (langReg.test(ver.name)) {
                    preVersions.push(ver);
                } else {
                    normalVersions.push(ver);
                }
            });
            if (normalVersions.length > 0) {
                displayNormalVersions = normalVersions[normalVersions.length - 1];
                displayNormalVersions.includedVersionLst = [];
                normalVersions.forEach(function (ver) {
                    var versionObj = createVersionObj(ver);
                    if(versionObj.cwsRestartNeeded===true){
                        displayNormalVersions['cwsRestartNeeded'] = true;
                    }
                    displayNormalVersions.includedVersionLst.push(versionObj);
                });
                displayVersions.push(displayNormalVersions);
            }
            if (preVersions.length > 0) {
                displayPreVersions = preVersions[preVersions.length - 1];
                displayPreVersions.includedVersionLst = [];
                preVersions.forEach(function (ver) {
                    var versionObj = createVersionObj(ver);
                    if(versionObj.cwsRestartNeeded===true){
                        displayPreVersions['cwsRestartNeeded'] = true;
                    }
                    displayPreVersions.includedVersionLst.push(versionObj);
                });
                displayVersions.push(displayPreVersions);
            }

            return displayVersions;
        };

        var createVersionObj = function (ver) {
            var newVersionObj = {};
            newVersionObj['id'] = ver.id;
            newVersionObj['name'] = ver.name;
            newVersionObj['releaseDate'] = ver.releaseDate;
            newVersionObj['updateDate'] = ver.updateDate;
            newVersionObj['needUpgradedCiu'] = ver.needUpgradedCiu;
            newVersionObj['currentUserAccessible'] = ver.currentUserAccessible;
            newVersionObj['isRemoteResource'] = ver.isRemoteResource;
            newVersionObj['cwsRestartNeeded'] = ver.cwsRestartNeeded;
            newVersionObj['includedVersionLst'] = [];
            return newVersionObj;
        };
        $scope.isShowAllVersions = false;
        $scope.showAllVersions = function(){
            if(!$scope.isShowAllVersions){
                $scope.isShowAllVersions=true;
            }else{
                $scope.isShowAllVersions=false;
            }
        };


        // load history
        $http.get('/last_update/' + env.id + '/' + product.code).success(function (data) {
            $scope.lastUpdate = data;
        });

        var convertTheRemoteResource = function (version) {
            var deferred = $q.defer();
            $scope.download_progress = "Converting";
            var versionName = version.name ? version.name : version;
            $http.post('/convert_remote_resource/' + versionName, {}).success(function (data) {

                if (data) {
                    // loadCurrentAndAvailableData();
                } else {
                    $scope.showDownload = false;
                    uiTools.showConfirmDlg({
                        type: 'dialog-error',
                        title: $scope.dict.pages.update.versions.uvu_err_dlg.header,
                        contentTitle: $scope.dict.pages.update.versions.uvu_err_dlg.title,
                        contentP: [
                            $scope.dict.pages.update.versions.uvu_err_dlg.p
                        ]
                    });

                }
                deferred.resolve();
            }).error(function (data, status) {
                console.log('fail, ' + ', ' + status);
                console.log(data);
                deferred.reject();
            });
            return deferred.promise;
        };

        $scope.preVersionFilter = function isPreVersion(element, index, array){
            var versionName = element.name ? element.name : element;
            return versionName.toLowerCase().indexOf('pre') < 0;
        };

        var makeDspDlgVersions = function(versions, isDownload){
            var displayMsg = isDownload ? $scope.dict.pages.update.versions.dl_dlg.notice : $scope.dict.pages.update.versions.merge_dlg.notice;
            displayMsg = '<b>' + displayMsg.replace('{0}', versions.filter($scope.preVersionFilter).length) +'</b>';
            var versionList = versions.map(function (obj) {
                return obj.name ? obj.name : obj;
            }).filter(function (name) {
                return name.toLowerCase().indexOf('pre') < 0;
            }).map(function(verNm){
                return '<span class="label label-info">'+verNm+'</span>';
            }).join('</br>');
            return displayMsg + '<br/><br/>' + '<div style="overflow-y:auto;">'+versionList+'</div>';
        };

        var makeDspDlProgressMsg = function(versionLst, version) {
            var displayMsg = $scope.dict.pages.update.versions.download_progress_msg;
            var size = versionLst.length;
            var currentIdx = 1;
            var versionName = version.name ? version.name : version;
            versionLst.map(function (ver) {
                return ver.name ? ver.name : ver;
            }).forEach(function (ele, idx) {
                if (versionName === ele) {
                    currentIdx = currentIdx + idx;
                }
            });
            return displayMsg.replace('{0}', currentIdx).replace('{1}', size).replace('{2}', versionName);
        };

        var makeDspMergeTimeMsg = function(versionLst) {           var displayMsg = $scope.dict.pages.update.versions.merge_time_msg;
            var size = versionLst.filter($scope.preVersionFilter).length;

            //it is not 100% accurate, we estimate the merge time of one ptf will be 30s
            var TIME_OF_ONE_PTF = 60;
            var totalTime = TIME_OF_ONE_PTF * size / 60;

            return displayMsg.replace('{0}', Math.ceil(totalTime));
        };

        var convertVersionLst = function(versionLst){
            return versionLst.map(function(ver){
                return ver.name ? ver.name : ver;
            });
        };

        $scope.startMultiDownload = function(){
            if (!$scope.selectedVersion) {
                return;
            }
            var downloadVersions = getDownloadVerLst();
            if (downloadVersions.filter($scope.preVersionFilter).length < 2) {
                return uiTools.showGrowl($scope.dict.pages.update.versions.download_err_msg, "info", 5000);
            }
            downloadVersions = convertVersionLst(downloadVersions);
            var cssStyle = [{key:'max-height',value:'300px'}, {key:'overflow-y',value:'auto'}];
            uiTools.showConfirmDlg({
                type: 'dialog-primary',
                style: cssStyle,
                title: $scope.dict.pages.update.versions.dl_dlg.header,
                content: makeDspDlgVersions(downloadVersions, true)
            }).then(function () {
                return downloadMultiplePtf(downloadVersions);
            });
        };

        var env_product = env.id+'_'+product.code;
        var multiPtfDLMgr = {
            'currentVersion': '',
            'status': 'ready',
            'versionLst':[]
        };

        var setProperty = function(prop, value){
            var obj = JSON.parse(storageSvc.getItem(env_product));
            obj[prop]= value;
            storageSvc.setItem(env_product, JSON.stringify(obj));
        };

        var getProperty = function(prop){
            return JSON.parse(storageSvc.getItem(env_product))[prop];
        };

        var resetMultiPtfDLMgr = function(){
            storageSvc.setItem(env_product, JSON.stringify(multiPtfDLMgr));
        };

        (function(){
            if(!storageSvc.getItem(env_product)){
                storageSvc.setItem(env_product, JSON.stringify(multiPtfDLMgr));
            }
        })();

        var downloadMultiplePtf = function (downloadVersions) {

            if (getProperty('status') === 'ready') {
                setProperty('versionLst', downloadVersions);
            }
            $scope.download_progress = "Downloading";
            $scope.downloadStatus = 'Downloading';
            $scope.showDownload = true;
            setProperty('status', 'downloading');
            var chain = $q.when();
            downloadVersions.forEach(
                function (version) {
                    chain = chain.then(function () {
                        return downloadOneVersion(version);
                    });
                }
            );
            return chain.then(
                function () {
                    var mergeList = getProperty('versionLst').length > 1 ? getProperty('versionLst') : downloadVersions;
                    $scope.downloadStatus = 'Merging';
                    $scope.mergeTimeMsg = makeDspMergeTimeMsg(mergeList);
                    setProperty('status', 'merging');
                    return mergeMultipleVersions(mergeList);
                }
            );

        };

        var getDownloadVerLst = function () {
            var downloadVerLst = [];
            if ($scope.selectedVersion === 0) {
                return downloadVerLst;
            }
            $scope.downloadableVersions.forEach(
                function (version) {
                    var versionNumber = version.versionNumber.toString().split('_')[0];
                    var selectedVersionNumber = $scope.selectedVersion.versionNumber.toString().split('_')[0];
                    if (versionNumber / 100 <= selectedVersionNumber / 100) {
                        downloadVerLst.push(version);
                    }
                }
            );
            return downloadVerLst;
        };

        var downloadOneVersion = function (version) {
            var deferred = $q.defer();
            setProperty('currentVersion', version);
            $scope.dspDownloadProgress = makeDspDlProgressMsg(getProperty('versionLst'), version);
            $http.post('/download_remote_resource/' + env.id + '/' + version, {}).then(
                function (obj) {
                    if (obj.data) {
                        console.log(version);
                        return convertTheRemoteResource(version).then(function () {
                            return $q.defer().resolve();
                        });
                    } else {
                        $scope.showDownload = false;
                        return uiTools.showConfirmDlg({
                            type: 'dialog-error',
                            title: $scope.dict.pages.update.versions.download_err_dlg.header,
                            contentTitle: $scope.dict.pages.update.versions.download_err_dlg.title,
                            contentP: [
                                $scope.dict.pages.update.versions.download_err_dlg.p
                            ]
                        }).then(
                            function () {
                                return $q.defer().reject();
                            }
                        );
                    }
                }
            ).then(
                function () {
                    deferred.resolve();
                },
                function () {
                    deferred.reject();
                }
            );
            return deferred.promise;
        };

        $scope.downloadBtnClick = function (version) {

            uiTools.showConfirmDlg({
                type: 'dialog-primary',
                title: $scope.dict.pages.update.versions.dl_dlg.header,
                content: $scope.dict.pages.update.versions.dl_dlg.text
            }).then(function () {
                $scope.download_progress = "Downloading";
                $scope.showDownload = true;
                $scope.downloadStatus = 'Downloading';
                console.log(version);
                $http.post('/download_remote_resource/' + env.id + '/' + version.name, {}).success(function (data) {

                    if (data) {
                        return convertTheRemoteResource(version).then(function () {
                            return loadCurrentAndAvailableData();
                        });
                    } else {
                        $scope.showDownload = false;
                        uiTools.showConfirmDlg({
                            type: 'dialog-error',
                            title: $scope.dict.pages.update.versions.download_err_dlg.header,
                            contentTitle: $scope.dict.pages.update.versions.download_err_dlg.title,
                            contentP: [
                                $scope.dict.pages.update.versions.download_err_dlg.p
                            ]
                        });

                    }
                }).error(function (data, status) {
                    console.log('fail, ' + ', ' + status);
                    console.log(data);
                });
            });
        };

        $scope.openDoc = function (version) {
            loadCurrentAndAvailableData().then(function () {

                var isAvailable = $scope.available.map(function (obj) {
                        return obj.name;
                    }).indexOf(version.name) >= 0;

                if (isAvailable) {
                    window.open('version_docs/' + version.name + '/contents.html', '_blank');
                } else if (!isAvailable) {
                    uiTools.showGrowl($scope.dict.pages.update.versions.no_update_package, "info", 6000);
                }

            });
        };

        $scope.openMan = function (version) {
            loadCurrentAndAvailableData().then(function () {

                var isAvailable = $scope.available.map(function (obj) {
                        return obj.name;
                    }).indexOf(version.name) >= 0;

                if (isAvailable) {
                    window.open('version_docs/' + version.name + '/' + version.name + '.zip', '_blank');
                } else if (!isAvailable) {
                    uiTools.showGrowl($scope.dict.pages.update.versions.no_update_package, "info", 6000);
                }

            });
        };

        $scope.openMergedDoc = function (version) {
            window.open('version_docs/' + version.name + '/contents.html', '_blank');
        };

        $scope.openMergedMan = function (version) {
            window.open('version_docs/' + version.name + '/' + version.name + '.zip', '_blank');
        };

        // go next and show prepare process
        var success = false;
        var connectErrors= {};
        var connLastErrorTime = 0;

        $scope.startBtnClick = function (version) {
            var isMultiple = version.includedVersionLst.length > 1;
            var isNeedUpgradedCiu = isMultiple ? version.includedVersionLst[0].needUpgradedCiu : version.needUpgradedCiu;
            if (isNeedUpgradedCiu) {
                uiTools.showConfirmDlg({
                    type: 'dialog-warning',
                    title: $scope.dict.pages.update.versions.need_higher_ciu,
                    content: $scope.dict.pages.update.versions.need_higher_ciu_content
                }).then(function () {
                    $scope.showUpgradeCiuDialog = true;
                    getCiuInfo();
                });
            } else {
                if (version.cwsRestartNeeded && version.productCode === 'CJK') {
                    uiTools.showConfirmDlg({
                        type: 'dialog-warning',
                        title: $scope.dict.pages.update.versions.need_restart_cws,
                        content: $scope.dict.pages.update.versions.need_restart_cws_content
                    }).then(function () {
                        applyUpdate(version);
                    });
                } else {
                    applyUpdate(version);
                }
            }
        };

        $scope.goToPlanPageIfSuccess = function () {
            if (success) {
                $state.go('update.plan');
            }
        };

        $scope.updateDebugState = function () {
            $http.post('/debugState', $scope.debugState).success(function (data, status, headers, config) {
                console.log(data);
            });
        };

        ws.reset()
            .setStateListener(function (data) {
                $scope.progressNow = prepareSteps[data.state];
                $scope.progress = data.state;
                if (data.state === 'ct.show_plan') {
                    success = true;
                    $scope.showProgress = false;
                }
                $scope.$apply();
            })
            .setErrorListener(function (error) {

                var errorContent;
                if (error.details) {
                    errorContent = [];
                    error.details.forEach(function (message) {
                        var messageParts = message.split(":");
                        debugger;
                        if (messageParts.length > 2) {
                            // if it is error message of database schema
                            if (messageParts[2].trim().indexOf("S_.") === 0 && messageParts[1].trim().match("._DB$")) {
                                errorContent.push(messageParts[0] + ":" + $scope.serverTypeDict(messageParts[1].trim()) + ":" + $scope.dict.pages.config.environments.one.server.schemas[messageParts[2].trim()]);
                            } else if ($scope.dict.pages.config.environments.one.server[messageParts[2].trim()]) {
                                // error message for common server type
                                errorContent.push(messageParts[0] + ":" + $scope.serverTypeDict(messageParts[1].trim()) + ":" + $scope.dict.pages.config.environments.one.server.HOME.help[messageParts[1].trim()]);
                            } else if (messageParts[2].trim() === "SRLT_EXECUTER" || messageParts[2].trim() === "TDI_EXE") {
                                // error message for SRLT_EXECUTOR
                                errorContent.push(messageParts[0] + ":" + $scope.serverTypeDict(messageParts[1].trim()) + ":" + $scope.dict.pages.config.environments.one.server.HOME.titles[messageParts[2].trim()]);
                            } else if ($scope.dict.serverType[messageParts[1].trim().split("_")[1]]) {
                                errorContent.push(messageParts[0] + ":" + $scope.serverTypeDict(messageParts[1].trim()) + ":" + messageParts[2].trim());
                            } else {
                                // special error message  e.g error stacktrace
                                errorContent.push(message);
                            }
                        } else {
                            if (messageParts[1].trim() !== "null" && $scope.dict.pages.config.environments.one.basic["CJKDB,9998"] !== undefined) {
                                // basic error message   e.g.   host,  port
                                errorContent.push(messageParts[0] + ":" + $scope.dict.pages.config.environments.one.basic[messageParts[1].trim()]);
                            } else {
                                // special error message
                                errorContent.push(message);
                            }
                        }

                    });
                } else {
                    errorContent = [error.message];
                }

                uiTools.showConfirmDlg({
                    type: 'dialog-error',
                    title: $scope.dict.pages.update.versions.err_dlg.header,
                    contentTitle: $scope.dict.pages.update.versions.err_dlg.title,
                    contentP: [$scope.dict.pages.update.versions.err_dlg.p],
                    contentE: errorContent,
                    hideCancel: true
                }).then(function(){
                    $scope.showProgress = false;

                    $http.post('/reset', {});
                    $scope.$apply();
                });


            })
            .setConnectListener(function (error) {
                connLastErrorTime = (new Date()).getTime();
                if (!(error.message in connectErrors)) {
                    connectErrors[error.message] = true;
                    uiTools.showConfirmDlg({
                        type: 'dialog-error',
                        title: $scope.dict.pages.update.versions.err_dlg.header,
                        contentTitle: $scope.dict.pages.update.versions.err_dlg.title,
                        contentP: [$scope.dict.pages.update.versions.err_dlg.p],
                        contentE: [error.message],
                        hideCancel: true
                    }).then(function () {
                        delete connectErrors[error.message];
                        if (Object.keys(connectErrors).length === 0 && !success) {
                            $http.post('/reset', {});
                            $scope.showProgress = false;
                            $scope.$apply();
                        }
                    });
                }
                $scope.waitForRetry = true;
                $scope.$apply();
                setTimeout(function () {
                    if ((new Date()).getTime() - connLastErrorTime > 5000) {
                        $scope.waitForRetry = false;
                        $scope.$apply();
                    }
                }, 5100);

            });

        var prepareSteps = {
            'ct.connect': 1,
            'ct.check_configuration': 2,
            'ct.check_in_advance': 3,
            'ct.transfer_update_package': 4,
            'ct.fast_release_check': 5,
            'ct.manual': 6,
            'ct.collect': 7,
            'ct.show_plan': 8
        };


        $scope.selfUpdate = function (version) {
            $scope.showSelfUpd = true;
            $http.post('/self_update/executor/' + version, {}).success(function (data) {
                console.log("self update executor");
                console.log(data);

                if (data.result) {
                    $scope.showSelfUpd = false;
                    uiTools.showConfirmDlg({
                        type: 'dialog-primary',
                        title: $scope.dict.common.restart,
                        contentTitle: $scope.dict.pages.config.self_update.waitRestart,
                        hideCancel: true
                    });

                    $http.post('/self_update/controller/' + version, {}).success(function (data) {
                        console.log("self update executor");
                        console.log(data);

                        if (data.result) {
                            ws.stop();
                            $interval(function () {
                                $http({
                                    url: 'https://' + location.hostname + ':' + (location.port - 443) + '/updater_version',
                                    method: 'GET',
                                    headers: {
                                        'Access-Control-Allow-Origin': '*',
                                        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                                        'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With'
                                    }
                                }).success(function (data, status)
                                {
                                    console.log('success, ' + ', ' + status);
                                    if (status === 200) {
                                        console.log('finish');
                                        location.replace('https://' + location.hostname + ':' + (location.port - 443) + '/login');
                                    }
                                });
                                $http.get('/updater_version').success(function (data, status) {
                                    console.log('success, ' + ', ' + status);
                                    if (status === 200 && isNaN(parseInt(data, 10))) {
                                        console.log('finish');
                                        location.replace(location.pathname + 'logout');
                                        location.reload(true);
                                    }
                                }).error(function (data, status) {
                                    console.log('fail, ' + ', ' + status);
                                });
                            }, 2000);
                        } else {
                            $scope.showSelfUpd = false;
                            $scope.selfUpdateErrorList = data.msg;
                            $scope.showErrorDialog = true;
                        }

                    }).error(function(data, status){
                        ws.stop();
                        $interval(function () {
                            $http({
                                url: 'https://' + location.hostname + ':' + (location.port - 443) + '/updater_version',
                                method: 'GET',
                                headers: {
                                    'Access-Control-Allow-Origin': '*',
                                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                                    'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With'
                                }
                            }).success(function (data, status)
                            {
                                console.log('success, ' + ', ' + status);
                                if (status === 200) {
                                    console.log('finish');
                                    location.replace('https://' + location.hostname + ':' + (location.port - 443) + '/login');
                                }
                            });
                            $http.get('/updater_version').success(function (data, status) {
                                console.log('success, ' + ', ' + status);
                                if (status === 200 && isNaN(parseInt(data, 10))) {
                                    console.log('finish');
                                    location.replace(location.pathname + 'logout');
                                    location.reload(true);
                                }
                            }).error(function (data, status) {
                                console.log('fail, ' + ', ' + status);
                            });
                        }, 2000);
                    });
                } else {
                    var regex = /([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\:?([0-9]{1,5})?;?/g;
                    if(data.msg.length >0 && data.msg[0].match(regex)){
                        for(var i = 0; i < data.msg.length; i++){
                            data.msg[i] = $scope.dict.pages.config.environments.one.network.CONNECTION_FAIL + '\r\n' +
                                $scope.dict.pages.config.self_update.errors.connect_error_prefix + data.msg[i];
                        }
                    }
                    $scope.showSelfUpd = false;
                    $scope.selfUpdateErrorList = data.msg;
                    $scope.showErrorDialog = true;
                }
            });
        };

    }]);

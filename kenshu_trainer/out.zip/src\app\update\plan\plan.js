angular.module('updater.update.plan', ['ui.router'])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('update.plan', {
      url: '/plan',
      controller: 'planCtrl',
      templateUrl: 'update/plan/plan.tpl.html',
      data: {}
    });
  }])
  .controller('planCtrl', ["$scope", "$http", "$state", "ws", "uiTools", function ($scope, $http, $state, ws, uiTools) {

    if (!$scope.checkEnv()) {
      return;
    }

    var connectErrors = {};
    var connLastErrorTime = 0;
    ws.reset()
        .setConnectListener(function (error) {
            connLastErrorTime = (new Date()).getTime();
            if (!(error.message in connectErrors)) {
                connectErrors[error.message] = true;
                uiTools.showConfirmDlg({
                    type: 'dialog-error',
                    title: $scope.dict.pages.update.versions.err_dlg.header,
                    contentTitle: $scope.dict.pages.update.versions.err_dlg.p,
                    contentE: [error.message],
                    hideCancel: true
                }).then(function () {
                    delete connectErrors[error.message];
                });
            }
            $scope.waitForRetry = true;
            $scope.$apply();
            setTimeout(function () {
                if ((new Date()).getTime() - connLastErrorTime > 5000) {
                    $scope.waitForRetry = false;
                    $scope.$apply();
                }
            }, 5100);
        });

    $scope.setCurrentStep(2);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    // load apply plan
    $scope.executorPlans = [];
    $http.get('/plan_info/' + env.id + '/' + product.code + '/' + version.id).success(function (executorPlans) {
      $scope.executorPlans = executorPlans;
    });

    $scope.nextBtnClick = function () {
      $http.post('/next/success/ct.show_plan', {}).success(function () {
        $state.go('update.manual');
      });
    };

  }])
  .filter('configForDisplay', ["$rootScope", function ($rootScope) {
    return function (input) {
      var output = {};
      for(var i in input) {
        if(input.hasOwnProperty(i)) {
          output[i] = input[i];
          if (i === 'STANDBY') {
            output[i] = $rootScope.dict.pages.config.environments.one.server.STANDBY.options[input[i] || 0];
          }

          if (i === 'CONTROL_TYPE') {
            output[i] = $rootScope.dict.pages.config.environments.one.server.CONTROL_TYPE.options[input[i] || 0];
          }
        }
      }
      return output;
    };
  }]);
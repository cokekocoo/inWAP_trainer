angular.module('updater.update.postUpdateCollect.list', [
  'ui.router',
  'loading'
])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateCollect.list', {
      url: '/postUpdateCollectList',
      controller: 'postUpdateCollectListCtrl',
      templateUrl: 'update/postUpdateCollect/list/listCollect.tpl.html',
      data: {}
    });
  }])
  .controller('postUpdateCollectListCtrl', ["$scope", "$http", "$state", "ws", function ($scope, $http, $state, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(4);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    var types = {
      'collect': 'oneCollect'
    };

    // load data
    $http.get('/post_update_collect/' + env.id + '/' + product.code + '/' + version.id).success(function (data) {
      $scope.tasks = data;
      if (data.collect.length === 0) {
        $scope.nextBtnClick();
      }
    });

    // task select logic
    $scope.oneTaskClick = function (type, task) {
      $state.go('update.postUpdateCollect.one', {key: task.taskKey});
    };

    // next logic
    $scope.canNext = function () {
      return true;
    };

    $scope.nextBtnClick = function () {
      $http.post('/next/success/ct.post-update-collect.wait', {}).success(function () {
        $state.go('update.progress');
      });
    };

    $scope.progressRptBtnClick = function () {
      $state.go('update.report', {status: 'postUpdateCollect'});
    };
  }]);
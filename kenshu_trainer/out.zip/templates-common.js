angular.module('templates-common', ['dialog/dialog.tpl.html', 'dictSpan/dictSpan.tpl.html', 'helpText/helpText.tpl.html', 'loading/loading.tpl.html', 'progressBar/progress_bar.tpl.html', 'progressTrack/progress_track.tpl.html', 'textFileReader/fileSelector.tpl.html', 'textFileReader/textFileReader.tpl.html']);

angular.module("dialog/dialog.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("dialog/dialog.tpl.html",
    "<div class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\"\n" +
    "     data-backdrop=\"static\" data-keyboard=\"false\">\n" +
    "    <div class=\"modal-dialog\">\n" +
    "        <div class=\"modal-content\" ng-transclude>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("dictSpan/dictSpan.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("dictSpan/dictSpan.tpl.html",
    "<span>{{_.template(template, templateData)}}</span>");
}]);

angular.module("helpText/helpText.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("helpText/helpText.tpl.html",
    "<p class=\"help-block\">{{ dictKey }}</p>");
}]);

angular.module("loading/loading.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("loading/loading.tpl.html",
    "<div class=\"followingBallsGDiv\">\n" +
    "    <div class=\"followingBallsG followingBallsG_1\">\n" +
    "    </div>\n" +
    "    <div class=\"followingBallsG followingBallsG_2\">\n" +
    "    </div>\n" +
    "    <div class=\"followingBallsG followingBallsG_3\">\n" +
    "    </div>\n" +
    "    <div class=\"followingBallsG followingBallsG_4\">\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("progressBar/progress_bar.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("progressBar/progress_bar.tpl.html",
    "<div class=\"progress progress-striped active\">\n" +
    "    <div class=\"progress-bar\" role=\"progressbar\" style=\"width: 50%\">\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("progressTrack/progress_track.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("progressTrack/progress_track.tpl.html",
    "<ol class=\"track-progress\" data-steps=\"{{steps.length}}\">\n" +
    "	<li ng-repeat=\"s in steps\">\n" +
    "		<span>{{ s }}</span>\n" +
    "		<i></i>\n" +
    "	</li>\n" +
    "</ol>");
}]);

angular.module("textFileReader/fileSelector.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("textFileReader/fileSelector.tpl.html",
    "<div>\n" +
    "    <div class=\"show-part\">\n" +
    "        <span ng-transclude></span>\n" +
    "    </div>\n" +
    "    <div style=\"display: none\">\n" +
    "        <input class=\"file-selector-input\" type=\"file\" ng-file-select=\"onFileSelect($files)\"/>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("textFileReader/textFileReader.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("textFileReader/textFileReader.tpl.html",
    "<div>\n" +
    "    <div class=\"show-part\">\n" +
    "        <span ng-transclude></span>\n" +
    "    </div>\n" +
    "    <div style=\"display: none\">\n" +
    "        <input class=\"file-selector-input\" type=\"file\" ng-file-select=\"onFileSelect($files)\"/>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module('uiTools', [])
  .factory('uiTools', ["$q", "$rootScope", function ($q, $rootScope) {

    var showGrowl = function (msg, type, delay, position) {
      if (!type) {
        type = "info";
      }
      if (!delay) {
        delay = 1200;
      }
      if (!position) {
        position = {
          from: "top",
          align: "center"
        };
      }
      $.growl({
        message: msg
      }, {
        type: type,
        fade_in: 500,
        delay: delay,
        allow_dismiss: false,
        position: position,
        z_index: 999999
      });
    };

    var showConfirmDlg = function (data, input) {
      var deferred = $q.defer();
      var i;
      var dlg = $('<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="false">' +
        '<div class="modal-dialog">' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<h4 class="modal-title">Modal title</h4>' +
        '</div>' +
        '<div class="modal-body">' +
        '</div>' +
        '<div class="modal-footer">' +
        '<button type="button" class="btn btn-default btn-close">' + $rootScope.dict.common.cancel + '</button>' +
        '<button type="button" class="btn btn-primary btn-ok">' + $rootScope.dict.common.ok + '</button>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>');

      dlg.on('hidden.bs.modal', function () {
        dlg.remove();
      });

      // handle basic dialog style
      if (data.type) {
        dlg.addClass('dialog-color').addClass(data.type);
      }
      //handle basic css style
      if (data.style) {
          data.style.forEach(function(ele){
              dlg.find('.modal-body').css(ele.key, ele.value);
          });
      }

      dlg.find('.modal-title').html(data.title);

      // file contant
      if (data.content) {
        dlg.find('.modal-body').html(data.content);
      } else {
        if (data.contentTitle) {
          dlg.find('.modal-body').append($('<h3>' + data.contentTitle + '</h3>'));
        }
        if (data.contentP) {
          for (i = 0; i < data.contentP.length; i++) {
            dlg.find('.modal-body').append($('<p>' + data.contentP[i] + '</p>'));
          }
        }
        if (data.contentE) {
          for (i = 0; i < data.contentE.length; i++) {
            dlg.find('.modal-body').append($('<pre>' + data.contentE[i] + '</pre>'));
          }
        }
        if (data.form) {
          for (i = 0; i < data.form.length; i++) {
            dlg.find('.modal-body').append(
              $('<div class="form-group">' +
              '<label for="' + data.form[i][0] + '">' + data.form[i][1] + '</label>' +
              '<input type="' + data.form[i][2] +'" class="form-control" id="' + data.form[i][0] +
              '" ng-model="' + data.form[i][0] +
              '" placeholder="' + 'Please input ' + data.form[i][1] + '">' +
              '</div>'
            ));
          }
        }
      }

      // handle the input
      var textarea = null;
      if (input) {
        textarea = $('<textarea class="form-control" rows="6"></textarea>');
        dlg.find('.modal-body').append(textarea);
      }

      // handle button caption
      if (data.okCap) {
        dlg.find('button.btn-ok').text(data.okCap);
      }
      if (data.cancelCap) {
        dlg.find('button.btn-close').text(data.cancelCap);
      }
      if (data.hideCancel) {
        dlg.find('button.btn-close').hide();
      }

      // handle button event
      dlg.find('button.btn-ok').on('click', function () {
        dlg.modal('hide');
        if (input) {
          deferred.resolve(textarea.val());
        } else if (data.form) {
          var res = {};
          for (i = 0; i < data.form.length; i++) {
            res[data.form[i][0]] = dlg.find('#' + data.form[i][0]).val();
          }
          deferred.resolve(res);
        } else {
          deferred.resolve();
        }
      });
      dlg.find('button.btn-close').on('click', function () {
        dlg.modal('hide');
        deferred.reject();
      });

      // show dialog
      $('body').append(dlg);
      dlg.modal('show');
      return deferred.promise;
    };

    return {
      'showGrowl': showGrowl,
      'showConfirmDlg': showConfirmDlg
    };
  }]);
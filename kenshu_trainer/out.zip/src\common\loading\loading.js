angular.module('loading', [])
  .directive('loading', function () {

    return {
      restrict: 'E',
      replace: true,
      templateUrl: 'loading/loading.tpl.html'
    };
  });
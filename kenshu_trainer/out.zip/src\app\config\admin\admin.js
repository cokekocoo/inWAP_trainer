angular.module('updater.config.admin', ['ui.router', 'uiTools'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('config.admin', {
      url: '/admin/:userId',
      controller: 'configAdminCtrl',
      templateUrl: 'config/admin/admin.tpl.html',
      data: {}
    });
  }])
  .controller('configAdminCtrl', ["$scope", "$http", "$state", "$stateParams", "uiTools", function ($scope, $http, $state, $stateParams, uiTools) {
    $scope.configUser = null;
    $scope.loadUser = function () {
      return $http.get('users/' + $stateParams.userId ).success(function (user) {
        $scope.configUser = user;
      });
    };
    $scope.loadUser();

    $scope.valid = {
      oldPassword: true,
      newPassword: true,
      confirmedPassword: true,

      fastValid: function () {
        if ($scope.user.newPassword !== $scope.user.confirmedPassword) {
          this.confirmedPassword = false;
          return false;
        }
        return true;
      }
    };

    $scope.changePassword = function () {
      if ($scope.valid.fastValid()) {
        // currently do not crypted
        $http.put('/users/' + $scope.configUser.id +'/password', $scope.configUser).success(function (result) {
          if (result.oldPassword) {
            uiTools.showConfirmDlg({
              type: 'dialog-primary',
              title: $scope.dict.common.success,
              contentTitle: $scope.dict.pages.config.admin.change_pass_success
            }).then(function () {
              $scope.loadUser();
            });
          } else {
            $scope.valid.oldPassword = false;
            uiTools.showConfirmDlg({
              type: 'dialog-warning',
              title: $scope.dict.common.fail,
              contentTitle: $scope.dict.pages.config.admin.change_pass_fail
            }).then(function () {

            });
          }
        });
      } else {
        $scope.valid.oldPassword = false;
        uiTools.showConfirmDlg({
          type: 'dialog-warning',
          title: $scope.dict.common.fail,
          contentTitle: $scope.dict.pages.config.admin.pass_not_match
        }).then(function () {

        });
      }
    };
  }]);
angular.module('updater', [
  'templates-app',
  'templates-common',
  'updater.update',
  'updater.config',
  'ui.router'
])
  .constant('_', window._)
  .config(["$stateProvider", "$urlRouterProvider", "$httpProvider", function ($stateProvider, $urlRouterProvider, $httpProvider) {
    $stateProvider.state('app', {
      controller: 'AppCtrl',
      templateUrl: 'app.tpl.html',
      data: {}
    });

    $urlRouterProvider.otherwise('/');

    $httpProvider.interceptors.push(function () {
      return {
        'response': function (response) {
          if (response.headers('need_login') === 'true') {
            location.replace(location.pathname + 'logout');
            location.reload(true);
          }
          return response;
        }
      };
    });
  }])

  .run(["$rootScope", "$http", "$state", "_", function ($rootScope, $http, $state, _) {

    // TODO MC state mark
    $rootScope.hide_self_up = false;

    $http.get('/debugState').success(function(data, status, headers, config) {
      $rootScope.debugState = data;
    });

    $rootScope.clearTestState = function () {
      $rootScope.test = false;
    };

    $rootScope._ = _;

    // basic data
    $rootScope.updateData = {};
    $rootScope.configData = {};

    // user info
    $rootScope.user = null;
    $rootScope.userPromise = $http.get('users/login').success(function (user) {
      $rootScope.user = user;
      $rootScope.goUserDefaultState(user);
    });

    $rootScope.goUserDefaultState = function (user) {
      if (user.type === 1) {
        $state.go('config.env.list');
      } else {
        $state.go('update.environments');
      }
    };

    // dictionary related function
    $rootScope.loadDict = function (lang) {
      $http({
        method: 'GET',
        url: '/assets/json/dict.' + lang + '.json'
      }).success(function (data) {
        console.log('load dict: ' + lang);
        $rootScope.dict = data;
      });
    };

    $http.get('/display_language').then(function (response) {
      $rootScope.selectedLanguage = response.data.value;
      $rootScope.loadDict(response.data.value);
    }, function() {
      console.error("Failed to get configured display language, using default English");
      $rootScope.loadDict('en');
    });

    $rootScope.serverTypeDict = function (serverType) {
      if (!serverType) {
        return null;
      }

      // handle the special case of CWS_DL and SRW_DL shown together in the configuration list of update plan, in CSR update
      if (serverType === "SRW_DL") {
        return 'SRW ' + $rootScope.dict.serverType["DL"];
      }
      // SRLT_CL should be shown as it is
      if (serverType === "SRLT_CL") {
        return "SRLT " + $rootScope.dict.serverType["CL"];
      }

      // CSR_TDIMP should be shown as it is
      if (serverType === "CSR_TDIMP") {
        return "CSR " + $rootScope.dict.serverType["TDIMP"];
      }

      var p = serverType.indexOf('_');
      return $rootScope.dict.product[serverType.substring(0, p)] + ' ' + $rootScope.dict.serverType[serverType.substring(p + 1)];
        };
  }])

  .controller('AppCtrl', ["$scope", "$http", function ($scope, $http) {

    // load version
    $http.get('/updater_version').success(function (data) {
      $scope.updaterVersion = data;
    });


    $scope.loadNewDict = function() {
      $http.post('/display_language/' + $scope.selectedLanguage).success(function () {
        $scope.loadDict($scope.selectedLanguage);
      });
    };

    //$http.post('/self_update/open').success(function (data) {
    //  $scope.self_update_open = data;
    //});



    }]);
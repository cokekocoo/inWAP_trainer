angular.module('updater.update.postUpdateManual', [
  'updater.update.postUpdateManual.list',
  'updater.update.postUpdateManual.one',
  'ui.router',
  'loading'
])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateManual', {
      url: '/postUpdateManual',
      controller: 'postUpdateManualCtrl',
      templateUrl: 'update/postUpdateManual/postUpdateManual.tpl.html',
      data: {}
    });
  }])
  .controller('postUpdateManualCtrl', ["$scope", "$http", "$state", function ($scope, $http, $state) {
    $state.go('update.postUpdateManual.list');
  }]);
angular.module('updater.config', [
  'updater.config.env',
  'updater.config.user',
  'updater.config.admin',
  'updater.update.socket',
  'unique',
  'dirty',
  'uiTools'
])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('config', {
        parent: 'app',
        url: '/config',
        controller: 'configCtrl',
        templateUrl: 'config/config.tpl.html',
        data: {}
    });
  }])
  .controller('configCtrl', ["$scope", "$state", "uiTools", "ws", function($scope, $state, uiTools, ws) {

      $scope.loginCount = 0;

      ws.connect();
      ws.setAdminLoginListener(function(data) {
        $scope.loginCount ++;
        if ($scope.loginCount > 0 && $scope.user.type === 1) {
            uiTools.showConfirmDlg({
              type: 'dialog-warning',
              title: $scope.dict.pages.config.environments.list.admin_expire_title,
              contentTitle: $scope.dict.pages.config.environments.list.admin_expire,
              hideCancel: true
            }).then(function() {
                console.log(location.pathname + 'login');
                location.replace(location.pathname + 'login');
                location.reload(true);
            });

            console.log("Admin user has logged on in another place");
        }

      });

    $scope.gotoAdminConfig = function() {
      $state.go('config.admin', {'userId' : $scope.user.id});
    };

    $scope.onDirty = function () {
      return uiTools.showConfirmDlg({
        type: 'dialog-warning',
        title: $scope.dict.pages.config.environments.list.change_unsaved_title,
        contentTitle: $scope.dict.pages.config.environments.list.change_unsaved
      });
    };

  }]);
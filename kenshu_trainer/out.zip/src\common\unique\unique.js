angular.module('unique', []).
  directive('unique', function () {
    return {
      restrict: 'A',
      require: 'ngModel',
      scope : {
        unique : '=',
        model : '=',
        uniqueField : '@'
      },
      link: function(scope, elm, attrs, ctrl) {

        ctrl.$validators.unique = function(modelValue, viewValue) {
          var value = viewValue || modelValue;
          var selfIndex = scope.unique.indexOf(scope.model);
          return scope.unique.filter(function(e, idx) {
            return idx != selfIndex;
          }).filter(function(e) {
            return e[scope.uniqueField] === value;
          }).length < 1;
        };
      }
    };
  });
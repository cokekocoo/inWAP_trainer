angular.module('updater.update.manual.oneManual', ['ui.router', 'ngSanitize'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.manual.oneManual', {
      url: '/one_manual/:key',
      controller: 'oneManualCtrl',
      templateUrl: 'update/manualPart/oneManual/one_manual.tpl.html',
      data: {}
    });
  }])
  .controller('oneManualCtrl', ["$scope", "$http", "$state", "$stateParams", "ws", function ($scope, $http, $state, $stateParams, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(3);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;
    var key = $stateParams.key;

    // load data
    var loadTask = function () {
      $http.get('/manual_part/' + env.id + '/' + product.code + '/' + version.id + '/manual/' + key).success(function (data) {
        $scope.task = data;
      });
    };
    loadTask();

    // button logic
    $scope.cancelBtnClick = function () {
      $state.go('update.manual.list');
    };

    $scope.testBtnClick = function () {
      $http.post('/manual_part/' + env.id + '/' + product.code + '/' + version.id + '/manual/' + key, {}).success(function () {
        loadTask();
      });
    };
  }]);
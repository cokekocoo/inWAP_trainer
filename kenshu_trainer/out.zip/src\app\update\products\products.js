angular.module('updater.update.products', ['ui.router', 'uiTools', 'dialog', 'progressBar', 'dictSpan'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.products', {
      url: '/products',
      controller: 'productsCtrl',
      templateUrl: 'update/products/products.tpl.html',
      data: {}
    });
  }])
  .controller('productsCtrl', ["$scope", "$http", "$state", "uiTools", "ws", function ($scope, $http, $state, uiTools, ws) {
    if (!$scope.checkEnv()) {
      return;
    }
    $scope.refreshEnv();
    ws.reset();
    $scope.setCurrentStep(0);
    $scope.refreshUpdaterWork();

    $scope.selectProdBtnClick = function (product) {
      $scope.updateData.product = product;
      $state.go('update.versions');
    };

    $scope.continueBtnClick = function () {
      $http.post("/operator", {}).success(function () {
        if ($scope.updaterWork.phase === 0) {
          $state.go('update.plan');
        } else if ($scope.updaterWork.phase === 1) {
          $state.go('update.manual');
        } else if ($scope.updaterWork.phase > 1 && $scope.updaterWork.phase < 6) {
          $state.go('update.progress');
        } else if ($scope.updaterWork.phase === 6 && $scope.updaterWork.state === 'ct.post-update-collect.wait') {
          $state.go('update.postUpdateCollect');
        } else if ($scope.updaterWork.phase === 6 && $scope.updaterWork.state === 'ct.post-update-manual.wait') {
          $state.go('update.postUpdateManual');
        } else if ($scope.updaterWork.phase === 6) {
          $state.go('update.progress');
        } else if ($scope.updaterWork.phase === 7) {
          $state.go('update.report', {status: 'finish'});
        }
      });
    };
  }]);
angular.module('updater.config.user', ['ui.router', 'uiTools', 'angularFileUpload'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('config.user', {
      url: '/user',
      controller: 'configUserCtrl',
      templateUrl: 'config/user/user.tpl.html',
      data: {}
    });
  }])
  .controller('configUserCtrl', ["$scope", "$http", "$state", "$upload", "$q", "uiTools", function ($scope, $http, $state, $upload, $q, uiTools) {
    $scope.loadTempUsers = function () {
      return $http.get('/admin/tempUsers').success(function (users) {
        $scope.tUsers = users;
      });
    };
    $scope.loadTempUsers();

    $scope.accessMap = {};

    $scope.loadPermanentUsers = function (indexOfPu, newUserData) {
      return $http.get('/admin/permanentUsers').success(function (users) {
        $scope.pUsers = users;

        $scope._.forEach($scope.pUsers, function (user) {
          $scope.accessMap[user.id] = {};
          $scope._.forEach(user.accessDto.accessPos, function (access) {
            $scope.accessMap[user.id][access.environment.environmentId] = true;
          });
        });

        $scope.loadCompanies();
      });
    };
    $scope.loadPermanentUsers();

    $scope.loadGivenPermanentUser = function (indexOfPu, userId) {
      return $http.get('/admin/permanentUsers/' + userId).success(function (user) {
        $scope.pUsers[indexOfPu] = user;
        $scope.accessMap[user.id] = {};
        $scope._.forEach(user.accessDto.accessPos, function (access) {
          $scope.accessMap[user.id][access.environment.environmentId] = true;
        });
      });
    };

    $scope.loadCompanies = function () {
      return $http.get('/admin/companies').success(function (companies) {
        $scope.companies = companies;
        $scope._.forEach(companies, function (company) {
          company.test = {
            'environment': $scope._.find(company.environments, {'type': 0})
          };
          company.prod = {
            'environment': $scope._.find(company.environments, {'type': 1})
          };
        });
      });
    };

    $scope.selectedUser = ($scope.tUsers && $scope.tUsers[0]) ? $scope.tUsers[0] : null;

    $scope.selectUser = function ($event, s) {

      if ($scope.userCreate) {
        var stopSwitch = false;
        uiTools.showConfirmDlg({
            type: 'dialog-warning',
            title: $scope.dict.pages.config.environments.list.change_unsaved_title,
            contentTitle: $scope.dict.pages.config.environments.list.importTempUser.abort_confirm
          }).then(function() {
            stopSwitch = true;
            $scope.userCreate = false;
            $scope.tUsers.pop();
            $scope.selectedUser = s;
            $scope.tUsers.pop();
          });

          if (stopSwitch) {
            $event.stopPropagation();
            return;
          }
      } else {
          $scope.userCreate = false;
          $scope.selectedUser = s;
      }
    };

    $scope.addUser = function () {
      var minId = $scope._.min($scope.pUsers, 'id').id;
      var item = {
        id: minId < 0 ? minId - 1 : -1,
        username: 'username',
        realName: '',
        password: '',
        type: 3,
        supportUser: '',
        supportPwd: '',
        accessDto: {
          accessPos: []
        }
      };
      $scope.pUsers.push(item);
      $scope.accessMap[item.id] = {};
      $scope.selectedUser = item;
    };

    $scope.onFileSelect = function ($files) {
      var file = $files[0];
      $scope.upload = $upload.upload({
        url: 'admin/uploadTempUserFile',
        data: {myObj: $scope.myModelObj},
        file: file
      }).success(function (data, status, headers, config) {
        $('#file-upload-input').val('');
        if (data) {
          $scope.tUsers.push(data);
          $scope.userCreate = true;
          $scope.selectedUser = data;
          uiTools.showGrowl($scope.dict.pages.config.environments.list.importTempUser.success, 'success', 1500);
        } else {
            $scope.userCreate = false;
          uiTools.showConfirmDlg({
            type: 'dialog-error',
            title: $scope.dict.pages.config.environments.list.importTempUser.fail,
            contentTitle: $scope.dict.pages.config.environments.list.importTempUser.fail
          });
        }
      });
    };

    $scope.createTempUser = function() {
        $http.post('/admin/importTempUser', $scope.selectedUser).success(function (resultMap) {
          $http.get('/admin/currentTempUser').success(function(tUsers) {
            $scope.tUsers = tUsers;
          });

          if (resultMap.result == "success") {
            uiTools.showGrowl($scope.dict.pages.config.environments.list.addTempUser.success, 'success', 1500);
          } else {
              uiTools.showConfirmDlg({
                  type: 'dialog-error',
                  title: $scope.dict.pages.config.environments.list.addTempUser.fail,
                  contentTitle: $scope.dict.pages.config.environments.list.addTempUser[resultMap.result],
                  hideCancel: true
              });
          }
        });
        $scope.userCreate = false;
    };

    $scope.cancelCreateTempUser = function() {
        $scope.tUsers.pop();
        $scope.userCreate = false;
        $scope.selectedUser = null;
    };

    function savePermanentUserConfig(newAddUserId, index) {
      return $http.put('/admin/permanentUsers/' + newAddUserId + '/config', $scope.accessMap[$scope.selectedUser.id]).success(function (newConfigUser) {
        $scope.loadGivenPermanentUser(index, newAddUserId);
        $scope.selectUser(newConfigUser);
        uiTools.showConfirmDlg({
          type: 'dialog-primary',
          title: $scope.dict.common.success,
          contentTitle: $scope.dict.common.success_content
        });
      });
    }

    function showError(data) {
      uiTools.showConfirmDlg({
        type: 'dialog-error',
        title: $scope.dict.common.fail,
        contentTitle: $scope.dict.common.fail
      });
    }

    $scope.saveUser = function () {
      var index = $scope._.indexOf($scope.pUsers, $scope.selectedUser);
      $http.put('/admin/permanentUsers', $scope.selectedUser).success(function(newAddUserId) {
        savePermanentUserConfig(newAddUserId, index);
      }).error(showError);
    };

    $scope.createUser = function () {
      var index = $scope._.indexOf($scope.pUsers, $scope.selectedUser);
      $http.post('/admin/permanentUsers', $scope.selectedUser).success(function(newAddUserId) {
        savePermanentUserConfig(newAddUserId, index);
      }).error(showError);
    };

    function removePUser(uid) {
      $scope._.remove($scope.pUsers, function (u) {
        return u.id === uid;
      });
    }

    $scope.removeUser = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-warning',
        title: $scope.dict.common.confirm_title,
        contentTitle: $scope.dict.common.are_you_sure,
        okCap: $scope.dict.common.ok_yes,
        cancelCap: $scope.dict.common.cancel_no
      }).then(function () {
        if ($scope.selectedUser.id < 0) {
          removePUser($scope.selectedUser.id);
          $scope.selectUser(null);
        } else {
          $http({method: 'DELETE', url: "/admin/permanentUsers/" + $scope.selectedUser.id + '/config'}).success(function (data) {
            removePUser($scope.selectedUser.id);
            $scope.selectUser(null);
          });
        }
      });
    };

    $scope.changePassword = function () {
      $state.go('config.admin', {'userId': $scope.selectedUser.id});
    };
  }]);
angular.module('progressTrack', [])
  .directive('progressTrack', function () {

    function link(scope, element) {

      var update = function() {
        var value = scope.current - 1;
        element.find('li:lt(' + value + ')').removeClass('current').addClass('done');
        element.find('li:eq(' + value + ')').removeClass('done').addClass('current');
        element.find('li:gt(' + value + ')').removeClass('done').removeClass('current');
      };

      scope.$watch('current', update);
      scope.$watch('steps', update);

      element.on('$destroy', function () {
      });
    }

    return {
      restrict: 'E',

      scope: {
        steps: '=',
        current: '='
      },
      link: link,
      templateUrl: 'progressTrack/progress_track.tpl.html'
    };
  });
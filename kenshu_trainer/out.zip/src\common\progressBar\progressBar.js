angular.module('progressBar', [])
  .directive('progressBar', function () {

    function link(scope, element) {

      scope.$watch('current', function () {
        var width = scope.current / scope.total * 100;
        element.find('.progress-bar').css('width', width + '%');
      });
    }

    return {
      restrict: 'E',
      replace: true,
      scope: {
        total: '=',
        current: '='
      },
      link: link,
      templateUrl: 'progressBar/progress_bar.tpl.html'
    };
  });
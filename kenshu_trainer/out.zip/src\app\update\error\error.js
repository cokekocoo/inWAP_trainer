angular.module('updater.update.error', ['ui.router', 'uiTools', 'dialog'])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('update.error', {
      url: '/error',
      controller: 'errorCtrl',
      templateUrl: 'update/error/error.tpl.html',
      data: {}
    });
  }])
  .controller('errorCtrl', ["$scope", "$http", "$state", "ws", "uiTools", function ($scope, $http, $state, ws, uiTools) {

    if (!$scope.checkEnv()) {
      return;
    }

    var connectErrors = {};
    var connLastErrorTime = 0;
    ws.reset()
          .setConnectListener(function (error) {
              connLastErrorTime = (new Date()).getTime();
              if (!(error.message in connectErrors)) {
                  connectErrors[error.message] = true;
                  uiTools.showConfirmDlg({
                      type: 'dialog-error',
                      title: $scope.dict.pages.update.versions.err_dlg.header,
                      contentTitle: $scope.dict.pages.update.versions.err_dlg.p,
                      contentE: [error.message],
                      hideCancel: true
                  }).then(function () {
                      delete connectErrors[error.message];
                  });
              }
              $scope.waitForRetry = true;
              $scope.$apply();
              setTimeout(function () {
                  if ((new Date()).getTime() - connLastErrorTime > 5000) {
                      $scope.waitForRetry = false;
                      $scope.$apply();
                  }
              }, 5100);
          });

    $scope.setCurrentStep(-1);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    $http.get('/progress/' + env.id + '/' + product.code + '/' + version.id).success(function (data) {
      $scope.progress = data.progress;
      $scope.currentState = data.current;
      $scope.percent = data.percent;
      $scope.phase = data.phase;
      $scope.currentTitle = data.currentTitle;
      $scope.currentInstruction = data.currentInstruction;

      if ($scope.errorInfo) {
        updateErrorInfo();
      }
    });

    var updateErrorInfo = function () {
      $scope.executorError = {};
      $scope.errStep = $scope.dict.phaseName[$scope.phase];
      $scope.taskKey = $scope.currentState;
      $scope.errOperation = $scope.currentTitle;
      for (var key in Object.keys($scope.errorInfo)) {
        var host = Object.keys($scope.errorInfo)[key];
        $scope.serverType = $scope.errorInfo[Object.keys($scope.errorInfo)[key]].serverType;
        var errorDetail = $scope.errorInfo[Object.keys($scope.errorInfo)[key]].summaries;
        $scope.executorError[host] = {
          "errorDetail": errorDetail
        };
      }

      $http.get('/supportInfo/' + env.id + '/' + product.code + '/' + version.id + "/" + $scope.currentState).success(function (supportInfo) {
        $scope.supportInfo = supportInfo;
      });
    };

    $http.get('/errorInfo/' + env.id + '/' + product.code + '/' + version.id).success(function (errors) {
      $scope.errorInfo = errors;
      if ($scope.currentTitle) {
        updateErrorInfo();
      }
    });

    $scope.backBtnClicked = function () {
      $state.go('update.progress');
    };

    $scope.retryBtnClicked = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-primary',
        title: $scope.dict.pages.update.error.handle.header,
        contentP: $scope.dict.pages.update.error.handle.p_retry,
        okCap: $scope.dict.pages.update.error.handle.retry
      }).then(function () {
        $http.post('/retry', {}).success(function () {
          $state.go('update.progress');
        });
      });
    };

    $scope.continueBtnClicked = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-warning',
        title: $scope.dict.pages.update.error.handle.btn_continue,
        contentP: $scope.dict.pages.update.error.handle.p_continue
      }, true).then(function (data) {
        var paramMap = {};
        paramMap.message = data;
        paramMap.errorHash = $scope.supportInfo.errorHash;
        $http.post('/next/ignore', paramMap).success(function () {
          $state.go('update.progress');
        });
      });
    };

  }]);
angular.module('updater.update.progress', ['ui.router', 'uiTools', 'dialog'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.progress', {
      url: '/progress',
      controller: 'progressCtrl',
      templateUrl: 'update/progress/progress.tpl.html',
      data: {}
    });
  }])
  .controller('progressCtrl', ["$scope", "$http", "$state", "$q", "ws", "uiTools", function ($scope, $http, $state, $q, ws, uiTools) {

    if (!$scope.checkEnv()) {
      return;
    }

    $scope.setCurrentStep(4);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    $scope.progressRecord = ws.getProgress();

    $scope.hasError = false;
    $scope.showProgressRecord = false;
    $scope.errorOccurredBefore = false;

    $scope.executorPlans = null;
    $http.get('/plan_info/' + env.id + '/' + product.code + '/' + version.id).success(function (executorPlans) {
      executorPlans.forEach(function (executor) {
        executor.taskInfo[1] = [];
      });
      $scope.executorPlans = executorPlans;
      updateProgress();
    });

    $scope.progress = [];
    $scope.checkResult = {};
    $scope.percent = 0;
    var loadProgressCanceler = $q.defer();
    var loadProgress = function () {
      loadProgressCanceler.resolve();
      loadProgressCanceler = $q.defer();
      return $http.get('/progress/' + env.id + '/' + product.code + '/' + version.id, {timeout: loadProgressCanceler.promise}).success(function (data) {
//        if (data.progress.length < $scope.progress.length) {
//          return;
//        }
        angular.extend($scope, data); // progress, current, percent, phase, currentTitle
        updateProgress();
      });
    };
    loadProgress();

    var updateProgress = function () {

      if (!$scope.progress || !$scope.executorPlans) {
        return;
      }

      $scope.hasError = false;
      $scope.progressMap = $scope.progress.reduce(function (map, element) {
        $scope.hasError = $scope.hasError || element.fail;
        map[element.taskKey] = element;
        return map;
      }, {});

      $scope.executorPlans.forEach(function (executor) {
        executor.taskInfo.forEach(function (phase) {
          phase.forEach(function (task) {
            angular.extend(task, $scope.progressMap[task.taskKey]);
            task.running = !task.fail && !task.finishTime && $scope.current === task.capKey;
            if (task.finishTime && (task.finishType === 'ignore' || task.finishType === 'continue')) {
                $scope.errorOccurredBefore = true;
            }
          });
        });
      });

      if ($scope.current === "ct.startup_confirm" && $scope.errorOccurredBefore) {
        $scope.showConfirm = true;
        $scope.showConfirmDialog = true;
      }

    };

    var nextState = null;
    var nextParams = {};
    var connectErrors= {};
    $scope.goToNextPage = function () {
      if ($scope.showProgressRecord) {
        $scope.showProgressRecord = false;
        return;
      }
      if (nextState) {
        $state.go(nextState, nextParams);
      }
    };

    /**
     *Trouble shooting related
     */
    ws.reset().setErrorListener(function () {
      loadProgress();
      $scope.showErrorDialog = true;
      $scope.$apply();
    }).setStateListener(function (data) {

      if (data.state === 'ct.post-update-collect.wait') {
        nextState = 'update.postUpdateCollect';
        $scope.goToNextPage();
        return;
      }

      if (data.state === 'ct.post-update-manual.wait') {
        nextState = 'update.postUpdateManual';
        $scope.goToNextPage();
        return;
      }

      if (data.state === 'ct.post-update.wait') {
        nextState = 'update.postUpdate';
        $scope.goToNextPage();
        return;
      }

      if (data.state === 'ct.startup_confirm') {

        $scope.$watch( "executorPlans", function() {
            updateProgress();
            if ($scope.errorOccurredBefore) {
                   $scope.showConfirm = true;
                   $scope.showConfirmDialog = true;
               } else {
                   $http.post('/next/success/ct.startup_confirm', {});
               }
        });
      }

      if (data.state === 'ct.show_report') {
        nextState = 'update.report';
        nextParams = {status: 'finish'};
        $scope.goToNextPage();
        return;
      }

      loadProgress();
      $scope.$apply();
    }).setSuccessListener(function () {
      $scope.currentVersion ='';
      loadProgress();
      $scope.$apply();
    }).setConnectListener(function (error) {
      if (!(error.message in connectErrors)) {
        connectErrors[error.message] = true;
        uiTools.showConfirmDlg({
          type: 'dialog-error',
          title: $scope.dict.pages.update.versions.err_dlg.header,
          contentTitle: $scope.dict.pages.update.versions.err_dlg.p,
          contentE: [error.message],
          hideCancel: true
        }).then(function() {
          delete connectErrors[error.message];
        });
        $scope.$apply();
      }
    }).setMultipleApplyListener(function(data){
        $scope.currentVersion = data.version;
        $scope.$apply();
    });


    $scope.startService = function() {
        $scope.showConfirm = false;
        $http.post('/next/success/ct.startup_confirm', {});
    };

    $scope.hideDialog = function () {
      $scope.showErrorDialog = false;
    };

    $scope.errorDetail = function () {
      $state.go('update.error');
    };

    $scope.progressReport = function () {
      $state.go('update.report', {status: 'progress'});
    };

  }]);
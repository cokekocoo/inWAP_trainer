angular.module('textFileReader', [])
  .directive('textFileReader', function () {

    var link = function (scope, element) {

      element.find('.show-part').on('click', function () {
        element.find('input.file-selector-input').trigger('click');
      });

      scope.onFileSelect = function ($files) {

        element.find('input.file-selector-input').val('');

        var file = $files[0];
        var reader = new FileReader();

        reader.onload = function (loadEvent) {
          var text = loadEvent.target.result;
          scope.onSelect({
            $text: text
          });
          scope.$apply();
        };
        reader.readAsText(file);
      };

    };

    return {
      restrict: 'E',
      replace: true,
      transclude: true,
      templateUrl: 'textFileReader/textFileReader.tpl.html',
      link: link,
      scope: {
        onSelect: '&'
      }
    };
  })
  .directive('fileSelector', function () {

    var link = function (scope, element) {
      element.find('.show-part').on('click', function () {
        element.find('input.file-selector-input').trigger('click');
      });

      scope.onFileSelect = function ($files) {

        element.find('input.file-selector-input').val('');

        scope.onSelect({
          $files: $files,
          $file: $files[0]
        });
      };
    };

    return {
      restrict: 'E',
      replace: true,
      transclude: true,
      templateUrl: 'textFileReader/fileSelector.tpl.html',
      link: link,
      scope: {
        onSelect: '&'
      }
    };
  });
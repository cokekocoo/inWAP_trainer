angular.module('helpText', [])
  .directive('helpText', ["$window", function ($window) {

    var link = function(scope) {
      scope._ = $window._;
      scope.dict = scope.$parent.dict;

    };

    return {
      restrict: 'E',
      replace: true,
      link: link,
      scope: {
        dictKey : '='
      },
      templateUrl: 'helpText/helpText.tpl.html'
    };
  }]);
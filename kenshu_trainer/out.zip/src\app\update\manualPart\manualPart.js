angular.module('updater.update.manual', [
  'updater.update.manual.list',
  'updater.update.manual.oneCollect',
  'updater.update.manual.oneManual',
  'updater.update.manual.oneFast',
  'ui.router',
  'loading'
])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('update.manual', {
      url: '/manual',
      controller: 'manualPartCtrl',
      templateUrl: 'update/manualPart/manual_part.tpl.html',
      data: {}
    });
  }])
  .controller('manualPartCtrl', ["$scope", "$http", "$state", function ($scope, $http, $state) {
    $state.go('update.manual.list');
  }]);
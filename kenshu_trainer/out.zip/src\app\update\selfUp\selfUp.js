angular.module('updater.update.selfUp', ['ui.router', 'uiTools', 'dialog'])
    .config(["$stateProvider", function config($stateProvider) {
        $stateProvider.state('update.selfUp', {
            url: '/selfUp',
            controller: 'selfUpdateCtrl',
            templateUrl: 'update/selfUp/selfUp.tpl.html',
            data: {}
        });
    }])
    .controller('selfUpdateCtrl', ["$scope", "$http", "$interval", "$state", "ws", "uiTools", function ($scope, $http, $interval, $state, ws, uiTools) {

        // load current CIU version
        $http.get('/self_update/ciu/current').success(function (data) {
            $scope.current = data;
        });

        // load latest CIU version
        var getLatestCiu = function () {
            $http.get('/self_update/ciu/latest').success(function (data) {
                $scope.latest = data;
            });
        };

        getLatestCiu();

        $scope.hideDialog = function () {
            $scope.showErrorDialog = false;
        };


        $scope.downloadCiu = function(version){
            console.log("start downloading "+version);

            uiTools.showConfirmDlg({
                type: 'dialog-primary',
                title: $scope.dict.pages.update.versions.dl_dlg.header,
                content: $scope.dict.pages.update.versions.dl_dlg.text
            }).then(function () {
                $scope.showDownload = true;
                console.log(version);
                $http.post('/self_update/download/'+version,{})
                    .success(function (data) {

                        $scope.showDownload = false;
                        if (data) {
                            console.log("Successfully download!");
                            getLatestCiu();
                        } else {
                            uiTools.showConfirmDlg({
                                type: 'dialog-error',
                                title: $scope.dict.pages.update.versions.download_err_dlg.header,
                                contentTitle: $scope.dict.pages.update.versions.download_err_dlg.title,
                                contentP: [
                                    $scope.dict.pages.update.versions.download_err_dlg.p
                                ]
                            });

                        }
                    }).error(function (data, status) {
                    $scope.showDownload = false;
                    alert('fail, ' + ', ' + status);
                    console.log(data);
                });
            });

        };

        $scope.selfUpdate = function (version) {
            $scope.showSelfUpd = true;
            $http.post('/self_update/executor/' + version, {}).success(function (data) {
                console.log("self update executor");
                console.log(data);

                if (data.result) {
                    $scope.showSelfUpd = false;
                    uiTools.showConfirmDlg({
                        type: 'dialog-primary',
                        title: $scope.dict.common.restart,
                        contentTitle: $scope.dict.pages.config.self_update.waitRestart,
                        hideCancel: true
                    });

                    $http.post('/self_update/controller/' + version, {}).success(function (data) {
                        console.log("self update controller");
                        console.log(data);

                        if (data.result) {
                            ws.stop();
                            $interval(function () {
                                $http({
                                    url: 'https://' + location.hostname + ':' + (location.port - 443) + '/updater_version',
                                    method: 'GET',
                                    headers: {
                                        'Access-Control-Allow-Origin': '*',
                                        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                                        'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With'
                                    }
                                }).success(function (data, status)
                                {
                                    console.log('success, ' + ', ' + status);
                                    if (status === 200) {
                                        console.log('finish');
                                        location.replace('https://' + location.hostname + ':' + (location.port - 443) + '/login');
                                    }
                                });
                                $http.get('/updater_version').success(function (data, status) {
                                    console.log('success, ' + ', ' + status);
                                    if (status === 200 && isNaN(parseInt(data, 10))) {
                                        console.log('finish');
                                        location.replace(location.pathname + 'logout');
                                        location.reload(true);
                                    }
                                }).error(function (data, status) {
                                    console.log('fail, ' + ', ' + status);
                                });
                            }, 2000);
                        } else {
                            $scope.showSelfUpd = false;
                            $scope.selfUpdateErrorList = data.msg;
                            $scope.showErrorDialog = true;
                        }

                    }).error(function(data, status){
                        ws.stop();
                        $interval(function () {
                            $http({
                                url: 'https://' + location.hostname + ':' + (location.port - 443) + '/updater_version',
                                method: 'GET',
                                headers: {
                                    'Access-Control-Allow-Origin': '*',
                                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                                    'Access-Control-Allow-Headers': 'Content-Type, X-Requested-With'
                                }
                            }).success(function (data, status)
                            {
                                console.log('success, ' + ', ' + status);
                                if (status === 200) {
                                    console.log('finish');
                                    location.replace('https://' + location.hostname + ':' + (location.port - 443) + '/login');
                                }
                            });
                            $http.get('/updater_version').success(function (data, status) {
                                console.log('success, ' + ', ' + status);
                                if (status === 200 && isNaN(parseInt(data, 10))) {
                                    console.log('finish');
                                    location.replace(location.pathname + 'logout');
                                    location.reload(true);
                                }
                            }).error(function (data, status) {
                                console.log('fail, ' + ', ' + status);
                            });
                        }, 2000);
                    });
                } else {
                    var regex = /([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+:[0-9]+;?/g;
                    if(data.msg.length >0 && data.msg[0].match(regex)){
                        for(var i = 0; i < data.msg.length; i++){
                            data.msg[i] = $scope.dict.pages.config.environments.one.network.CONNECTION_FAIL + '\r\n' +
                                $scope.dict.pages.config.self_update.errors.connect_error_prefix + data.msg[i];
                        }
                    }
                    if(data.msg.length >0 && data.msg[0] == 'no_executor_registered'){
                        data.msg[0] = $scope.dict.pages.config.self_update.errors.no_executor_registered;
                    }
                    $scope.showSelfUpd = false;
                    $scope.selfUpdateErrorList = data.msg;
                    $scope.showErrorDialog = true;
                }
            });
        };
    }]);

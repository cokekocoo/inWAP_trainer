angular.module('updater.update.report', ['ui.router', 'updater.update.plan'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.report', {
      url: '/report/:status',
      controller: 'reportCtrl',
      templateUrl: 'update/report/report.tpl.html',
      data: {}
    });
  }])
  .controller('reportCtrl', ["$scope", "$http", "$state", "$stateParams", "ws", "uiTools", function ($scope, $http, $state, $stateParams, ws, uiTools) {

    if (!$scope.checkEnv()) {
      return;
    }

    $scope.setCurrentStep(0);

    var connectErrors = {};
    var connLastErrorTime = 0;
    console.log("in report!");
    ws.reset()
        .setConnectListener(function (error) {
            console.log(error);
            connLastErrorTime = (new Date()).getTime();
            if (!(error.message in connectErrors)) {
                connectErrors[error.message] = true;
                uiTools.showConfirmDlg({
                    type: 'dialog-error',
                    title: $scope.dict.pages.update.versions.err_dlg.header,
                    contentTitle: $scope.dict.pages.update.versions.err_dlg.p,
                    contentE: [error.message],
                    hideCancel: true
                }).then(function () {
                    delete connectErrors[error.message];
                });
            }
            $scope.waitForRetry = true;
            $scope.$apply();
            setTimeout(function () {
                if ((new Date()).getTime() - connLastErrorTime > 5000) {
                    $scope.waitForRetry = false;
                    $scope.$apply();
                }
            }, 5100);
        });

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    $scope.ptfVersionLst = version.includedVersionLst;

    $http.post('/finish/' + env.id + '/' + version.id, version).then(function (data){
        return generateXMLReport();
    }, function(data) {
        console.log("failed to finish update");
    });

    env.products.forEach(function(element) {
        if (element.version.substring(0,3) === product.code) {
            $scope.preVersion = element.version;
        }
        if (product.code ==="SRLT" && element.version.substring(0,4) === product.code) {
            $scope.preVersion = element.version;
        }
    });

    $scope.finish = function () {
//      $http.post('/finish/' + env.id + '/' + version.id, {}).success(function (data) {
//        if (data) {
      $state.go('update.products');
//        }
//      });
    };

    // load apply plan
    $scope.executorPlans = null;
    $http.get('/plan_info/' + env.id + '/' + product.code + '/' + version.id).success(function (executorPlans) {
      $scope.executorPlans = executorPlans;
      updateProgress();
    });

    $scope.progress = null;
    $http.get('/reportCheckResult/' + env.id + '/' + product.code + '/' + version.id).success(function (data) {
      angular.extend($scope, data); // progress, current, percent, phase, currentTitle
      updateProgress();
    });


    var updateProgress = function () {

      $scope.operatorMap = {};

      if (!$scope.progress || !$scope.executorPlans) {
        return;
      }

      var progressMap = $scope.progress.reduce(function (map, element) {
        map[element.taskKey] = element;
        if (element.operator) {
          $scope.operatorMap[element.operator] = true;
        }
        if (element.finishTime) {
          $scope.finishTime = element.finishTime;
        }
        return map;
      }, {});

      $scope.executorPlans.forEach(function (executor) {
        executor.taskInfo.forEach(function (phase) {
          phase.forEach(function (task) {
            angular.extend(task, progressMap[task.taskKey]);
          });
        });
      });

      if (!$scope.finished) {
        $scope.finishTime = new Date();
      }
    };

    $scope.isArray = function (data) {
      return Array.isArray(data);
    };

    $scope.goBack = function () {
      if ($stateParams.status === "progress") {
        $state.go('update.progress');
      } else if ($stateParams.status === "postUpdateCollect") {
        $state.go('update.postUpdateCollect');
      } else if ($stateParams.status === "postUpdateManual") {
        $state.go('update.postUpdateManual');
      }

    };

    // pdf button
    // TODO better style
    $scope.print = function () {
      $('.navbar-fixed-top').hide();
      $('.navbar-fixed-bottom').hide();
      $('.bottom-btn-div').hide();
      window.print();
      $('.navbar-fixed-top').show();
      $('.navbar-fixed-bottom').show();
      $('.bottom-btn-div').show();
    };

    $scope.finished = $stateParams.status === 'finish';

    var reportPath = "";
    function generateXMLReport() {
        var infoForPrintXML = getInfoForPrintXML();
        $http.post('/xml_result_generate',infoForPrintXML).success(function (data) {
            reportPath = data.fileName;
            $scope.downloadXMLReport();
        });
    }

    $scope.downloadXMLReport = function () {
        if (reportPath !== "") {
            console.log("XML report generated " + reportPath);
            //for IE
            if(window.navigator.msSaveBlob) {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'reports/' + reportPath);
                xhr.responseType = 'blob';
                xhr.onloadend = function() {
                    if(xhr.status !== 200) {
                        return;
                    }
                    window.navigator.msSaveBlob(xhr.response, reportPath);
                };
                xhr.send();
            //for Chrome FireFox
            } else {
                var outputElement = document.createElement("a");
                outputElement.href = "reports/" + reportPath;
                outputElement.target = '_blank';
                outputElement.download = reportPath;
                document.body.appendChild(outputElement);
                outputElement.click();
                document.body.removeChild(outputElement);
            }
        } else {
            console.log("Fail to generate XML report");
            uiTools.showGrowl($scope.dict.pages.update.report.generate_xml_report_err, "error", 6000);
        }
      };

    function getInfoForPrintXML (){
      var infoForPrintXML = {};
      infoForPrintXML.cuVersion = $scope.updaterVersion;
      infoForPrintXML.baseVersionInfo = $scope.preVersion;
      infoForPrintXML.userId = $scope.user.id;
      infoForPrintXML.companyName = $scope.env.companyName;
      infoForPrintXML.envId = $scope.env.id;
      infoForPrintXML.updateVersion = $scope.updateData.version;
      return infoForPrintXML;
    }
  }]);
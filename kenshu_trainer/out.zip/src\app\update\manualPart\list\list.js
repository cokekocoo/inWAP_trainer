angular.module('updater.update.manual.list', ['ui.router', 'uiTools'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.manual.list', {
      url: '/list',
      controller: 'manualListCtrl',
      templateUrl: 'update/manualPart/list/list.tpl.html',
      data: {}
    });
  }])
  .controller('manualListCtrl', ["$scope", "$http", "$state", "ws", "uiTools", function ($scope, $http, $state, ws, uiTools) {
    if (!$scope.checkEnv()) {
      return;
    }

    var connectErrors = {};
    var connLastErrorTime = 0;
    ws.reset()
        .setConnectListener(function (error) {
            connLastErrorTime = (new Date()).getTime();
            if (!(error.message in connectErrors)) {
                connectErrors[error.message] = true;
                uiTools.showConfirmDlg({
                    type: 'dialog-error',
                    title: $scope.dict.pages.update.versions.err_dlg.header,
                    contentTitle: $scope.dict.pages.update.versions.err_dlg.p,
                    contentE: [error.message],
                    hideCancel: true
                }).then(function () {
                    delete connectErrors[error.message];
                });
            }
            $scope.waitForRetry = true;
            $scope.$apply();
            setTimeout(function () {
                if ((new Date()).getTime() - connLastErrorTime > 5000) {
                    $scope.waitForRetry = false;
                    $scope.$apply();
                }
            }, 5100);
          });

    $scope.setCurrentStep(3);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    var types = {
      'collect': 'oneCollect',
      'fast': 'oneFast',
      'manual': 'oneManual'
    };

    // load data
    $http.get('/manual_part/' + env.id + '/' + product.code + '/' + version.id).success(function (data) {
      $scope.tasks = data;
    });

    // task select logic
    $scope.oneTaskClick = function (type, task) {
      $state.go('update.manual.' + types[type], {key: task.taskKey});
    };

    // next logic
    $scope.canNext = function () {
      if (!$scope.tasks) {
        return false;
      }
      var i;
      for (var type in types) {
        for (i = 0; i < $scope.tasks[type].length; i++) {
          if (!$scope.tasks[type][i].finishTime) {
            return false;
          }
        }
      }
      return true;
    };

    $scope.nextBtnClick = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-warning',
        title: $scope.dict.pages.update.manual.next_dlg.header,
        contentTitle: $scope.dict.pages.update.manual.next_dlg.title,
        contentP: [
          $scope.dict.pages.update.manual.next_dlg.p
        ],
        okCap: $scope.dict.common.start_btn
      }).then(function () {
        $http.post('/next/success/ct.user_manual', {}).success(function () {
          $state.go('update.progress');
        });
      });
    };
  }]);
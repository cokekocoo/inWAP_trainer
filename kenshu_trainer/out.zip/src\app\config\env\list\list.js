angular.module('updater.config.env.list', ['ui.router', 'uiTools', 'angularFileUpload'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('config.env.list', {
      url: '/list',
      controller: 'configEnvListCtrl',
      templateUrl: 'config/env/list/list.tpl.html',
      data: {}
    });
  }])
  .directive('xeditable', ["$timeout", function($timeout) {
        return {
            restrict: 'A',
            require: "ngModel",
            link: function(scope, element, attrs, ngModel) {
                element.editable({
                    type: 'text',
                    pk: 1,
                    title: scope.dict.pages.config.environments.list.unique_env_msg,
                    success: function(response, newValue) {
                        $timeout(function() {
                            ngModel.$setViewValue(newValue);
                            ngModel.$render();
                            scope.renameEnvironment(newValue);
                        });
                    }
                });

                element.editable('option','validate', function (v) {
                    var message = scope.validateEnvName(v);
                    return message;
                });

                scope.$watch(attrs.ngModel, function(newValue) {
                    element.editable('setValue', newValue);
                });
            }
        };
  }])
  .controller('configEnvListCtrl', ["$scope", "$http", "$state", "$upload", "$q", "uiTools", function ($scope, $http, $state, $upload, $q, uiTools) {

    var loadExecutors = function (company, environmentIndex) {
      $http.get('/admin/environments/' + company.environments[environmentIndex].id + '/executors/').success(function (executors) {
        company.environments[environmentIndex].executors = executors;
      });
    };

    $scope.exportUrl = '/admin/companies/';

    $scope.loadCompany = function () {
      return $http.get('/admin/companies').then(function (companies) {
        $scope.companies = companies.data;
        $scope.companies.forEach(function (company) {
          company.environments.forEach(function (environment, eIndex) {
            loadExecutors(company, eIndex);
          });
        });
      });
    };
    $scope.loadCompany();

    $scope.loadGivenCompany = function (companyId) {
      return $http.get('/admin/companies/' + companyId);
    };

    $scope.selectedCompanyIndex = -1;

//    $scope.companies[$scope.selectedCompanyIndex] = ($scope.companies && $scope.companies[0]) ? $scope.companies[0] : null;
    $scope.selectCompany = function (index) {
      $scope.selectedCompanyIndex = index;
      $scope.selectedEnvIndex = -1;
    };

    $scope.createCompany = function () {
      $http.post('/admin/companies', $scope.companies[$scope.selectedCompanyIndex]).then(function (res) {
        uiTools.showGrowl($scope.dict.common.success, 'success', 800);
        return $scope.loadGivenCompany(res.data);
      }).then(function (company) {
        $scope.companies[$scope.selectedCompanyIndex] = company.data;
      });
    };

    $scope.saveCompany = function () {
      $http.put('/admin/companies/' + $scope.companies[$scope.selectedCompanyIndex].companyId, $scope.companies[$scope.selectedCompanyIndex])
        .then(function (res) {
          if (res.data) {
            uiTools.showGrowl($scope.dict.common.success, 'success', 800);
            return $scope.loadGivenCompany($scope.companies[$scope.selectedCompanyIndex].companyId);
          } else {
            uiTools.showGrowl($scope.dict.common.fail, 'error', 800);
          }
        })
        .then(function (company) {
          $scope.companies[$scope.selectedCompanyIndex] = company.data;
        });
    };

    $scope.addCompany = function () {
      $scope.companies.push({
        companyId: -1,
        companyName: $scope.dict.pages.config.environments.list.please_input,
        supportId: "0",
        countryCode: "",
        environments: [
          {"id": -1, "companyName": "", "environmentName": "Test_Environment", "supportId": "", "type": 0, "products": [], "canConfig": false, "executors": []},
          {"id": -1, "companyName": "", "environmentName": "Production_Environment", "supportId": "", "type": 1, "products": [], "canConfig": false, "executors": []}
        ]
      });
    };

    $scope.removeCompany = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-error',
        title: $scope.dict.common['delete'] + ' ' + $scope.companies[$scope.selectedCompanyIndex].companyName,
        content: $scope.dict.common.are_you_sure
      }).then(function () {
        $http({method: 'DELETE', url: '/admin/companies/' + $scope.companies[$scope.selectedCompanyIndex].companyId}).success(function () {
          $scope.loadCompany();
          $scope.companies[$scope.selectedCompanyIndex] = null;
        }).error(function (data, status) { //data, status, headers, config
          uiTools.showGrowl($scope.dict.common.fail, 'danger', 1500);
        });
      });
    };

    $scope.goDetail = function (env_id) {
      $state.go('config.env.one', {id: env_id});
    };

    $scope.onFileSelect = function ($files) {
      var file = $files[0];
      $scope.upload = $upload.upload({
        url: 'admin/uploadConfiguration',
        data: {myObj: $scope.myModelObj},
        file: file
      }).error(function(data, status, headers, config) {
        uiTools.showConfirmDlg({
            type: 'dialog-error',
            title: $scope.dict.pages.config.environments.list.input_error,
            contentTitle: $scope.dict.pages.config.environments.list.input_error
          }).then(function () {
            $scope.loadCompany();
          });
      }).success(function (data, status, headers, config) {
        $('#file-upload-input').val('');
        if (data) {
          $scope.loadCompany();
          uiTools.showGrowl($scope.dict.common.success, 'success', 800);
        } else {
          uiTools.showConfirmDlg({
            type: 'dialog-error',
            title: $scope.dict.pages.config.environments.list.company_exists,
            contentTitle: $scope.dict.pages.config.environments.list.company_exists
          }).then(function () {
            $scope.loadCompany();
          });
        }
      });
    };

    $scope.addEnvironment = function(env_type) {
        $scope.companies[$scope.selectedCompanyIndex].environments.push({
            "id": -1,
            "companyName": "",
            "environmentName": $scope.dict.pages.config.environments.list.click_to_input,
            "supportId": "",
            "type": env_type,
            "products": [],
            "canConfig": false,
            "executors": []
        });
    };

    $scope.removeEnvironment = function(index) {

        uiTools.showConfirmDlg({
            type: 'dialog-error',
            title: $scope.dict.common['delete'] + ' ' + $scope.companies[$scope.selectedCompanyIndex].environments[index].environmentName,
            content: $scope.dict.common.are_you_sure
          }).then(function() {
            $scope.companies[$scope.selectedCompanyIndex].environments.splice(index, 1);
          });
    };

    $scope.renameEnvironment = function(environmentName) {

        if ($scope.selectedEnvIndex === -1) {
            console.log("no selected environment as target, rename ignored");
            return;
        }

        $scope.companies[$scope.selectedCompanyIndex].environments[$scope.selectedEnvIndex].environmentName = environmentName;
//        if ($scope.companies[$scope.selectedCompanyIndex].companyId > 0) {
//            $http.post('/admin/environments/' + $scope.companies[$scope.selectedCompanyIndex].environments[$scope.selectedEnvIndex].id + "/" + environmentName, $scope.companies[$scope.selectedCompanyIndex])
//            .then(function success(res) {
//                $scope.companies = angular.copy($scope.companies);
//             }, function fail(res) {
//                uiTools.showGrowl($scope.dict.common.fail, 'fail', 800);
//            });
//        }
    };

    $scope.validateEnvName = function(newName) {
        var oriName = $scope.companies[$scope.selectedCompanyIndex].environments[$scope.selectedEnvIndex].environmentName;
        var message = '';
        $scope.companies[$scope.selectedCompanyIndex].environments.forEach(function (environment) {
            if (newName !== oriName && newName === environment.environmentName) {
                message = $scope.dict.pages.config.environments.list.duplicate_environment;
            }
        });
        return message;
    };

    $scope.switchEnvFocus = function(index) {
        $scope.selectedEnvIndex = index;
    };
  }]);
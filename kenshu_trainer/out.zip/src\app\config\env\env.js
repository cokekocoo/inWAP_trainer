angular.module('updater.config.env', [
  'updater.config.env.list',
  'updater.config.env.one'
])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('config.env', {
      url: '/env',
      controller: 'configEnvCtrl',
      templateUrl: 'config/env/env.tpl.html',
      data: {}
    });
  }])
  .controller('configEnvCtrl', function () {
  });
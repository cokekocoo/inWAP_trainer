angular.module('updater.update', [
  'updater.update.socket',
  'updater.update.environments',
  'updater.update.selfUp',
  'updater.update.products',
  'updater.update.versions',
  'updater.update.plan',
  'updater.update.manual',
  'updater.update.progress',
  'updater.update.postUpdateCollect',
  'updater.update.postUpdateCollect.list',
  'updater.update.postUpdateCollect.one',
  'updater.update.postUpdateManual',
  'updater.update.postUpdateManual.list',
  'updater.update.postUpdateManual.one',
  'updater.update.report',
  'updater.update.error',
  'ui.router',
  'progressTrack',
  'loading',
  'uiTools'
])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('update', {
      parent: 'app',
      url: '/update',
      controller: 'updateCtrl',
      templateUrl: 'update/update.tpl.html',
      data: {}
    });
  }])
  .controller('updateCtrl', ["$scope", "$http", "$state", "uiTools", "ws", function($scope, $http, $state, uiTools, ws) {

    ws.connect();

    $scope.updateCtrlName = 'updateCtrl';

    $scope.waitForRetry = false;

    // data for progress track
    $scope.currentStep = 0;
    $scope.setCurrentStep = function (step) {
      $scope.currentStep = step;
    };

    /**
     ************************************************
     * Environment functions                        *
     ************************************************
     */
    $scope.updateData.env = null;
    $scope.setEnv = function (env) {
      $scope.updateData.env = env;
    };
    $scope.resetEnv = function () {
      $scope.updateData.env = null;
      $state.go('update.environments', {}, {reload: true});
    };

    function getInfoForChangePassword(res) {
        var configUser = {};
        configUser.oldPassword = res.oldPassword;
        configUser.newPassword = res.newPassword;
        configUser.username = $scope.user.username;
        return configUser;
    }


      $scope.valid = {
        hasEmpty: false,
        oldPassword: true,
        newPassword: true,
        confirmedPassword: true,

        fastValid: function (configUser) {
            if(configUser.oldPassword === "" || configUser.newPassword === "" || configUser.newPasswordConfirm === ""){
                this.hasEmpty = true;
                return false;
            }
            this.hasEmpty = false;
            if(configUser.newPassword !== configUser.newPasswordConfirm){
                this.confirmedPassword = false;
                return false;
            }
            return true;
        }
    };

    $scope.changeUserPass = function () {
        uiTools.showConfirmDlg({
            type: 'dialog-primary',
            title: $scope.dict.pages.config.admin.change_pass,
            form: [
                ["oldPassword",
                    $scope.dict.pages.config.admin.old_pass,
                    "password"],
                ["newPassword",
                    $scope.dict.pages.config.admin.new_pass,
                    "password"],
                ["newPasswordConfirm",
                    $scope.dict.pages.config.admin.new_pass_confirm,
                    "password"]
            ]
        }).then(function (res) {
            var configUser = getInfoForChangePassword(res);
            if ($scope.valid.fastValid(res)) {
                // currently do not crypted
                $http.put('/users/' + $scope.user.id +'/password', configUser).success(function (result) {
                    if (result.oldPassword) {
                        uiTools.showConfirmDlg({
                            type: 'dialog-primary',
                            title: $scope.dict.common.success,
                            contentTitle: $scope.dict.pages.config.admin.change_pass_success,
                            hideCancel: 'true'
                        });
                    } else {
                        $scope.valid.oldPassword = false;
                        uiTools.showConfirmDlg({
                            type: 'dialog-warning',
                            title: $scope.dict.common.fail,
                            contentTitle: $scope.dict.pages.config.admin.change_pass_fail,
                            hideCancel: 'true',
                            okCap:$scope.dict.pages.config.admin.pass_retry
                        }).then(function (res){
                            $scope.changeUserPass();
                        });
                    }
                });
            } else {
                $scope.valid.oldPassword = false;
                var errMsg = "";
                if($scope.valid.hasEmpty){
                    errMsg = $scope.dict.pages.config.admin.pass_empty;
                }else{
                    errMsg = $scope.dict.pages.config.admin.pass_not_match;
                }
                uiTools.showConfirmDlg({
                    type: 'dialog-warning',
                    title: $scope.dict.common.fail,
                    contentTitle: errMsg,
                    hideCancel: 'true',
                    okCap:$scope.dict.pages.config.admin.pass_retry
                }).then(function (res){
                    $scope.changeUserPass();
                });
            }
        });
    };

    $scope.changeSupportPass = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-primary',
        title: $scope.dict.pages.config.environments.one.configuration,
        form: [
          ["supportUser",
          $scope.dict.pages.config.users.sp_user_name,
          "text"],
          ["supportPass",
          $scope.dict.pages.config.users.sp_user_pass,
          "password"]
        ]
      }).then(function (res) {
        $http.post('/support_update', res).success(function (data) {
          if (data === true) {
              $http.get('/check_support_token').success(function (data){
                  if( !data ){
                      uiTools.showConfirmDlg({
                          type: 'dialog-primary',
                          title: $scope.dict.pages.update.remote_err.header,
                          content: $scope.dict.pages.update.remote_err.text
                      });
                  }else{
                      $scope.resetEnv();
                  }
              }).error(function (data) {
                  console.log("data when error"+data);
              });

          } else {
              console.log("Fail to update support info");
          }
        });
      });
    };

    $scope.refreshEnv = function () {
      $('#detecting').show();
      if ($scope.updateData.env) {
        $http.get('/environment/' + $scope.updateData.env.id).success(function (data) {
          $scope.updateData.env = data;
          $('#detecting').hide();
        });
      }
    };
    $scope.checkEnv = function () {
      if ($scope.updateData.env === null) {
        $state.go('update.environments');
        return false;
      } else {
        return true;
      }
    };
    $scope.envStr = function (env) {
      if (env) {
        return env.companyName + ' - ' + env.environmentName;
      }
    };

    $scope.showPullDownMenu = function () {

    };

    $scope.generateCUlogs = function () {
        // var infoForPrintXML = "C:\\pleiadesCU\\workspace\updater_1\\test_resources\\logs";
        // $http.post('/cu_log_generate',infoForPrintXML).success(function (data) {
        //     reportPath = data.fileName;
        //     $scope.downloadCUlogs();
        // });
        var CUlog = "out.zip";
        $scope.downloadCUlogs(CUlog);
    };

    $scope.downloadCUlogs = function (CUlog) {
        reportPath = CUlog;
        if(window.navigator.msSaveBlob) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', "../" + reportPath);
            xhr.responseType = 'blob';
            xhr.onloadend = function() {
                if(xhr.status !== 200) {
                    return;
                }
                window.navigator.msSaveBlob(xhr.response, reportPath);
            };
            xhr.send();
            //for Chrome FireFox
        } else {
            var outputElement = document.createElement("a");
            outputElement.href = "../" + reportPath;
            outputElement.target = '_blank';
            outputElement.download = "hori.zip";
            document.body.appendChild(outputElement);
            outputElement.click();
            document.body.removeChild(outputElement);
        }
    };

    /**
     ************************************************
     * Current updater work functions               *
     ************************************************
     */
    $scope.updaterWork = null;
    $scope.refreshUpdaterWork = function () {
      return $http.get('/current_update/').success(function (data) {
        $scope.updaterWork = data;
        $scope.updateData.version = data.version;
        for (var i = 0; i < $scope.updateData.env.products.length; i++) {
          if ($scope.updateData.env.products[i].code === data.prod) {
            $scope.updateData.product = $scope.updateData.env.products[i];
            break;
          }
        }
      });
    };

    /**
     ************************************************
     * Common operation                             *
     ************************************************
     */

    $scope.cancelUpdateBtnClick = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-warning',
        title: $scope.dict.common.are_you_sure,
        contentTitle: $scope.dict.common.cancel_dlg_title,
        contentP: [
          $scope.dict.common.cancel_dlg_p
        ]
      }).then(function () {
        $('#detecting').show();
        $http.post('/reset', {}).success(function () {
          $state.go('update.environments');
        });
      });
    };
  }]);
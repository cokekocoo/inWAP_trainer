angular.module('updater.update.environments', ['ui.router', 'uiTools', 'dialog'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.environments', {
      url: '/environments',
      controller: 'environmentsCtrl',
      templateUrl: 'update/environments/environments.tpl.html',
      data: {}
    });
  }])
  .controller('environmentsCtrl', ["$scope", "$http", "$state", "ws", "uiTools", function ($scope, $http, $state, ws, uiTools) {
    ws.reset();

    if ($scope.updateData.env) {
      $state.go('update.products');
      return;
    }

    $scope.envs = [];
    $('#detecting').show();
    console.log("start to detect products");
    $scope.userPromise.success(function () {

      $http.get('/is_permanent_user').success(function (data){
        if( !data ){
            $scope.checkSupportToken();
        }
      }).error(function (data) {
          console.log("data when error"+data);
      });

      $http.get('/user_environment/' + $scope.user.id).success(function (data) {
        $scope.envs = data;
        $('#detecting').hide();
        console.log("finished detecting products");

      }).error(function (data) {
          $('#detecting').hide();
          console.log("environment_list shows none because of AP Server error");
      });
    });
    $scope.checkSupportToken = function () {
      $http.get('/check_support_token').success(function (data){
          if( !data ){
              uiTools.showConfirmDlg({
                  type: 'dialog-primary',
                  title: $scope.dict.pages.update.remote_err.header,
                  content: $scope.dict.pages.update.remote_err.text
              });
          }
      }).error(function (data) {
          console.log("data when error"+data);
      });
    };
    $scope.select = function (env) {
      $scope.setEnv(env);
      $state.go('update.products');
    };

  }]);
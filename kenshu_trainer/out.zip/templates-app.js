angular.module('templates-app', ['app.tpl.html', 'config/admin/admin.tpl.html', 'config/config.tpl.html', 'config/env/env.tpl.html', 'config/env/list/list.tpl.html', 'config/env/one/one.tpl.html', 'config/user/user.tpl.html', 'update/environments/environments.tpl.html', 'update/error/error.tpl.html', 'update/manualPart/list/list.tpl.html', 'update/manualPart/manual_part.tpl.html', 'update/manualPart/oneCollect/one_collect.tpl.html', 'update/manualPart/oneFast/one_fast.tpl.html', 'update/manualPart/oneManual/one_manual.tpl.html', 'update/plan/plan.tpl.html', 'update/postUpdateCollect/list/listCollect.tpl.html', 'update/postUpdateCollect/postUpdateCollect.tpl.html', 'update/postUpdateManual/list/listManual.tpl.html', 'update/postUpdateManual/postUpdateManual.tpl.html', 'update/products/products.tpl.html', 'update/progress/progress.tpl.html', 'update/report/report.tpl.html', 'update/selfUp/selfUp.tpl.html', 'update/update.tpl.html', 'update/versions/versions.tpl.html']);

angular.module("app.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("app.tpl.html",
    "<div class=\"container\" ui-view>\n" +
    "    Loading update page... please wait\n" +
    "</div>\n" +
    "\n" +
    "<!-- Fixed footer -->\n" +
    "<div class=\"navbar navbar-default navbar-fixed-bottom unselectable\" ng-class=\"{'production' : updateData.env.type===1}\">\n" +
    "    <div class=\"container\">\n" +
    "        <div class=\"navbar-collapse collapse form-inline\">\n" +
    "            <div id=\"wrapper\" style=\"display:flex; align-items: center; justify-content: space-between\">\n" +
    "                <ul class=\"nav navbar-nav\">\n" +
    "                    <li><a>{{ 'CIU' + updaterVersion }}</a></li>\n" +
    "                </ul>\n" +
    "\n" +
    "                <select name=\"languageSelect\" id=\"languageSelect\" ng-model=\"selectedLanguage\" ng-change=\"loadNewDict()\" class=\"navbar-right form-control\" >\n" +
    "                    <option value=\"en\">English</option>\n" +
    "                    <option value=\"zh\">简体中文</option>\n" +
    "                    <option value=\"ja\">日本語</option>\n" +
    "                </select>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("config/admin/admin.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/admin/admin.tpl.html",
    "<h2>{{dict.pages.config.admin.change_pass}}</h2>\n" +
    "\n" +
    "<div class=\"col-md-8\">\n" +
    "    <form class=\"form-horizontal\" role=\"form\">\n" +
    "        <fieldset>\n" +
    "            <div class=\"form-group\">\n" +
    "\n" +
    "                <!-- Text input-->\n" +
    "                <label class=\"col-md-3 control-label\" for=\"user-name-input\">{{dict.pages.config.admin.user}}</label>\n" +
    "\n" +
    "                <div class=\"col-md-9\">\n" +
    "                    <input id=\"user-name-input\" class=\"form-control\" ng-model=\"configUser.username\" disabled=\"true\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"form-group\">\n" +
    "                <label class=\"col-md-3 control-label\" for=\"old-password-input\">{{dict.pages.config.admin.old_pass}}</label>\n" +
    "\n" +
    "                <div class=\"col-md-9\">\n" +
    "                    <input id=\"old-password-input\" class=\"form-control\" type=\"password\" placeholder=\"old password\"\n" +
    "                           ng-model=\"configUser.oldPassword\"\n" +
    "                           ng-class=\" {'valid-fail': !valid.oldPassword}\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"form-group\">\n" +
    "                <label class=\"col-md-3 control-label\" for=\"old-password-input\">{{dict.pages.config.admin.new_pass}}</label>\n" +
    "\n" +
    "                <div class=\"col-md-9\">\n" +
    "                    <input id=\"new-password-input\" class=\"form-control\" type=\"password\" placeholder=\"new password\"\n" +
    "                           ng-model=\"configUser.newPassword\"\n" +
    "                           ng-class=\" {'valid-fail': !valid.newPassword}\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"form-group\">\n" +
    "                <label class=\"col-md-3 control-label\" for=\"new-password-input-confirm\">{{dict.pages.config.admin.new_pass_confirm}}</label>\n" +
    "\n" +
    "                <div class=\"col-md-9\">\n" +
    "                    <input id=\"new-password-input-confirm\" class=\"form-control\" type=\"password\"\n" +
    "                           placeholder=\"confirm password\" ng-model=\"configUser.confirmedPassword\"\n" +
    "                           ng-class=\" {'valid-fail': !valid.confirmedPassword}\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <button type=\"submit\" class=\"btn btn-default col-md-offset-9 col-md-3\" ng-click=\"changePassword()\">{{dict.pages.config.admin.change_pass}}\n" +
    "            </button>\n" +
    "        </fieldset>\n" +
    "    </form>\n" +
    "</div>");
}]);

angular.module("config/config.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/config.tpl.html",
    "<!-- Fixed header -->\n" +
    "<div class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\">\n" +
    "    <div class=\"container\">\n" +
    "        <div class=\"navbar-header\">\n" +
    "            <a class=\"navbar-brand\">COMPANY UPDATER</a>\n" +
    "        </div>\n" +
    "        <div class=\"navbar-collapse collapse\">\n" +
    "            <ul class=\"nav navbar-nav\">\n" +
    "                <li><a ui-sref=\"config.env.list\">{{dict.pages.config.environments.title}}</a></li>\n" +
    "                <li><a ui-sref=\"config.user\">{{dict.pages.config.users.title}}</a></li>\n" +
    "            </ul>\n" +
    "            <ul class=\"nav navbar-nav navbar-right\">\n" +
    "                <li ng-show=\"env\">\n" +
    "                    <a ng-href=\"#environments\" ng-click=\"resetEnv()\"><span class=\"glyphicon glyphicon-globe\"></span>\n" +
    "                        {{ envStr(env) }}\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <a ng-click=\"gotoAdminConfig()\"><span class=\"glyphicon glyphicon-user\"></span> {{ user.realName + '(' +\n" +
    "                        user.username + ')'}}</a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <a ng-href=\"/logout\"><span class=\"glyphicon glyphicon-off\"></span></a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"container\" ui-view>\n" +
    "    Loading configuration page... please wait\n" +
    "</div>");
}]);

angular.module("config/env/env.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/env/env.tpl.html",
    "<div ui-view>\n" +
    "    Loading environments...\n" +
    "</div>");
}]);

angular.module("config/env/list/list.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/env/list/list.tpl.html",
    "<dirty-handler handler=\"onDirty\"></dirty-handler>\n" +
    "<h2>{{dict.pages.config.environments.title}}</h2>\n" +
    "<div class=\"row\">\n" +
    "\n" +
    "    <div class=\"col-md-4\">\n" +
    "\n" +
    "        <ul class=\"nav nav-pills nav-stacked\" id=\"server-list\">\n" +
    "            <li ng-repeat=\"c in companies\" ng-class=\"{active : c === companies[selectedCompanyIndex]}\" dirty-check=\"c\">\n" +
    "                <a ng-click=\"selectCompany($index)\">\n" +
    "                    <div class=\"ip\">\n" +
    "                        {{ c.companyName }}\n" +
    "                    </div>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\" ng-click=\"addCompany()\">\n" +
    "            <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "        </button>\n" +
    "\n" +
    "        <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\" onclick=\"return  $('#file-upload-input').click();\">\n" +
    "            <span class=\"glyphicon glyphicon-floppy-open\">\n" +
    "            </span>\n" +
    "        </button>\n" +
    "\n" +
    "        <div style=\"display: none;\">\n" +
    "            <input type=\"text\" ng-model=\"myModelObj\">\n" +
    "            <input type=\"file\" id=\"file-upload-input\" accept=\".export\" ng-file-select=\"onFileSelect($files)\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"col-md-8\">\n" +
    "        <form name=\"companyForm\" editable-form>\n" +
    "            <div ng-if=\"companies[selectedCompanyIndex]\">\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.environments.list.company_name}}</label>\n" +
    "                    <input class=\"form-control\" name=\"companyName\"\n" +
    "                           ng-model=\"companies[selectedCompanyIndex].companyName\" ng-pattern='/^[^\\\\/:*?\"<>|~]+$/'\n" +
    "                           required unique=\"companies\" model=\"companies[selectedCompanyIndex]\"\n" +
    "                           unique-field=\"companyName\"/>\n" +
    "                    <p ng-show=\"companyForm.companyName.$invalid\" class=\"help-block\" style=\"color:red\">\n" +
    "                        {{dict.pages.config.environments.list.company_name_msg}}</p>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.environments.list.support_id}}</label>\n" +
    "                    <input class=\"form-control\" name=\"supportId\" ng-model=\"companies[selectedCompanyIndex].supportId\"\n" +
    "                           required unique=\"companies\" model=\"companies[selectedCompanyIndex]\"\n" +
    "                           unique-field=\"supportId\"/>\n" +
    "                    <p ng-show=\"companyForm.supportId.$invalid\" class=\"help-block\" style=\"color: red\">\n" +
    "                        {{dict.pages.config.environments.list.support_id_msg}}</p>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.environments.list.support_addr}}</label>\n" +
    "                    <div class=\"thumbnail\">\n" +
    "                        <div class=\"row\">\n" +
    "                            <div class=\"col-md-5\">\n" +
    "                                <div class=\"radio\" style=\"margin: 2px\">\n" +
    "                                    <label>\n" +
    "                                        <input type=\"radio\" ng-model=\"companies[selectedCompanyIndex].supportAddress\" value=\"0\" />\n" +
    "                                        {{dict.pages.config.environments.list.support_domestic}}\n" +
    "                                    </label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                            <div class=\"col-md-5\">\n" +
    "                                <div class=\"radio\" style=\"margin: 2px\">\n" +
    "                                    <label>\n" +
    "                                        <input type=\"radio\" ng-model=\"companies[selectedCompanyIndex].supportAddress\" value=\"1\" />\n" +
    "                                        {{dict.pages.config.environments.list.support_global}}\n" +
    "                                    </label>\n" +
    "                                </div>\n" +
    "                            </div>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.environments.list.country_code}}</label>\n" +
    "                    <input class=\"form-control\" ng-model=\"companies[selectedCompanyIndex].countryCode\"\n" +
    "                           unique=\"companies\" model=\"companies[selectedCompanyIndex]\"/>\n" +
    "                </div>\n" +
    "\n" +
    "                <table class=\"table plan-table\">\n" +
    "                    <tr>\n" +
    "                        <th colspan=\"2\">{{dict.pages.config.environments.list.test_env}}</th>\n" +
    "                    </tr>\n" +
    "                    <tr ng-repeat=\"env in companies[selectedCompanyIndex].environments\" ng-if=\"env.type === 0\">\n" +
    "                        <td style=\"vertical-align:middle;\">\n" +
    "                            <a href=\"#\" data-ng-model=\"env.environmentName\" xeditable ng-click=\"switchEnvFocus($index)\"\n" +
    "                               class=\"editable editable-click\">{{env.environmentName || \"Click To Input Name\"}}</a>\n" +
    "                            <!--<a href=\"#\" data-type=\"text\" data-pk=\"1\" data-title=\"Input Unique Environment Name\" data-success=\"renameEnvironment(env.id, env.environmentName)\" data-ng-model=\"env.environmentName\" xeditable class=\"editable editable-click\">{{env.environmentName || \"Click To Input Name\"}}</a>-->\n" +
    "                        </td>\n" +
    "                        <td style=\"vertical-align:middle;\">\n" +
    "                            <button class=\"btn btn-default btn-sm cfg-btn\" style=\"min-width:0;\"\n" +
    "                                    ng-click=\"goDetail(env.id)\"\n" +
    "                                    ng-disabled=\"env.id === -1\"\n" +
    "                                    data-toggle=\"tooltip\" title=\"Configure Detail\">\n" +
    "                                <span class=\"glyphicon glyphicon-edit\"></span>\n" +
    "                            </button>\n" +
    "                            <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\"\n" +
    "                                    style=\"min-width:0; margin-left:5px;\" ng-click=\"removeEnvironment($index)\"\n" +
    "                                    data-toggle=\"tooltip\" title=\"Delete Environment\">\n" +
    "                                <span class=\"glyphicon glyphicon-remove\"></span>\n" +
    "                            </button>\n" +
    "                        </td>\n" +
    "                    </tr>\n" +
    "                    <tr>\n" +
    "                        <td colspan=\"2\" style=\"vertical-align:middle;\">\n" +
    "                            <button type=\"button\" class=\"btn btn-default btn-sm\" style=\"min-width:0;\"\n" +
    "                                    ng-click=\"addEnvironment(0)\">\n" +
    "                                <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "                            </button>\n" +
    "                        </td>\n" +
    "                    </tr>\n" +
    "                    <tr>\n" +
    "                        <th colspan=\"2\">{{dict.pages.config.environments.list.prod_env}}</th>\n" +
    "                    </tr>\n" +
    "                    <tr ng-repeat=\"env in companies[selectedCompanyIndex].environments\" ng-if=\"env.type === 1\">\n" +
    "                        <td style=\"vertical-align:middle;\">\n" +
    "                            <a href=\"#\" data-ng-model=\"env.environmentName\" xeditable ng-click=\"switchEnvFocus($index)\"\n" +
    "                               class=\"editable editable-click\">{{env.environmentName || \"Click To Input Name\"}}</a>\n" +
    "                        </td>\n" +
    "                        <td style=\"vertical-align:middle;\">\n" +
    "                            <button class=\"btn btn-default btn-sm cfg-btn\" style=\"min-width:0;\"\n" +
    "                                    ng-click=\"goDetail(env.id)\"\n" +
    "                                    ng-disabled=\"env.id === -1\"\n" +
    "                                    data-toggle=\"tooltip\" title=\"Configure Detail\">\n" +
    "                                <span class=\"glyphicon glyphicon-edit\"></span>\n" +
    "                            </button>\n" +
    "                            <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\"\n" +
    "                                    style=\"min-width:0; margin-left:5px;\" ng-click=\"removeEnvironment($index)\"\n" +
    "                                    data-toggle=\"tooltip\" title=\"Delete Environment\">\n" +
    "                                <span class=\"glyphicon glyphicon-remove\"></span>\n" +
    "                            </button>\n" +
    "                        </td>\n" +
    "                    </tr>\n" +
    "                    <tr>\n" +
    "                        <td colspan=\"2\" style=\"vertical-align:middle;\">\n" +
    "                            <button type=\"button\" class=\"btn btn-default btn-sm\" style=\"min-width:0;\"\n" +
    "                                    ng-click=\"addEnvironment(1)\">\n" +
    "                                <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "                            </button>\n" +
    "                        </td>\n" +
    "                    </tr>\n" +
    "                </table>\n" +
    "\n" +
    "                <label>{{dict.pages.config.environments.list.export_config}}</label>\n" +
    "\n" +
    "                <div id=\"server-config\">\n" +
    "                    <div>\n" +
    "                        <a class=\"btn btn-default btn-sm\"\n" +
    "                           ng-href=\"{{ exportUrl + companies[selectedCompanyIndex].companyId }}\"\n" +
    "                           ng-disabled=\"companies[selectedCompanyIndex].companyId === -1\">{{dict.pages.config.environments.list.export}}</a>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div>\n" +
    "                        <button class=\"btn btn-primary btn-sm\" ng-click=\"createCompany()\"\n" +
    "                                ng-if=\"companies[selectedCompanyIndex].companyId === -1\"\n" +
    "                                ng-disabled=\"companyForm.$invalid\">\n" +
    "                            {{dict.common.create}}\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-primary btn-sm\" ng-click=\"saveCompany()\"\n" +
    "                                ng-if=\"companies[selectedCompanyIndex].companyId !== -1\"\n" +
    "                                ng-disabled=\"companyForm.$invalid\">\n" +
    "                            {{dict.common.save}}\n" +
    "                        </button>\n" +
    "                        <button class=\"btn btn-danger btn-sm\" ng-click=\"removeCompany()\">\n" +
    "                            {{dict.common.delete}}\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </form>\n" +
    "    </div>\n" +
    "</div>\n" +
    "");
}]);

angular.module("config/env/one/one.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/env/one/one.tpl.html",
    "<dirty-handler handler=\"onDirty\"></dirty-handler>\n" +
    "\n" +
    "<div class=\"row\">\n" +
    "    <div class=\"col-md-3\">\n" +
    "        <h3>\n" +
    "            {{environment.companyName }} - {{ environment.environmentName }}\n" +
    "            {{ dict.pages.config.environments.one.executor_list}}\n" +
    "        </h3>\n" +
    "\n" +
    "        <ul class=\"nav nav-pills nav-stacked\" id=\"server-list\">\n" +
    "            <li ng-repeat=\"e in executors\" ng-class=\"{active : e === selected}\" dirty-check=\"e\">\n" +
    "                <a ng-click=\"select($index)\">\n" +
    "                    <div class=\"ip\">\n" +
    "                        {{ e.host ? e.host + ':' + e.port : dict.pages.config.environments.one.basic.please_set }}\n" +
    "                    </div>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "\n" +
    "        </ul>\n" +
    "\n" +
    "        <button class=\"btn btn-default btn-sm cfg-btn\" ng-click=\"addExecutor()\">\n" +
    "            <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "        </button>\n" +
    "\n" +
    "        <br/>\n" +
    "\n" +
    "        <button class=\"btn btn-default btn-sm cfg-btn cfg-btn-big\" ng-click=\"back()\">\n" +
    "            {{dict.common.back}}\n" +
    "        </button>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"col-md-6\">\n" +
    "\n" +
    "        <div id=\"server-config-home\">\n" +
    "            <h3>{{dict.pages.config.environments.one.configuration}}</h3>\n" +
    "        </div>\n" +
    "        <div id=\"server-config\" ng-if=\"selected\">\n" +
    "\n" +
    "            <form novalidate name=\"executorForm\" ng-init=\"setFormScope(this)\">\n" +
    "                <div>\n" +
    "                    <h4>{{dict.pages.config.environments.one.basic.title}}</h4>\n" +
    "\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <label>{{dict.pages.config.environments.one.basic.env_mst_Id}}</label>\n" +
    "                        <help-text dict-key=\"dict.pages.config.environments.one.basic.env_mst_id_help\"></help-text>\n" +
    "                        <input ng-model=\"selected.envMstId\" class=\"form-control\"\n" +
    "                               required\n" +
    "                               ng-change=\"validEnvMstId(selected.envMstId)\"/>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-group\" ng-class=\"{'has-error': errorList.indexOf('host') >= 0}\">\n" +
    "                        <label>{{dict.pages.config.environments.one.basic.host}}</label>\n" +
    "                        <help-text dict-key=\"dict.pages.config.environments.one.basic.host_help\"></help-text>\n" +
    "                        <input ng-model=\"selected.host\" class=\"form-control\" name=\"host\" required\n" +
    "                               ng-change=\"validHostAndPort(selected.host, selected.port)\"/>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-group\" ng-class=\"{'has-error': errorList.indexOf('port') >= 0}\">\n" +
    "                        <label>{{dict.pages.config.environments.one.basic.port}}</label>\n" +
    "                        <help-text dict-key=\"dict.pages.config.environments.one.basic.port_help\"></help-text>\n" +
    "                        <input type=\"number\" ng-model=\"selected.port\" class=\"form-control\" min=\"0\" max=\"65535\"\n" +
    "                               required\n" +
    "                               ng-change=\"validHostAndPort(selected.host, selected.port)\"/>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-group\">\n" +
    "                        <label>{{dict.pages.config.environments.one.basic.backup_flag}}</label>\n" +
    "                        <help-text dict-key=\"dict.pages.config.environments.one.basic.backup_flag_help\"></help-text>\n" +
    "                        <select class=\"form-control\"\n" +
    "                                ng-options=\"m as dict.pages.config.environments.one.basic.backup[m] for m in [0, 1]\"\n" +
    "                                ng-model=\"selected.backupFlag\"></select>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-group\" ng-class=\"{'has-error': errorList.indexOf('backupDir') >= 0}\">\n" +
    "                        <label>{{dict.pages.config.environments.one.basic.backup_dir}}</label>\n" +
    "                        <help-text dict-key=\"dict.pages.config.environments.one.basic.backup_dir_help\"></help-text>\n" +
    "                        <input ng-model=\"selected.backupDir\" class=\"form-control\"/>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div ng-if=\"errorMsg.length > 0\">\n" +
    "                        <label style=\"color: red\">{{dict.pages.config.environments.one.wrong_config}}</label>\n" +
    "                        <ul>\n" +
    "                            <li ng-repeat=\"message in errorMsg\"><label style=\"color: red\">{{message}}</label></li>\n" +
    "                        </ul>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <button class=\"btn btn-primary btn-sm\" ng-click=\"saveExecutor(selected)\"\n" +
    "                            ng-if=\"selected.executorId !== -1\" ng-disabled=\"checkChange() || executorForm.$invalid || !validHostAndPort(selected.host, selected.port) || !validEnvMstId(selected.envMstId)\">\n" +
    "                        {{dict.common.save}}\n" +
    "                    </button>\n" +
    "\n" +
    "                    <button class=\"btn btn-primary btn-sm\" ng-click=\"createExecutor(selected)\"\n" +
    "                            ng-if=\"selected.executorId === -1\" ng-disabled=\"executorForm.$invalid || !validHostAndPort(selected.host, selected.port) || !validEnvMstId(selected.envMstId)\">\n" +
    "                        {{dict.common.create}}\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-default btn-sm\" ng-click=\"validConfiguration(selected)\"\n" +
    "                            ng-disabled=\"executorForm.$invalid || !validEnvMstId(selected.envMstId)\">\n" +
    "                        {{dict.pages.config.environments.one.basic.check_configuration}}\n" +
    "                    </button>\n" +
    "                    <button class=\"btn btn-danger btn-sm\" ng-click=\"removeExecutor()\">{{dict.common.delete}}\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </form>\n" +
    "\n" +
    "            <div>\n" +
    "                <h4>{{dict.pages.config.environments.one.server.type}}</h4>\n" +
    "\n" +
    "                <div class=\"dropdown\">\n" +
    "                    <button class=\"btn btn-default btn-sm\" data-toggle=\"dropdown\">\n" +
    "                        <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "                        {{dict.pages.config.environments.one.server.add}}\n" +
    "                    </button>\n" +
    "                    <ul class=\"dropdown-menu multi-level\" role=\"menu\" aria-labelledby=\"drop1\">\n" +
    "                        <li class=\"dropdown-submenu\" ng-repeat=\"(prod, types) in addTypes\">\n" +
    "                            <a ng-if=\"prod === 'CSR' || prod == 'SRLT'\" tabindex=\"-1\" style=\"cursor: default\">{{prod}}</a>\n" +
    "                            <a ng-if=\"prod !== 'CSR' && prod !== 'SRLT'\" tabindex=\"-1\" style=\"cursor: default\">{{dict.product[prod]}}</a>\n" +
    "                            <ul class=\"dropdown-menu\">\n" +
    "                                <li ng-repeat=\"type in types\"><a style=\"cursor: pointer\"\n" +
    "                                                                 ng-click=\"addServer(prod + '_' + type)\">{{\n" +
    "                                    dict.serverType[type] }}</a></li>\n" +
    "                            </ul>\n" +
    "                        </li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "\n" +
    "            <div ng-repeat=\"(type, typeData) in selected.typeConfig\" class=\"one-type\">\n" +
    "                <div id=\"type_id_{{$index}}\">\n" +
    "                    <h4>{{ serverTypeDict(type) }}</h4>\n" +
    "                    <div ng-repeat=\"item in configKeys[type]\" class=\"form-group\"\n" +
    "                         ng-class=\"{'has-error': errorList.indexOf(type + ':' + item) >= 0}\">\n" +
    "\n" +
    "                        <label> {{ dict.pages.config.environments.one.server[item].titles[type] }}</label>\n" +
    "                        <p ng-if=\"item === 'HOME'\" class=\"help-block\">{{ dict.pages.config.environments.one.server[item].help[type] }}</p>\n" +
    "                        <!--begin (for csr time data import :modified by Tamagawa_s@2017/03/24)-->\n" +
    "                        <p ng-if=\"item !== 'HOME'\" class=\"help-block\"> {{ dict.pages.config.environments.one.server[item].help }}</p>\n" +
    "                        <input ng-model=\"typeData[item]\" class=\"form-control\"\n" +
    "                               ng-if=\"item !== 'STANDBY' && item !== 'CONTROL_TYPE' && item.indexOf('PASS') < 0\"/>\n" +
    "                        <input ng-model=\"typeData[item]\" class=\"form-control\" type=\"password\"\n" +
    "                               ng-if=\"item !== 'STANDBY' && item !== 'CONTROL_TYPE' && item.indexOf('PASS') >= 0\"/>\n" +
    "                        <select ng-model=\"typeData[item]\" class=\"form-control\" ng-if=\"item === 'STANDBY'\"\n" +
    "                                ng-options=\"m as dict.pages.config.environments.one.server.STANDBY.options[m] for m in ['0','1']\"></select>\n" +
    "                        <select ng-model=\"typeData[item]\" class=\"form-control\" ng-init=\"typeData[item] = '1' || typeData[item]\" ng-if=\"item === 'CONTROL_TYPE'\"\n" +
    "                                ng-options=\"m as dict.pages.config.environments.one.server.CONTROL_TYPE.options[m] for m in ['0','1']\"></select>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div ng-if=\"type.indexOf('DB') >= 0\">\n" +
    "                        <div ng-repeat=\"(schemaType, schemaTypeData) in selected.typeDbConfig[type]\"\n" +
    "                             class=\"one-schema-type one-schema-div\">\n" +
    "                            <h5>{{dict.pages.config.environments.one.server.schema}} : {{\n" +
    "                                dict.pages.config.environments.one.server.schemas[schemaType] }}</h5>\n" +
    "\n" +
    "                            <div class=\"form-group\"\n" +
    "                                 ng-class=\"{'has-error': errorList.indexOf(type + ':' + schemaType) >= 0}\">\n" +
    "\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.DB_URL.title}}</label>\n" +
    "                                <input ng-model=\"schemaTypeData['DB_URL']\" class=\"form-control\"/>\n" +
    "\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.DB_USER.title}}</label>\n" +
    "                                <input ng-model=\"schemaTypeData['DB_USER']\" class=\"form-control\"/>\n" +
    "\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.DB_PASS.title}}</label>\n" +
    "                                <input type=\"password\" ng-model=\"schemaTypeData['DB_PASS']\" class=\"form-control\"/>\n" +
    "\n" +
    "                            </div>\n" +
    "\n" +
    "                        </div>\n" +
    "\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div ng-if=\"type.indexOf('DB') >= 0\">\n" +
    "                        <div ng-repeat=\"(schemaType, schemaTypeData) in selected.typeDbConfig[type]\"\n" +
    "                             class=\"one-schema-type one-schema-div\">\n" +
    "\n" +
    "                            <div class=\"form-group\"\n" +
    "                                 ng-class=\"{'has-error': errorList.indexOf(type + ':EXP_USER') >= 0}\">\n" +
    "\n" +
    "                                <!--For DB Export User-->\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.EXP_USER.title}}</label>\n" +
    "                                <input ng-model=\"schemaTypeData['EXP_USER']\" class=\"form-control\"/>\n" +
    "\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.EXP_PASS.title}}</label>\n" +
    "                                <input type=\"password\" ng-model=\"schemaTypeData['EXP_PASS']\" class=\"form-control\"/>\n" +
    "\n" +
    "                                <label class=\"schema-label\">{{dict.pages.config.environments.one.server.EXP_DIRECTORY_OBJECT_NAME.title}}</label>\n" +
    "                                <input ng-model=\"schemaTypeData['EXP_DIRECTORY_OBJECT_NAME']\" class=\"form-control\"/>\n" +
    "                            </div>\n" +
    "\n" +
    "                        </div>\n" +
    "\n" +
    "                    </div>\n" +
    "\n" +
    "                    <button class=\"btn btn-danger btn-sm\" ng-click=\"removeServer(type)\">{{dict.common.delete}}\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"col-md-3\" id=\"leftCol\" ng-show=\"selected\">\n" +
    "        <ul class=\"nav nav-stacked\" id=\"sidebar\">\n" +
    "            <li>\n" +
    "                <a href=\"#server-config-home\" ng-click=\"scrollTo_server($event)\">{{dict.pages.config.environments.one.configuration}}</a>\n" +
    "            </li>\n" +
    "            <li ng-repeat=\"(type, typeData) in selected.typeConfig\">\n" +
    "                <a href=\"#type_id_{{$index}}\" ng-click=\"scrollTo_typeId($event, $index)\"> {{\n" +
    "                    serverTypeDict(type) }}</a>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "    </div>\n" +
    "\n" +
    "</div>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showProgress\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.config.environments.one.basic.check_configuration}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3>{{dict.pages.config.environments.one.basic.configuration_check_in_progress}}</h3>\n" +
    "        <progress-bar current=\"progressNow\" total=\"1\"></progress-bar>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showDetected\">\n" +
    "    <div class=\"modal-header modal-header-primary\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.config.environments.one.detect.title}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <div ng-if=\"detected.products.length > 0\">\n" +
    "            <h4>{{dict.pages.config.environments.one.detect.new_product.title}}</h4>\n" +
    "            <ul>\n" +
    "                <li ng-repeat=\"i in detected.products\">\n" +
    "                    {{ i.name }}\n" +
    "                    <span ng-if=\"i.newVersion\" class=\"label label-info\">new version</span>\n" +
    "                    <span ng-if=\"i.newProduct\" class=\"label label-info\">new product</span>\n" +
    "                    <span ng-if=\"i.newRecord\" class=\"label label-info\">new record</span>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "");
}]);

angular.module("config/user/user.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("config/user/user.tpl.html",
    "<dirty-handler handler=\"onDirty\"></dirty-handler>\n" +
    "<h2>{{dict.pages.config.users.title}}</h2>\n" +
    "\n" +
    "<div class=\"row\">\n" +
    "\n" +
    "    <div class=\"col-md-4\" ng-model=\"pUsers\" id=\"server-list\">\n" +
    "        <h4>{{dict.pages.config.users.permanent}} {{dict.pages.config.users.title}}</h4>\n" +
    "        <ul class=\"nav nav-pills nav-stacked\">\n" +
    "            <li ng-repeat=\"u in pUsers\" ng-class=\"{active : u === selectedUser}\" dirty-check=\"u\">\n" +
    "                <a ng-click=\"selectUser($event, u)\">\n" +
    "                    <div class=\"ip\">\n" +
    "                        {{ u.username }}\n" +
    "                    </div>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\" ng-click=\"addUser()\" >\n" +
    "            <span class=\"glyphicon glyphicon-plus\"></span>\n" +
    "        </button>\n" +
    "\n" +
    "        <h4>{{dict.pages.config.users.temp}} {{dict.pages.config.users.title}}</h4>\n" +
    "        <ul class=\"nav nav-pills nav-stacked\">\n" +
    "            <li ng-repeat=\"u in tUsers\" ng-class=\"{active : u === selectedUser}\" dirty-check=\"u\">\n" +
    "                <a ng-click=\"selectUser($event, u)\" >\n" +
    "                    <div class=\"ip\">\n" +
    "                        {{ u.username }}\n" +
    "                    </div>\n" +
    "                </a>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <button type=\"button\" class=\"btn btn-default btn-sm cfg-btn\" onclick=\"return  $('#file-upload-input').click();\">\n" +
    "            <span class=\"glyphicon glyphicon-floppy-open\">\n" +
    "            </span>\n" +
    "        </button>\n" +
    "\n" +
    "        <div style=\"display: none;\">\n" +
    "            <input type=\"text\" ng-model=\"myModelObj\">\n" +
    "            <input type=\"file\" id=\"file-upload-input\" ng-file-select=\"onFileSelect($files)\">\n" +
    "        </div>\n" +
    "\n" +
    "    </div>\n" +
    "    <div class=\"col-md-8\">\n" +
    "        <form name=\"userForm\">\n" +
    "            <div id=\"server-config\" ng-if=\"selectedUser || userCreate\">\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.users.user_id}}</label>\n" +
    "                    <input class=\"form-control\" ng-model=\"selectedUser.username\" ng-disabled=\"selectedUser.type === 2 || userCreate\" required unique=\"pUsers\" model=\"selectedUser\" unique-field=\"username\"/>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\">\n" +
    "                    <label>{{dict.pages.config.users.real_name}}</label>\n" +
    "                    <input class=\"form-control\" ng-model=\"selectedUser.realName\" ng-disabled=\"selectedUser.type === 2 || userCreate\" required />\n" +
    "                </div>\n" +
    "                <div class=\"form-group\" ng-if=\"selectedUser.type === 3\">\n" +
    "                    <label>{{dict.pages.config.users.password}}</label>\n" +
    "                    <input type=\"password\" class=\"form-control\" ng-model=\"selectedUser.password\"\n" +
    "                           ng-disabled=\"selectedUser.id >= 0\" data-ng-required=\"true\"/>\n" +
    "                </div>\n" +
    "\n" +
    "                <div class=\"form-group\" ng-if=\"selectedUser.type !== 3\">\n" +
    "                    <label>{{dict.pages.config.users.sp_user_name}}</label>\n" +
    "                    <input class=\"form-control\" ng-model=\"selectedUser.supportUser\" placeholder=\"Please input your @Support Username\" required/>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\" ng-if=\"selectedUser.type !== 3\">\n" +
    "                    <label>{{dict.pages.config.users.sp_user_pass}}</label>\n" +
    "                    <input type=\"password\" class=\"form-control\" ng-model=\"selectedUser.supportPwd\" placeholder=\"Please input your @Support Password\" required/>\n" +
    "                </div>\n" +
    "                <div class=\"form-group\" ng-if = false>\n" +
    "                    <label>{{dict.pages.config.users.support_address}}</label>\n" +
    "                    <div class = \"thumbnail\">\n" +
    "                        <div class=\"radio\">\n" +
    "                            <label><input type=\"radio\" name=\"sp_address\">Domestic (https://support.worksap.co.jp/)</label>\n" +
    "                        </div>\n" +
    "                        <div class=\"radio\">\n" +
    "                            <label><input type=\"radio\" name=\"sp_address\">Global (https://support.worksap.co.jp/)</label>\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "\n" +
    "\n" +
    "                <label>{{dict.pages.config.users.access_control}}</label>\n" +
    "                <table class=\"table table-bordered table-condensed\" ng-if=\"selectedUser.type === 2 || userCreate\">\n" +
    "                    <thead>\n" +
    "                    <tr class=\"active\">\n" +
    "                        <th width=\"10%\">{{dict.pages.config.users.company_env}}</th>\n" +
    "                        <th width=\"10%\">{{dict.pages.config.users.from_version}}</th>\n" +
    "                        <th width=\"10%\">{{dict.pages.config.users.to_version}}</th>\n" +
    "                        <th width=\"10%\">{{dict.pages.config.users.start_date}}</th>\n" +
    "                        <th width=\"10%\">{{dict.pages.config.users.end_date}}</th>\n" +
    "                    </tr>\n" +
    "                    </thead>\n" +
    "                    <tbody>\n" +
    "                    <tr ng-repeat=\"accessPo in selectedUser.accessDto.accessPos\">\n" +
    "                        <td>{{ accessPo.environment.companyInfo.companyName }} - {{ accessPo.environment.environmentName }}\n" +
    "                        </td>\n" +
    "                        <td>{{ accessPo.fromVersionPo.productCd}}{{ accessPo.fromVersionPo.versionNum}}</td>\n" +
    "                        <td>{{ accessPo.toVersionPo.productCd}}{{ accessPo.toVersionPo.versionNum}}</td>\n" +
    "                        <td>{{ accessPo.applyFrom | date:'yyyy-MM-dd'}}</td>\n" +
    "                        <td>{{ accessPo.applyTo | date:'yyyy-MM-dd'}}</td>\n" +
    "                    </tr>\n" +
    "                    </tbody>\n" +
    "                </table>\n" +
    "\n" +
    "                <table class=\"table table-bordered table-condensed\" ng-if=\"selectedUser.type === 3\" ng-repeat=\"company in companies\">\n" +
    "                    <thead>\n" +
    "                    <tr class=\"active\">\n" +
    "                        <th width=\"40%\" style=\"text-align:center\">{{dict.pages.config.users.company_env}}</th>\n" +
    "                        <th width=\"10%\" style=\"text-align:center\">{{dict.pages.config.users.accessible}}</th>\n" +
    "                    </tr>\n" +
    "                    </thead>\n" +
    "                    <tbody>\n" +
    "                    <tr ng-repeat=\"environment in company.environments\">\n" +
    "                        <td>\n" +
    "                            <span ng-if=\"environment.type === 0\">{{ company.companyName }} - TEST - {{environment.environmentName}}</span>\n" +
    "                            <span ng-if=\"environment.type === 1\">{{ company.companyName }} - PRODUCT - {{environment.environmentName}}</span>\n" +
    "                        </td>\n" +
    "                        <td>\n" +
    "                            <input type=\"checkbox\" ng-model=\"accessMap[selectedUser.id][environment.id]\"/>\n" +
    "                        </td>\n" +
    "                    </tr>\n" +
    "                    </tbody>\n" +
    "                </table>\n" +
    "                <button ng-if=\"selectedUser.type === 3 && selectedUser.id >= 0\" class=\"btn btn-primary btn-sm\" style=\"display: inline\" ng-disabled = \"userForm.$invalid\"\n" +
    "                        ng-click=\"saveUser()\">{{dict.common.save}}\n" +
    "                </button>\n" +
    "                <button ng-if=\"selectedUser.type === 3 && selectedUser.id < 0\" class=\"btn btn-primary btn-sm\" style=\"display: inline\" ng-disabled = \"userForm.$invalid\"\n" +
    "                        ng-click=\"createUser()\">{{dict.common.create}}\n" +
    "                </button>\n" +
    "                <button type=\"button\" ng-if=\"selectedUser.type === 3 && selectedUser.id >= 0\" class=\"btn btn-default btn-sm\" style=\"display: inline\"\n" +
    "                        ng-click=\"changePassword()\">{{dict.pages.config.admin.change_pass}}\n" +
    "                </button>\n" +
    "                <button ng-if=\"selectedUser.type === 3\" class=\"btn btn-danger btn-sm\"\n" +
    "                        style=\"display: inline\" ng-click=\"removeUser()\">{{dict.common.delete}}\n" +
    "                </button>\n" +
    "                <button ng-if=\"userCreate === true\" class=\"btn btn-primary btn-sm\" style=\"display: inline\" ng-disabled = \"!selectedUser.supportUser || !selectedUser.supportPwd\"\n" +
    "                        ng-click=\"createTempUser()\">{{dict.common.create}}\n" +
    "                </button>\n" +
    "                <button ng-if=\"userCreate === true\" class=\"btn btn-default btn-sm\" style=\"display: inline\"\n" +
    "                        ng-click=\"cancelCreateTempUser()\">{{dict.common.cancel}}\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </form>\n" +
    "    </div>\n" +
    "\n" +
    "</div>");
}]);

angular.module("update/environments/environments.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/environments/environments.tpl.html",
    "<h2>{{dict.pages.update.env.title}}</h2>\n" +
    "\n" +
    "<h4>{{dict.pages.update.env.info}}</h4>\n" +
    "<br/>\n" +
    "\n" +
    "<loading ng-hide=\"envs\"></loading>\n" +
    "\n" +
    "<div class=\"row unselectable\" ng-repeat=\"e in envs\">\n" +
    "    <div class=\"col-md-6\">\n" +
    "        <div class=\"well one_env\" ng-click=\"select(e)\">\n" +
    "            <h4>{{ envStr(e) }}</h4>\n" +
    "            <span class=\"label prods_in_env\"\n" +
    "                  ng-repeat=\"p in e.products\"\n" +
    "                  ng-class=\"{'1': 'label-primary', '0': 'label-default', '-1': 'label-danger'}[p.updateAvailable]\">\n" +
    "                {{ p.version =='CGP0' ? dict.pages.update.prods.table.cgp_not_applied_yet : p.version }}\n" +
    "            </span>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>");
}]);

angular.module("update/error/error.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/error/error.tpl.html",
    "<button class=\"btn btn-default\" ng-click=\"backBtnClicked()\">{{dict.common.back}}</button>\n" +
    "<br>\n" +
    "<br>\n" +
    "\n" +
    "<div class=\"panel panel-info\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <h4 class=\"panel-title\">{{dict.pages.update.error.info.header}}</h4>\n" +
    "    </div>\n" +
    "    <div style=\"margin:10px\">\n" +
    "        <table width=\"100%\" class=\"table server-table\">\n" +
    "            <tbody>\n" +
    "            <tr>\n" +
    "                <th width=\"10%\">{{dict.pages.update.error.info.step}}</th>\n" +
    "                <td>{{errStep}}</td>\n" +
    "            </tr>\n" +
    "            <tr>\n" +
    "                <th>{{dict.pages.update.error.info.operation}}</th>\n" +
    "                <td>{{errOperation}}</td>\n" +
    "            </tr>\n" +
    "            <tr>\n" +
    "                <th>{{dict.pages.update.error.info.serverType}}</th>\n" +
    "                <td>{{ serverTypeDict(serverType) }}</td>\n" +
    "            </tr>\n" +
    "            </tbody>\n" +
    "        </table>\n" +
    "        <table width=\"100%\" class=\"table server-table\" ng-repeat=\"(host, errorObj) in executorError\">\n" +
    "            <tr>\n" +
    "                <th width=\"10%\">{{dict.pages.update.error.info.host}}</th>\n" +
    "                <td>{{host}}</td>\n" +
    "            </tr>\n" +
    "            <tr ng-repeat=\"errorDetail in errorObj.errorDetail\">\n" +
    "                <th>{{dict.pages.update.error.info.log}}</th>\n" +
    "                <td>{{errorDetail}}</td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"panel panel-info\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <h4 class=\"panel-title\">{{dict.pages.update.error.support.header}}</h4>\n" +
    "    </div>\n" +
    "    <div style=\"margin:10px\" width=\"100%\">\n" +
    "        <p style=\"font-weight:bold\">{{dict.pages.update.error.support.msg_info}}</p>\n" +
    "\n" +
    "        <div width=\"100%\">\n" +
    "            <div ng-if=\"supportInfo == null\" class=\"progress\" ng-class=\"{'progress-striped active' : true}\"\n" +
    "                 style=\"width:50%\">\n" +
    "                <div class=\"progress-bar\" role=\"progressbar\" style=\"width:100%;\">\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <p ng-if=\"supportInfo == null\">{{dict.pages.update.error.support.msg_wait}}</p>\n" +
    "            <table width=\"100%\" ng-if=\"supportInfo != null\" class=\"table server-table\">\n" +
    "                <tr>\n" +
    "                    <td width=\"10%\" style=\"font-weight:bold\">{{dict.pages.update.error.support.title}}</td>\n" +
    "                    <td>\n" +
    "                        <div style=\"white-space: pre-wrap\">{{supportInfo.title}}</div>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "                <tr>\n" +
    "                    <td width=\"10%\" style=\"font-weight:bold\">{{dict.pages.update.error.support.file}}</td>\n" +
    "                    <td width=\"90%\">\n" +
    "                        <div style=\"white-space: pre-wrap; word-break: break-all\"><a target=\"_self\" href=\"download/{{supportInfo.limitedTitle}}.zip\" download=\"{{supportInfo.title}}.zip\">{{supportInfo.title}}.zip</a></div>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "                <tr>\n" +
    "                    <td width=\"10%\" style=\"font-weight:bold\">{{dict.pages.update.error.support.error}}</td>\n" +
    "                    <td width=\"90%\">\n" +
    "                        <div style=\"white-space: pre-wrap; word-break: break-all; max-height:600px; overflow:auto\">{{supportInfo.content}}</div>\n" +
    "                    </td>\n" +
    "                </tr>\n" +
    "            </table>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"supportInfo.ignoredInTest\" class=\"panel panel-info\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <h4 class=\"panel-title\">{{dict.pages.update.error.remind.header}}</h4>\n" +
    "    </div>\n" +
    "    <div style=\"margin:10px\">\n" +
    "        <p><strong>{{dict.pages.update.error.remind.info}}</strong></p>\n" +
    "        <pre style=\"background:inherit; border:none\">{{ supportInfo.testIgnoreMessage }}</pre>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"panel panel-info\">\n" +
    "    <div class=\"panel-heading\">\n" +
    "        <h4 class=\"panel-title\">{{dict.pages.update.error.handle.header}}</h4>\n" +
    "    </div>\n" +
    "\n" +
    "    <div style=\"margin:10px\">\n" +
    "        <div class=\"bottom-btn-div\" ng-if=\"serverType.indexOf('_DB') < 0\">\n" +
    "            <p><strong>{{dict.pages.update.error.handle.msg_retry}}</strong></p>\n" +
    "            <button class=\"btn btn-primary\" ng-click=\"retryBtnClicked()\">{{dict.pages.update.error.handle.btn_retry}}</button>\n" +
    "        </div>\n" +
    "\n" +
    "        <div class=\"bottom-btn-div\" ng-if=\"taskKey.indexOf('DB_BACKUP') === taskKey.length - 9\">\n" +
    "            <p><strong>{{dict.pages.update.error.handle.msg_retry}}</strong></p>\n" +
    "            <button class=\"btn btn-primary\" ng-click=\"retryBtnClicked()\">{{dict.pages.update.error.handle.btn_retry}}</button>\n" +
    "        </div>\n" +
    "\n" +
    "        <div class=\"bottom-btn-div\">\n" +
    "            <p><strong>{{dict.pages.update.error.handle.msg_continue}}</strong></p>\n" +
    "            <div ng-if=\"currentInstruction\" style=\"white-space: pre-wrap\">Instruction:  {{ currentInstruction }}</div>\n" +
    "            <button class=\"btn btn-warning\" ng-click=\"continueBtnClicked()\">{{dict.pages.update.error.handle.btn_continue}}</button>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "</div>\n" +
    "");
}]);

angular.module("update/manualPart/list/list.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/manualPart/list/list.tpl.html",
    "<h2>{{dict.pages.update.manual.title}}</h2>\n" +
    "<h4>{{dict.pages.update.manual.info}}</h4>\n" +
    "\n" +
    "<loading ng-hide=\"tasks\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"type in ['collect', 'fast', 'manual']\" ng-if=\"tasks[type].length > 0\">\n" +
    "    <hr/>\n" +
    "    <h4>{{dict.pages.update.manual[type].title}}</h4>\n" +
    "\n" +
    "    <table class=\"table table-hover table-condensed\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.host}}</th>\n" +
    "            <th width=\"20%\">{{dict.pages.update.manual.table.name}}</th>\n" +
    "            <th width=\"40%\">{{dict.pages.update.manual.table.description}}</th>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.finish_time}}</th>\n" +
    "            <th width=\"10%\">{{dict.pages.update.manual.table.operator}}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr ng-repeat=\"t in tasks[type]\" ng-class=\"{true: 'success', false: ''}[!!t.finishTime]\"\n" +
    "            ng-click=\"oneTaskClick(type, t)\" style=\"cursor: pointer\">\n" +
    "            <td>{{ t.host }}</td>\n" +
    "            <td>{{ t.title }}</td>\n" +
    "            <td>{{ t.summary }}</td>\n" +
    "            <td>\n" +
    "                {{ t.finishTime | date:'yyyy-MM-dd HH:mm:ss' }}\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                {{ t.operator }}\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<div ng-if=\"tasks.collect.length === 0 && tasks.fast.length === 0 && tasks.manual.length === 0\">\n" +
    "    <p>{{dict.pages.update.manual.no_task}}</p>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"cancelUpdateBtnClick()\" ng-disabled=\"waitForRetry\" >{{dict.common.cancel}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"nextBtnClick()\" ng-disabled=\"!canNext() || waitForRetry\">{{dict.common.next}}</button>\n" +
    "</div>");
}]);

angular.module("update/manualPart/manual_part.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/manualPart/manual_part.tpl.html",
    "<div ui-view>\n" +
    "    Loading manual parts...\n" +
    "</div>");
}]);

angular.module("update/manualPart/oneCollect/one_collect.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/manualPart/oneCollect/one_collect.tpl.html",
    "<h2>{{ task.title }}</h2>\n" +
    "<h4>{{ task.summary }}</h4>\n" +
    "<div ng-if=\"task.detail\" style=\"white-space: pre-wrap\">{{ task.detail.trim() }}</div>\n" +
    "\n" +
    "<br/>\n" +
    "<loading ng-hide=\"task\"></loading>\n" +
    "\n" +
    "<div ng-if=\"task.instruction\">\n" +
    "    <h4>{{dict.pages.update.manual.manual.instruction}}</h4>\n" +
    "    <pre style=\"background-color: inherit\">{{ task.instruction.trim() }}</pre>\n" +
    "</div>\n" +
    "\n" +
    "<form name=\"collectForm\">\n" +
    "\n" +
    "    <div ng-repeat=\"q in task.questions\">\n" +
    "\n" +
    "        <h4>{{ q.title }}</h4>\n" +
    "\n" +
    "        <p>{{ q.description }}</p>\n" +
    "\n" +
    "\n" +
    "        <div ng-if=\"q.type === 'TYPE_INPUT'\" class=\"form-group\">\n" +
    "            <div class=\"form-group\">\n" +
    "                <input class=\"form-control\" ng-model=\"q.value\" ng-pattern=\"q.validation\" data-ng-required=\"true\"/>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "\n" +
    "        <div ng-if=\"q.type === 'TYPE_COMBO'\" class=\"form-group\">\n" +
    "            <div class=\"form-group\">\n" +
    "                <select class=\"form-control\" ng-model=\"q.value\" ng-options=\"k as v[0] for (k, v) in q.options\"\n" +
    "                        required></select>\n" +
    "\n" +
    "                <div ng-if=\"q.options[q.value][1]\" ng-bind-html=\"q.options[q.value][1]\" style=\"margin-top: 8px;\"></div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "\n" +
    "        <div ng-if=\"q.type === 'TYPE_GRID'\" class=\"form-group\">\n" +
    "\n" +
    "            <a class=\"btn btn-default btn-xs\" ng-href=\"{{exportUrl + $index}}\">\n" +
    "                <span class=\"glyphicon glyphicon-export\"></span> {{dict.pages.update.manual.collect.import.export_btn}}\n" +
    "            </a>\n" +
    "\n" +
    "            <file-selector class=\"btn btn-default btn-xs\" on-select=\"importOneGrid($index, $file)\">\n" +
    "                <span class=\"glyphicon glyphicon-import\"></span> {{dict.pages.update.manual.collect.import.import_btn}}\n" +
    "            </file-selector>\n" +
    "\n" +
    "            <div class=\"gridStyle\" ng-grid=\"q.gridOptions\" style=\"min-height: 100px; margin-top: 8px;\"></div>\n" +
    "        </div>\n" +
    "\n" +
    "        <br/>\n" +
    "    </div>\n" +
    "\n" +
    "    <br/>\n" +
    "\n" +
    "    <div class=\"bottom-btn-div\">\n" +
    "        <button class=\"btn btn-default\" ng-click=\"cancelBtnClick()\">{{dict.common.cancel}}</button>\n" +
    "        <button class=\"btn btn-primary\" ng-click=\"saveBtnClick()\" ng-disabled=\"collectForm.$invalid\">\n" +
    "            {{dict.common.save}}\n" +
    "        </button>\n" +
    "    </div>\n" +
    "\n" +
    "</form>");
}]);

angular.module("update/manualPart/oneFast/one_fast.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/manualPart/oneFast/one_fast.tpl.html",
    "<h2>{{ task.title }}</h2>\n" +
    "<h4>{{ task.summary }}</h4>\n" +
    "\n" +
    "<br/>\n" +
    "<loading ng-hide=\"task\"></loading>\n" +
    "\n" +
    "<form name=\"fastForm\">\n" +
    "<table class=\"fast-release-list\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th>{{dict.pages.update.manual.fast.file}}</th>\n" +
    "        <th>{{dict.pages.update.manual.fast.file_operation}}</th>\n" +
    "        <th>{{dict.pages.update.manual.fast.file_info}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tr ng-repeat=\"f in task.fastReleaseFiles\">\n" +
    "        <td>{{ f.name }}</td>\n" +
    "        <td class=\"select-td\">\n" +
    "            <select required class=\"form-control\" ng-model=\"f.operation\"\n" +
    "                    ng-options=\"k*1 as v for (k, v) in {'1': dict.pages.update.manual.fast.delete, '2': dict.pages.update.manual.fast.retain}\">\n" +
    "            </select>\n" +
    "        </td>\n" +
    "        <td><input class=\"form-control\" ng-model=\"f.message\"/></td>\n" +
    "    </tr>\n" +
    "\n" +
    "</table>\n" +
    "\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"cancelBtnClick()\">{{dict.common.cancel}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"saveBtnClick()\" ng-disabled=\"fastForm.$invalid\">{{dict.common.save}}</button>\n" +
    "</div>\n" +
    "</form>");
}]);

angular.module("update/manualPart/oneManual/one_manual.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/manualPart/oneManual/one_manual.tpl.html",
    "<h2>{{ task.title }}</h2>\n" +
    "<h4>{{ task.summary }}</h4>\n" +
    "<div ng-if=\"task.detail\" style=\"white-space: pre-wrap\">{{ task.detail.trim() }}</div>\n" +
    "\n" +
    "<h5 class=\"text-info\" ng-if=\"!task.finishTime\">{{dict.pages.update.manual.manual.msg_no_finish}}</h5>\n" +
    "<h5 class=\"text-success\" ng-if=\"task.finishTime\">{{dict.pages.update.manual.manual.msg_finish}} {{ task.finishTime |\n" +
    "    date:'yyyy-MM-dd HH:mm:ss'}} {{ task.operator }}</h5>\n" +
    "\n" +
    "<br/>\n" +
    "<loading ng-hide=\"task\"></loading>\n" +
    "\n" +
    "<h4>{{dict.pages.update.manual.manual.target}}</h4>\n" +
    "<ul class=\"list-group\">\n" +
    "    <li class=\"list-group-item\">{{dict.pages.update.manual.manual.target_host}}: {{ task.host }}</li>\n" +
    "    <li class=\"list-group-item\">{{dict.pages.update.manual.manual.target_type}}: {{ task.serverType }}</li>\n" +
    "    <li class=\"list-group-item\" ng-repeat=\"(key, value) in task.midWareInfo\">{{ key }}: {{ value }}</li>\n" +
    "</ul>\n" +
    "\n" +
    "<br/>\n" +
    "<h4>{{dict.pages.update.manual.manual.instruction}}</h4>\n" +
    "<pre style=\"background-color: inherit\">{{ task.instruction.trim() }}</pre>\n" +
    "\n" +
    "<br/>\n" +
    "<h4>{{dict.pages.update.manual.manual.check}}</h4>\n" +
    "<p class=\"text-success\" ng-if=\"task.checkPass\">{{dict.pages.update.manual.manual.check_pass}}</p>\n" +
    "<div ng-if=\"!task.checkPass\" ng-bind-html=\"task.checkResult\"></div>\n" +
    "\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"cancelBtnClick()\">{{dict.common.back}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"testBtnClick()\">{{dict.common.test}}</button>\n" +
    "</div>");
}]);

angular.module("update/plan/plan.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/plan/plan.tpl.html",
    "<h2>{{dict.pages.update.plan.target}}</h2>\n" +
    "<loading ng-hide=\"executorPlans\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"executorPlan in executorPlans\">\n" +
    "    <table class=\"table plan-table\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th colspan=\"2\">{{ executorPlan.executor.host }}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.os_info}}</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td width=\"20%\">OS</td>\n" +
    "            <td width=\"80%\">{{ executorPlan.executor.os.name }} ({{ executorPlan.executor.os.arch }})</td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.mid_info}}</td>\n" +
    "        </tr>\n" +
    "        <tr ng-repeat=\"(serverType,valueMap) in executorPlan.executor.middlewareInfo\">\n" +
    "            <td>{{ serverTypeDict(serverType) }}</td>\n" +
    "            <td>\n" +
    "                <table width=\"100%\">\n" +
    "                    <tr ng-repeat=\"(name,value) in valueMap\">\n" +
    "                        <td width=\"30%\"> {{ name }}</td>\n" +
    "                        <td> {{ value }}</td>\n" +
    "                    </tr>\n" +
    "                </table>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.mid_config}}</td>\n" +
    "        </tr>\n" +
    "        <tr ng-repeat=\"(serverType,valueMap) in executorPlan.executor.configuration\">\n" +
    "            <td>{{ serverTypeDict(serverType) }}</td>\n" +
    "            <td>\n" +
    "                <table width=\"100%\">\n" +
    "                    <tr ng-repeat=\"(name, value) in valueMap | configForDisplay\">\n" +
    "                        <td width=\"30%\"> {{ dict.pages.config.environments.one.server[name].title }}</td>\n" +
    "                        <td ng-if=\"name.indexOf('PASS') >= 0 \">***</td>\n" +
    "                        <td ng-if=\"name.indexOf('PASS') < 0 \"> {{ value }}</td>\n" +
    "                    </tr>\n" +
    "                </table>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "\n" +
    "<h2>{{dict.pages.update.plan.process}}</h2>\n" +
    "<loading ng-hide=\"executorPlans\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"executorPlan in executorPlans\">\n" +
    "    <table class=\"table table-hover plan-table\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th colspan=\"2\">{{ executorPlan.executor.host }}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody ng-repeat=\"(phase, tasks) in executorPlan.taskInfo\" ng-if=\"tasks && tasks.length > 0\">\n" +
    "        <tr class=\"stage-header\">\n" +
    "            <td colspan=2>\n" +
    "                {{ dict.phaseName[$index] }}\n" +
    "                <span class=\"label label-info\" ng-if=\"phase === 1\">Manual</span>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr ng-repeat-start=\"task in tasks\" class=\"task\" ng-class=\"{true: 'info', false: ''}[phase === 1]\" ng-click=\"task.showDetail = !task.showDetail\">\n" +
    "            <td width=\"30%\">{{ task.title }}</td>\n" +
    "            <td width=\"70%\">{{ task.summary }}</td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr ng-if=\"task.showDetail\" ng-repeat-end class=\"task_detail\">\n" +
    "            <td colspan=2>\n" +
    "                <div ng-if=\"task.detail\">\n" +
    "                    <span class=\"label label-default\">{{dict.pages.update.plan.label_detail}}</span>\n" +
    "                    <pre>{{ task.detail.trim() }}</pre>\n" +
    "                </div>\n" +
    "                <div ng-if=\"task.instruction\">\n" +
    "                    <span class=\"label label-default\">{{dict.pages.update.plan.label_instruction}}</span>\n" +
    "                    <pre>{{ task.instruction.trim() }}</pre>\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button ng-disabled = \"waitForRetry\" class=\"btn btn-default\" ng-click=\"cancelUpdateBtnClick()\">{{dict.common.cancel}}</button>\n" +
    "    <button ng-disabled = \"waitForRetry\" class=\"btn btn-primary\" ng-click=\"nextBtnClick()\">{{dict.common.next}}</button>\n" +
    "</div>");
}]);

angular.module("update/postUpdateCollect/list/listCollect.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/postUpdateCollect/list/listCollect.tpl.html",
    "<h2>{{dict.pages.update.post_update_collect.title}} </h2>\n" +
    "<h4>{{dict.pages.update.post_update_collect.info}}</h4>\n" +
    "\n" +
    "<loading ng-hide=\"tasks\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"type in ['collect']\" ng-if=\"tasks[type].length > 0\">\n" +
    "    <hr/>\n" +
    "    <h4>{{dict.pages.update.manual[type].title}}</h4>\n" +
    "\n" +
    "    <table class=\"table table-hover table-condensed\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.host}}</th>\n" +
    "            <th width=\"20%\">{{dict.pages.update.manual.table.name}}</th>\n" +
    "            <th width=\"40%\">{{dict.pages.update.manual.table.description}}</th>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.finish_time}}</th>\n" +
    "            <th width=\"10%\">{{dict.pages.update.manual.table.operator}}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr ng-repeat=\"t in tasks[type]\" ng-class=\"{true: 'success', false: ''}[!!t.finishTime]\"\n" +
    "            ng-click=\"oneTaskClick(type, t)\" style=\"cursor: pointer\">\n" +
    "            <td>{{ t.host }}</td>\n" +
    "            <td>{{ t.title }}</td>\n" +
    "            <td>{{ t.summary }}</td>\n" +
    "            <td>\n" +
    "                {{ t.finishTime | date:'yyyy-MM-dd HH:mm:ss' }}\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                {{ t.operator }}\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"progressRptBtnClick()\">{{dict.pages.update.progress.prog_report}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"nextBtnClick()\" ng-disabled=\"!canNext()\">{{dict.common.next}}</button>\n" +
    "</div>");
}]);

angular.module("update/postUpdateCollect/postUpdateCollect.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/postUpdateCollect/postUpdateCollect.tpl.html",
    "<div ui-view>\n" +
    "    Loading post update collect parts...\n" +
    "</div>");
}]);

angular.module("update/postUpdateManual/list/listManual.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/postUpdateManual/list/listManual.tpl.html",
    "<h2>{{dict.pages.update.post_update_manual.title}} Manual</h2>\n" +
    "<h4>{{dict.pages.update.post_update_manual.info}}</h4>\n" +
    "\n" +
    "<loading ng-hide=\"tasks\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"type in ['manual']\" ng-if=\"tasks[type].length > 0\">\n" +
    "    <hr/>\n" +
    "    <h4>{{dict.pages.update.manual[type].title}}</h4>\n" +
    "\n" +
    "    <table class=\"table table-hover table-condensed\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.host}}</th>\n" +
    "            <th width=\"20%\">{{dict.pages.update.manual.table.name}}</th>\n" +
    "            <th width=\"40%\">{{dict.pages.update.manual.table.description}}</th>\n" +
    "            <th width=\"15%\">{{dict.pages.update.manual.table.finish_time}}</th>\n" +
    "            <th width=\"10%\">{{dict.pages.update.manual.table.operator}}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr ng-repeat=\"t in tasks[type]\" ng-class=\"{true: 'success', false: ''}[!!t.finishTime]\"\n" +
    "            ng-click=\"oneTaskClick(type, t)\" style=\"cursor: pointer\">\n" +
    "            <td>{{ t.host }}</td>\n" +
    "            <td>{{ t.title }}</td>\n" +
    "            <td>{{ t.summary }}</td>\n" +
    "            <td>\n" +
    "                {{ t.finishTime | date:'yyyy-MM-dd HH:mm:ss' }}\n" +
    "            </td>\n" +
    "            <td>\n" +
    "                {{ t.operator }}\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"progressRptBtnClick()\">{{dict.pages.update.progress.prog_report}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"nextBtnClick()\" ng-disabled=\"!canNext()\">{{dict.common.next}}</button>\n" +
    "</div>");
}]);

angular.module("update/postUpdateManual/postUpdateManual.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/postUpdateManual/postUpdateManual.tpl.html",
    "<div ui-view>\n" +
    "    Loading post update manual parts...\n" +
    "</div>");
}]);

angular.module("update/products/products.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/products/products.tpl.html",
    "<h2>{{dict.pages.update.prods.title}}</h2>\n" +
    "<h4>{{dict.pages.update.prods.prod_status}}</h4>\n" +
    "\n" +
    "<table class=\"table\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th width=\"25%\">{{dict.pages.update.prods.table.name}}</th>\n" +
    "        <th width=\"25%\">{{dict.pages.update.prods.table.status}}</th>\n" +
    "        <th width=\"25%\">{{dict.pages.update.prods.table.version}}</th>\n" +
    "        <th width=\"25%\">{{dict.pages.update.prods.table.update}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "    <tr ng-repeat=\"p in updateData.env.products\">\n" +
    "        <td>{{ p.code }}</td>\n" +
    "        <td>\n" +
    "            <span ng-if=\"p.updateAvailable==0\">\n" +
    "                <span class=\"glyphicon glyphicon-ok\" style=\"color: #5cb85c\"></span>\n" +
    "            </span>\n" +
    "            <span ng-if=\"p.updateAvailable==-1\" class=\"text-danger\">\n" +
    "                <span class=\"glyphicon glyphicon-question-sign\" style=\"color:red\"></span>\n" +
    "                {{dict.pages.update.prods.table.out_sync}}\n" +
    "            </span>\n" +
    "            <span ng-if=\"p.updateAvailable==1 && ! (updaterWork.env.id===updateData.env.id && updaterWork.prod===p.code) \">\n" +
    "                <span class=\"glyphicon glyphicon-upload\" style=\"color: #428bca\"></span>\n" +
    "                {{dict.pages.update.prods.table.available}}\n" +
    "            </span>\n" +
    "            <span ng-if=\"p.updateAvailable==1 && updaterWork && updaterWork.env.id===updateData.env.id && updaterWork.prod===p.code\">\n" +
    "                <span class=\"glyphicon glyphicon-refresh\" style=\"color: #d9534f\"></span>\n" +
    "                {{dict.pages.update.prods.table.updating}}\n" +
    "            </span>\n" +
    "        </td>\n" +
    "        <td>\n" +
    "            <span ng-if=\"p.version == 'CGP0'\">{{dict.pages.update.prods.table.not_applied_yet}}</span>\n" +
    "            <span ng-if=\"p.version != 'CGP0'\">{{p.version}}</span>\n" +
    "        </td>\n" +
    "        <td class=\"product-status-list-btn\">\n" +
    "            <button ng-if=\"p.updateAvailable==1 && !updaterWork\"\n" +
    "                    ng-click=\"selectProdBtnClick(p)\"\n" +
    "                    class=\"btn btn-primary btn-xs\">\n" +
    "                {{dict.pages.update.prods.table.update}}\n" +
    "            </button>\n" +
    "\n" +
    "            <button ng-if=\"p.updateAvailable==1 && updaterWork && updaterWork.env.id===updateData.env.id && updaterWork.prod===p.code\"\n" +
    "                    ng-click=\"continueBtnClick()\"\n" +
    "                    class=\"btn btn-primary btn-xs\">\n" +
    "                {{dict.pages.update.prods.table.continue}}\n" +
    "            </button>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<h4>{{dict.pages.update.prods.current}}</h4>\n" +
    "<div ng-if=\"!updaterWork\">\n" +
    "    {{dict.pages.update.prods.no_current}}\n" +
    "</div>\n" +
    "<div ng-if=\"updaterWork\">\n" +
    "    <p>\n" +
    "        <dict-span template=\"{{dict.pages.update.prods.current_msg1}}\"\n" +
    "                   template-data=\"{prod:updaterWork.prod,\n" +
    "                   env:envStr(updaterWork.env),\n" +
    "                   version: updaterWork.version.name}\" >\n" +
    "        </dict-span>\n" +
    "    </p>\n" +
    "\n" +
    "    <p class=\"text-info\">\n" +
    "        <span class=\"glyphicon glyphicon-info-sign\"></span>\n" +
    "        {{dict.pages.update.prods.current_msg2}}\n" +
    "    </p>\n" +
    "</div>");
}]);

angular.module("update/progress/progress.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/progress/progress.tpl.html",
    "<h2>{{dict.pages.update.progress.title}}</h2>\n" +
    "\n" +
    "<h4>{{dict.pages.update.progress.current}} {{ dict.phaseName[phase] }} — {{ currentTitle }}</h4>\n" +
    "<h4 ng-if=\"currentVersion\">{{dict.pages.update.progress.current_version}} {{currentVersion}}</h4>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\" ng-if=\"hasError\">\n" +
    "    <p>{{dict.pages.update.progress.err_msg_1}}</p>\n" +
    "    <p>{{dict.pages.update.progress.err_msg_2}}</p>\n" +
    "    <p>{{dict.pages.update.progress.err_msg_3}}</p>\n" +
    "    <div class=\"bottom-btn-div\">\n" +
    "        <button class=\"btn btn-primary\" ng-click=\"errorDetail()\">{{dict.pages.update.progress.trouble_shooting}}</button>\n" +
    "        <!--<button class=\"btn btn-default\">Rollback</button>-->\n" +
    "        <button class=\"btn btn-default\" ng-click=\"progressReport()\">{{dict.pages.update.progress.prog_report}}</button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\" ng-if=\"showConfirm\">\n" +
    "    <p>{{dict.pages.update.progress.confirm_server_start_msg}}</p>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"startService()\">{{dict.pages.update.progress.start_service_btn_text}}</button>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div progress\" ng-class=\"{'progress-striped active' : !hasError && !showConfirm}\">\n" +
    "    <div class=\"progress-bar\" role=\"progressbar\" ng-class=\"{'progress-bar-danger' : hasError}\" ng-style=\"{width: (percent / 100 * 97) + 3 + '%'}\">\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"showProgressRecord=true\">Show process detail</button>\n" +
    "</div>\n" +
    "\n" +
    "<loading ng-hide=\"executorPlans\"></loading>\n" +
    "\n" +
    "<div ng-repeat=\"executorPlan in executorPlans\">\n" +
    "    <table class=\"table table-hover plan-table\" id=\"progress-table\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th colspan=\"3\">{{ executorPlan.executor.host }}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody ng-repeat=\"(phase, tasks) in executorPlan.taskInfo\" ng-if=\"tasks && tasks.length > 0\">\n" +
    "        <tr class=\"stage-header\">\n" +
    "            <td colspan=3>\n" +
    "                {{ dict.phaseName[$index] }}\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr ng-repeat=\"task in tasks\" ng-class=\"{\n" +
    "                        'success': task.finishType === 'success',\n" +
    "                        'warning': task.finishType === 'ignore' || task.finishType === 'continue',\n" +
    "						'danger': task.fail,\n" +
    "						'info': task.running}\">\n" +
    "            <td width=\"30%\">{{ task.title }}</td>\n" +
    "            <td width=\"45%\">{{ task.summary }}</td>\n" +
    "            <td width=\"25%\" style=\"text-align: right;\">\n" +
    "                <div ng-if=\"!task.fail && task.finishTime\">\n" +
    "                    {{ task.operator }}\n" +
    "                    -\n" +
    "                    {{ task.finishTime | date:'yyyy-MM-dd HH:mm:ss' }}\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-error\" dialog-show=\"showErrorDialog\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" id=\"myModalLabel\">{{dict.pages.update.progress.error_occur}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <p>{{dict.pages.update.progress.current}} {{ currentTitle }}</p>\n" +
    "        <p>{{dict.pages.update.progress.err_msg_1}}</p>\n" +
    "        <p>{{dict.pages.update.progress.err_msg_2}}</p>\n" +
    "        <p>{{dict.pages.update.progress.err_msg_3}}</p>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-primary\" ng-click=\"hideDialog()\">{{dict.common.ok}}</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\" dialog-show=\"showConfirmDialog\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" id=\"confirmModalLabel\">{{dict.pages.update.progress.confirm_server_start}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <p>{{dict.pages.update.progress.confirm_server_start_msg}}</p>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">{{dict.common.ok}}</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showProgressRecord\" wide=\"true\" on-hide=\"goToNextPage()\">\n" +
    "    <div class=\"modal-header modal-header-primary\">\n" +
    "        <h4 class=\"modal-title\">Update process detail</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\" ng-if=\"showProgressRecord\" style=\"max-height: 500px; overflow: auto\">\n" +
    "        <table class=\"table table-condensed\">\n" +
    "            <tr ng-repeat-start=\"r in progressRecord\" ng-if=\"r.type === 'executor'\">\n" +
    "                <td>{{ r.time  | date:'HH:mm:ss' }}</td>\n" +
    "                <td>{{ r.host }}:{{ r.port }}</td>\n" +
    "                <td>{{ r.log }}</td>\n" +
    "            </tr>\n" +
    "            <tr ng-repeat-end ng-if=\"r.type === 'state'\">\n" +
    "                <td colspan=\"3\"><strong>{{ r.stateCap }}</strong></td>\n" +
    "            </tr>\n" +
    "        </table>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">{{dict.common.ok}}</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "");
}]);

angular.module("update/report/report.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/report/report.tpl.html",
    "<h2>{{dict.pages.update.report.title}} —— {{ env.companyName }}</h2>\n" +
    "<br>\n" +
    "<h4>{{dict.pages.update.report.version}}</h4>\n" +
    "<ul type=\"circle\">\n" +
    "    <li ng-repeat=\"v in ptfVersionLst\">{{v.name}}</li>\n" +
    "</ul>\n" +
    "\n" +
    "\n" +
    "<h4 ng-if=\"finished\">{{dict.pages.update.report.finished_time}} {{ finishTime | date:'yyyy-MM-dd HH:mm:ss' }}</h4>\n" +
    "<h4 ng-if=\"!finished\">{{dict.pages.update.report.unfinished_time}} {{ finishTime | date:'yyyy-MM-dd HH:mm:ss' }}</h4>\n" +
    "\n" +
    "<loading ng-hide=\"executorPlans\"></loading>\n" +
    "\n" +
    "<br>\n" +
    "<table class=\"report-table\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th>{{dict.pages.update.report.customer}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "    <tr>\n" +
    "        <td>{{ env.companyName }}</td>\n" +
    "    </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<table class=\"report-table\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th>{{dict.pages.update.report.operators}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "    <tr>\n" +
    "        <td ng-repeat=\"(operator, flag) in operatorMap\">\n" +
    "            <span>{{operator}}</span>\n" +
    "        </td>\n" +
    "    </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<table class=\"report-table\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th>{{dict.pages.update.report.env}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "    <tr>\n" +
    "        <td>{{ envStr(env) }}</td>\n" +
    "    </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<table class=\"report-table\">\n" +
    "    <thead>\n" +
    "    <tr>\n" +
    "        <th>{{dict.pages.update.report.before}}</th>\n" +
    "    </tr>\n" +
    "    </thead>\n" +
    "    <tbody>\n" +
    "    <tr>\n" +
    "        <td width=\"50%\">{{ preVersion }}</td>\n" +
    "    </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<div ng-repeat=\"executorPlan in executorPlans\">\n" +
    "    <table class=\"table plan-table\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th colspan=\"2\">{{ executorPlan.executor.host }}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody>\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.os_info}}</td>\n" +
    "        </tr>\n" +
    "        <tr>\n" +
    "            <td width=\"20%\">OS</td>\n" +
    "            <td width=\"80%\">{{ executorPlan.executor.os.name }} ({{ executorPlan.executor.os.arch }})</td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.mid_info}}</td>\n" +
    "        </tr>\n" +
    "        <tr ng-repeat=\"(serverType,valueMap) in executorPlan.executor.middlewareInfo\">\n" +
    "            <td>{{ serverTypeDict(serverType) }}</td>\n" +
    "            <td>\n" +
    "                <table width=\"100%\">\n" +
    "                    <tr ng-repeat=\"(name,value) in valueMap\">\n" +
    "                        <td width=\"30%\"> {{ name }}</td>\n" +
    "                        <td> {{ value }}</td>\n" +
    "                    </tr>\n" +
    "                </table>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr class=\"target-header\">\n" +
    "            <td colspan=\"2\">{{dict.pages.update.plan.mid_config}}</td>\n" +
    "        </tr>\n" +
    "        <tr ng-repeat=\"(serverType,valueMap) in executorPlan.executor.configuration\">\n" +
    "            <td>{{ serverTypeDict(serverType) }}</td>\n" +
    "            <td>\n" +
    "                <table width=\"100%\">\n" +
    "                    <tr ng-repeat=\"(name,value) in valueMap | configForDisplay\">\n" +
    "                        <td width=\"30%\"> {{ dict.pages.config.environments.one.server[name].title }}</td>\n" +
    "                        <td ng-if=\"name.indexOf('PASS') >= 0 \">***</td>\n" +
    "                        <td ng-if=\"name.indexOf('PASS') < 0 \"> {{ value }}</td>\n" +
    "                    </tr>\n" +
    "                </table>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "\n" +
    "<div ng-repeat=\"executorPlan in executorPlans\">\n" +
    "    <!--<h3>Host : {{ executorPlan.executor.host }}</h3>-->\n" +
    "    <table class=\"table table-hover plan-table\">\n" +
    "        <thead>\n" +
    "        <tr>\n" +
    "            <th colspan=\"5\">{{ executorPlan.executor.host }}</th>\n" +
    "        </tr>\n" +
    "        </thead>\n" +
    "        <tbody ng-repeat=\"(phase, tasks) in executorPlan.taskInfo\" ng-if=\"tasks && tasks.length > 0\">\n" +
    "\n" +
    "        <tr class=\"stage-header\">\n" +
    "            <td colspan=5>\n" +
    "                {{ dict.phaseName[$index] }}\n" +
    "                <span class=\"label label-info\" ng-if=\"phase === 1\">{{ dict.pages.update.plan.manual_label }}</span>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr ng-repeat-start=\"task in tasks\"\n" +
    "            class=\"task\" ng-class=\"{\n" +
    "                'success': task.finishType == 'success',\n" +
    "                'warning': task.finishType == 'ignore' || task.finishType == 'continue',\n" +
    "                'danger': task.fail}\">\n" +
    "\n" +
    "            <td width=\"20%\">{{ task.title }}</td>\n" +
    "            <td width=\"40%\">{{ task.summary }}</td>\n" +
    "            <td width=\"20%\">{{ task.finishTime | date:'yyyy-MM-dd HH:mm:ss' }}</td>\n" +
    "\n" +
    "            <td width=\"10%\" ng-switch=\"task.fail || task.finishType\">\n" +
    "                <span ng-switch-when=\"true\">{{dict.pages.update.report.state_fail}}</span>\n" +
    "                <span ng-switch-when=\"success\">{{dict.pages.update.report.state_success}}</span>\n" +
    "                <span ng-switch-when=\"ignore\">{{dict.pages.update.report.state_ignore}}</span>\n" +
    "                <span ng-switch-when=\"continue\">{{dict.pages.update.report.state_continue}}</span>\n" +
    "                <span ng-switch-default></span>\n" +
    "            </td>\n" +
    "            <td width=\"10%\">{{ task.operator }}</td>\n" +
    "        </tr>\n" +
    "\n" +
    "        <tr ng-repeat-end\n" +
    "            ng-if=\"task.reportCheckResults && isArray(task.reportCheckResults) && task.reportCheckResults.length > 0\">\n" +
    "            <td colspan=\"5\">\n" +
    "                <div style=\"width: 100%;\">\n" +
    "                    <table ng-repeat=\"reportResult in task.reportCheckResults track by $index\" style=\"width: 100%\"\n" +
    "                           class=\"table plan-table\" width=\"100%\">\n" +
    "                        <tr ng-repeat=\"item in reportResult\" width=\"100%\">\n" +
    "                            <td ng-if=\"!item[1]\" colspan=\"5\" style=\"word-break:break-all; word-wrap:break-all;\">\n" +
    "                                <div style=\"white-space: pre-wrap\">{{ item[0] }}</div>\n" +
    "                            </td>\n" +
    "                            <td ng-if=\"item[1]\" width=\"50%\" style=\"word-break:break-all; word-wrap:break-all;\"> {{\n" +
    "                                item[0] }}\n" +
    "                            </td>\n" +
    "                            <td ng-if=\"item[1] && !item[2]\" colspan=\"4\"\n" +
    "                                style=\"word-break:break-all; word-wrap:break-all;\">{{ item[1] }}\n" +
    "                            </td>\n" +
    "                            <td ng-if=\"item[2]\" width=\"10%\" style=\"word-break:break-all; word-wrap:break-all;\">{{\n" +
    "                                item[1] }}\n" +
    "                            </td>\n" +
    "                            <td ng-if=\"item[2]\" width=\"40%\" style=\"word-break:break-all; word-wrap:break-all;\">{{\n" +
    "                                item[2] }}\n" +
    "                            </td>\n" +
    "                        </tr>\n" +
    "                    </table>\n" +
    "                </div>\n" +
    "            </td>\n" +
    "        </tr>\n" +
    "\n" +
    "        </tbody>\n" +
    "    </table>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\" ng-if=\"finished\">\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"finish()\">{{dict.common.finish}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"print()\">{{dict.common.print}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"downloadXMLReport()\">{{dict.pages.update.report.generate_xml_report_btn}}</button>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"bottom-btn-div\" ng-if=\"!finished\">\n" +
    "    <button class=\"btn btn-default\" ng-click=\"goBack()\">{{dict.common.back}}</button>\n" +
    "    <button class=\"btn btn-primary\" ng-click=\"print()\">{{dict.common.print}}</button>\n" +
    "</div>");
}]);

angular.module("update/selfUp/selfUp.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/selfUp/selfUp.tpl.html",
    "<dirty-handler handler=\"onDirty\"></dirty-handler>\n" +
    "<h2>{{dict.pages.config.self_update.title}}</h2>\n" +
    "\n" +
    "<!--<div class=\"row\">-->\n" +
    "<!--<div class=\"col-md-4\">-->\n" +
    "<!--<ul class =\"nav nav-pills nav-stacked\" id=\"server-list\">-->\n" +
    "<!--<li ng-repeat=\"c in ciu\">-->\n" +
    "<!--<a ng-click=\"selfUpdate(c)\">-->\n" +
    "<!--<div class = \"ip\"> Self update {{c}} </div>-->\n" +
    "<!--</a>-->\n" +
    "<!--</li>-->\n" +
    "<!--</ul>-->\n" +
    "<!--</div>-->\n" +
    "<!--</div>-->\n" +
    "\n" +
    "<div class=\"row\">\n" +
    "    <div class=\"col-md-4\">\n" +
    "        <h4>{{dict.pages.config.self_update.versions.current}}</h4>\n" +
    "        <loading ng-hide=\"current\"></loading>\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"well\" ng-if=\"current\">\n" +
    "                <dl>\n" +
    "                    <dt>{{dict.pages.config.self_update.versions.version_number}}</dt>\n" +
    "                    <dd>{{current.name}}</dd>\n" +
    "                    <dt>{{dict.pages.config.self_update.versions.release_date}}</dt>\n" +
    "                    <dd>{{current.releaseDate}}</dd>\n" +
    "                </dl>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"col-md-2\"></div>\n" +
    "\n" +
    "    <div class=\"col-md-6\">\n" +
    "        <h4>{{dict.pages.config.self_update.versions.latest}}</h4>\n" +
    "        <loading ng-hide=\"latest\"></loading>\n" +
    "        <div class=\"well row\" ng-if=\"latest\">\n" +
    "            <div class=\"col-md-7\">\n" +
    "                <dl>\n" +
    "                    <dt>{{dict.pages.config.self_update.versions.version_number}}</dt>\n" +
    "                    <dd>{{latest.name}}</dd>\n" +
    "                    <dt>{{dict.pages.config.self_update.versions.release_date}}</dt>\n" +
    "                    <dd>{{latest.releaseDate}}</dd>\n" +
    "                </dl>\n" +
    "            </div>\n" +
    "\n" +
    "            <div  class=\"col-md-5\">\n" +
    "                <button ng-if =\"!latest.remoteResource\" class=\"btn btn-primary btn-sm self_update_button\" ng-click = \"selfUpdate(latest.name)\" ng-disabled = \"current.name == latest.name\"  >\n" +
    "                    {{dict.pages.config.self_update.versions.update_button}}\n" +
    "                </button>\n" +
    "            </div>\n" +
    "\n" +
    "            <div  class=\"col-md-5\">\n" +
    "                <button ng-if =\"latest.remoteResource\" class=\"btn btn-primary btn-sm self_update_button\" ng-click = \"downloadCiu(latest.name)\" ng-disabled = \"current.name == latest.name\"  >\n" +
    "                    {{dict.pages.config.self_update.versions.download_button}}\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showSelfUpd\" on-hide=\"\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.update.versions.self_dlg_2.header}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3>{{dict.pages.update.versions.self_dlg_2.p}}</h3>\n" +
    "\n" +
    "        <div class=\"progress progress-striped active\">\n" +
    "            <div class=\"progress-bar\" role=\"progressbar\" style=\"width:100%;\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-error\" dialog-show=\"showErrorDialog\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" id=\"myModalLabel\">{{dict.pages.update.progress.error_occur}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <pre ng-repeat=\"selfUpErrorInfo in selfUpdateErrorList\">\n" +
    "            {{selfUpErrorInfo}}\n" +
    "        </pre>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-primary\" ng-click=\"hideDialog()\">{{dict.common.ok}}</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showDownload\" on-hide=\"\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.update.versions.download_title}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3>{{dict.pages.update.versions.download_progress}}</h3>\n" +
    "\n" +
    "        <div class=\"progress progress-striped active\">\n" +
    "            <div class=\"progress-bar\" role=\"progressbar\" style=\"width:100%;\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</dialog>");
}]);

angular.module("update/update.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/update.tpl.html",
    "<!-- Fixed header -->\n" +
    "<div class=\"navbar navbar-default navbar-fixed-top unselectable\" ng-class=\"{'production' : updateData.env.type===1}\"\n" +
    "     ng-class=\"environment.toLowerCase()\" role=\"navigation\">\n" +
    "    <div class=\"container\">\n" +
    "        <div class=\"navbar-header\">\n" +
    "            <a class=\"navbar-brand\">COMPANY UPDATER</a>\n" +
    "        </div>\n" +
    "        <ul class=\"nav navbar-nav\">\n" +
    "            <li><a ui-sref=\"update.environments\">{{dict.pages.config.environments.title}}</a></li>\n" +
    "            <li><a ng-if=\"!hide_self_up\" ui-sref=\"update.selfUp\">{{dict.pages.config.self_update.title}}</a></li>\n" +
    "        </ul>\n" +
    "        <div class=\"navbar-collapse collapse\">\n" +
    "            <ul class=\"nav navbar-nav navbar-right\">\n" +
    "                <li ng-show=\"updateData.env\">\n" +
    "                    <a ng-click=\"resetEnv()\" style=\"cursor:pointer\"><span class=\"glyphicon glyphicon-globe\"></span>\n" +
    "                        {{ envStr(updateData.env) }}\n" +
    "                    </a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <a ng-click=\"generateCUlogs()\"><span class=\"glyphicon glyphicon-th\"></span></a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <a ng-click=\"changeUserPass()\"><span class=\"glyphicon glyphicon-user\"></span> {{ user.realName + '(' + user.username + ')'}}</a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <a ng-click=\"changeSupportPass()\"><span class=\"glyphicon glyphicon-lock\"></span></a>\n" +
    "                </li>\n" +
    "                <li>\n" +
    "                    <!--<a ng-click=\"showPullDownMenu()\"><span class=\"glyphicon glyphicon-align-right\"></span></a>-->\n" +
    "                    <a ng-href=\"/logout\"><span class=\"glyphicon glyphicon-align-right\"></span></a>\n" +
    "                </li>\n" +
    "            </ul>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"container\" ng-show=\"currentStep > 0\">\n" +
    "    <div class=\"row\">\n" +
    "        <progress-track current=\"currentStep\" steps=\"dict.pages.update.steps\">\n" +
    "        </progress-track>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"container\" ui-view>\n" +
    "    Loading update page... please wait\n" +
    "</div>");
}]);

angular.module("update/versions/versions.tpl.html", []).run(["$templateCache", function($templateCache) {
  $templateCache.put("update/versions/versions.tpl.html",
    "<h2>{{dict.pages.update.versions.title}}</h2>\n" +
    "\n" +
    "<div class=\"row\">\n" +
    "    <div class=\"col-md-4\">\n" +
    "        <div class=\"row\">\n" +
    "            <h4>{{dict.pages.update.versions.current}}</h4>\n" +
    "            <loading ng-hide=\"current\"></loading>\n" +
    "            <div class=\"well\" ng-hide=\"!current\">\n" +
    "                <dl ng-if=\"current.name!='CGP0'\">\n" +
    "                    <dt>{{dict.pages.update.versions.v_num}}</dt>\n" +
    "                    <dd>{{ current.name }}</dd>\n" +
    "                    <dt>{{dict.pages.update.versions.update_date}}</dt>\n" +
    "                    <dd>{{ current.updateDate }}</dd>\n" +
    "                </dl>\n" +
    "                <dl ng-if=\"current.name=='CGP0'\">\n" +
    "                    <dt>{{dict.pages.update.prods.table.not_applied_yet}}</dt>\n" +
    "                </dl>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div class=\"row\" ng-if=\"lastUpdate && lastUpdate.version.name!='CGP0'\">\n" +
    "            <h4>{{dict.pages.update.versions.last}}</h4>\n" +
    "            <loading ng-hide=\"lastUpdate\"></loading>\n" +
    "            <div class=\"well\" ng-hide=\"!lastUpdate\">\n" +
    "                <dl>\n" +
    "                    <dt>{{dict.pages.update.versions.v_num}}</dt>\n" +
    "                    <dd>{{ lastUpdate.version.name }}</dd>\n" +
    "                    <dt>{{dict.pages.update.versions.update_date}}</dt>\n" +
    "                    <dd>{{ lastUpdate.updateDate }}</dd>\n" +
    "                    <dt>{{dict.pages.update.versions.result}}</dt>\n" +
    "                    <dd>{{ lastUpdate.success ? dict.common.success : dict.common.fail }}</dd>\n" +
    "                    <dt>{{dict.pages.update.versions.msg}}</dt>\n" +
    "                    <dd>\n" +
    "                        <p ng-if=\" lastUpdate.operations.length === 0\">{{dict.pages.update.versions.no_msg}}</p>\n" +
    "\n" +
    "                        <p ng-if=\" lastUpdate.operations.length > 0\" ng-repeat=\" o in lastUpdate.operations\">\n" +
    "                            {{ o.updateTime }} {{ o.operator.realName }} : {{ o.message }}\n" +
    "                        </p>\n" +
    "                    </dd>\n" +
    "                </dl>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"col-md-2\">\n" +
    "    </div>\n" +
    "    <div class=\"col-md-6\">\n" +
    "        <div>\n" +
    "            <h4 ng-show=\"(downloadableVersions.length > 1 && isDownloable)||(mergeableVersions.length > 1 && !isDownloable)\">\n" +
    "                {{isDownloable ? dict.pages.update.versions.multiple_download : dict.pages.update.versions.multiple_merge}}\n" +
    "            </h4>\n" +
    "            <div class=\"form-inline\">\n" +
    "                <div class=\"well row one_version form-group\" ng-show=\"(downloadableVersions.length > 1 && isDownloable)||(mergeableVersions.length > 1 && !isDownloable)\">\n" +
    "                    <label ng-if=\"selectedLanguage==='en'\" style=\"text-align:center\">{{dict.pages.update.versions.up_to}}</label>\n" +
    "                    <select class=\"form-control\" style=\"width:220px; max-width:250px;\" ng-show=\"isDownloable\"\n" +
    "                            ng-options=\"version.name for version in downloadableVersions | filter: '!pre'\"\n" +
    "                            ng-model=\"selectedVersion\">\n" +
    "                    </select>\n" +
    "                    <select class=\"form-control\" style=\"width:220px; max-width:250px;\" ng-hide=\"isDownloable\"\n" +
    "                            ng-options=\"version.name for version in mergeableVersions | filter: '!pre'\"\n" +
    "                            ng-model=\"selectedVersion\">\n" +
    "                    </select>\n" +
    "                    <label ng-if=\"selectedLanguage==='ja'\" style=\"text-align:center\">{{dict.pages.update.versions.up_to}}</label>\n" +
    "                    <button style=\"float: right;\" class=\"btn btn-primary btn-sm form-control\" ng-show=\"isDownloable\"\n" +
    "                            ng-click=\"startMultiDownload()\">{{dict.pages.update.versions.download}}\n" +
    "                    </button>\n" +
    "                    <button style=\"float: right;\" class=\"btn btn-primary btn-sm form-control\" ng-hide=\"isDownloable\"\n" +
    "                            ng-click=\"startMergeVersions()\">{{dict.pages.update.versions.start_merge}}\n" +
    "                    </button>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "            <h4 ng-if=\"mergedAvailableVersions.length > 0\">{{dict.pages.update.versions.multiple_update}}</h4>\n" +
    "            <div class=\"well row one_version\" ng-repeat=\"ver in mergedAvailableVersions\" >\n" +
    "                <div class=\"col-md-10\">\n" +
    "                    <!--ng-mouseleave=\"hideSelectText(v)\" ng-mouseenter=\"showSelectText(v)\"  title=\"{{v.title}}\"-->\n" +
    "                    <dl>\n" +
    "                        <dt>{{dict.pages.update.versions.version_after_update}}</dt>\n" +
    "                        <dd>{{ ver.name }}</dd>\n" +
    "                    </dl>\n" +
    "                        <button class=\"btn btn-info btn-sm\" ng-click=\"showAllVersions()\">\n" +
    "                            {{dict.pages.update.versions.show_included_versions}}\n" +
    "                        </button>\n" +
    "                        <table class=\"table table-responsive\" ng-show=\"isShowAllVersions\">\n" +
    "                            <thead>\n" +
    "                            <tr>\n" +
    "                                <th>{{dict.pages.update.versions.v_num}}</th>\n" +
    "                                <th>{{dict.pages.update.versions.release_date}}</th>\n" +
    "                                <th>{{dict.pages.update.versions.detail}}</th>\n" +
    "                                <th>{{dict.pages.update.versions.procedure}}</th>\n" +
    "                            </tr>\n" +
    "                            </thead>\n" +
    "                            <tbody ng-repeat=\"v in ver.includedVersionLst\">\n" +
    "                            <tr>\n" +
    "                                <td scope=\"row\"> {{ v.name }}</td>\n" +
    "                                <td>{{ v.releaseDate }}</td>\n" +
    "                                <td>\n" +
    "                                    <a ng-click=\"openMergedDoc(v)\" class=\"one_version_link\" target=\"_blank\">\n" +
    "                                        html\n" +
    "                                    </a>\n" +
    "                                </td>\n" +
    "                                <td>\n" +
    "                                    <a ng-click=\"openMergedMan(v)\" class=\"one_version_link\" target=\"_blank\">\n" +
    "                                        zip\n" +
    "                                    </a>\n" +
    "                                </td>\n" +
    "                            </tr>\n" +
    "                            </tbody>\n" +
    "                        </table>\n" +
    "                </div>\n" +
    "                <div class=\"col-md-2 tooltip-container\">\n" +
    "                    <!--<a ng-click=\"openDoc(ver)\" class=\"one_version_link\" target=\"_blank\">-->\n" +
    "                        <!--{{dict.pages.update.versions.detail}} (html)-->\n" +
    "                    <!--</a>-->\n" +
    "                    <button class=\"btn btn-primary btn-sm one_version_link\" ng-click=\"startBtnClick(ver)\"\n" +
    "                            ng-disabled=\"!ver.currentUserAccessible || disableButton || waitForRetry\">\n" +
    "                        {{dict.pages.update.versions.select}}\n" +
    "                    </button>\n" +
    "                    <span ng-if=\"!waitForRetry && ver.title\" class=\"tooltip-text\">{{ver.title}}</span>\n" +
    "                    <span ng-if=\"waitForRetry\" class=\"tooltip-text\">{{dict.pages.update.versions.connect_error}}</span>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <h4 ng-if=\"available.length > 0\">{{dict.pages.update.versions.available}}</h4>\n" +
    "        <loading ng-hide=\"current\"></loading>\n" +
    "        <div class=\"well row one_version\" ng-repeat=\"v in available\" >\n" +
    "            <div class=\"col-md-7\">\n" +
    "                <!--ng-mouseleave=\"hideSelectText(v)\" ng-mouseenter=\"showSelectText(v)\"  title=\"{{v.title}}\"-->\n" +
    "                <dl>\n" +
    "                    <dt>{{dict.pages.update.versions.v_num}}</dt>\n" +
    "                    <dd>{{ v.name }}</dd>\n" +
    "                    <dt>{{dict.pages.update.versions.release_date}}</dt>\n" +
    "                    <dd>{{ v.releaseDate }}</dd>\n" +
    "                </dl>\n" +
    "            </div>\n" +
    "            <div class=\"col-md-5 tooltip-container\">\n" +
    "                <a ng-if =\"!v.remoteResource\" ng-click=\"openDoc(v)\" class=\"one_version_link\" target=\"_blank\">\n" +
    "                    {{dict.pages.update.versions.detail}} (html)\n" +
    "                </a>\n" +
    "                <a ng-if =\"!v.remoteResource\" ng-click=\"openMan(v)\" class=\"one_version_link\" target=\"_blank\">\n" +
    "                    {{dict.pages.update.versions.procedures_download}} (zip)\n" +
    "                </a>\n" +
    "                <span ng-if =\"v.remoteResource\"  style=\"float:right\">\n" +
    "                    {{dict.pages.update.versions.remote_resource}}\n" +
    "                </span>\n" +
    "                <button ng-if =\"!v.remoteResource\" class=\"btn btn-primary btn-sm one_version_link\" ng-click=\"startBtnClick(v)\"\n" +
    "                        ng-disabled=\"!v.currentUserAccessible || disableButton || waitForRetry\">\n" +
    "                    {{dict.pages.update.versions.select}}\n" +
    "                </button>\n" +
    "                <span ng-if=\"!waitForRetry && v.title\" class=\"tooltip-text\">{{v.title}}</span>\n" +
    "                <span ng-if=\"waitForRetry\" class=\"tooltip-text\">{{dict.pages.update.versions.connect_error}}</span>\n" +
    "\n" +
    "                <button ng-if =\"v.remoteResource\" class=\"btn btn-primary btn-sm one_version_link\" ng-click=\"downloadBtnClick(v)\"\n" +
    "                        ng-disabled=\"!v.currentUserAccessible\">\n" +
    "                    {{dict.pages.update.versions.download}}\n" +
    "                </button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "        <div>\n" +
    "            <h4>{{dict.pages.update.versions.debug_options.title}}</h4>\n" +
    "            <div class=\"well row one_version\">\n" +
    "                <div class=\"checkbox\" ng-if=\"!test\" class=\"debug-item\">\n" +
    "                    <label>\n" +
    "                        <input type=\"checkbox\" ng-model=\"debugState['NOT_SERVER_START_DOWN']\" ng-change=\"updateDebugState()\"/>\n" +
    "                        <span>{{dict.pages.update.versions.debug_options[\"NOT_SERVER_START_DOWN\"]}}</span>\n" +
    "                    </label>\n" +
    "                </div>\n" +
    "                <div class=\"checkbox\" ng-if=\"!test\" class=\"debug-item\">\n" +
    "                    <label>\n" +
    "                        <input type=\"checkbox\" ng-model=\"debugState['NOT_BACKUP']\" ng-change=\"updateDebugState()\"/>\n" +
    "                        <span>{{dict.pages.update.versions.debug_options[\"NOT_BACKUP\"]}}</span>\n" +
    "                    </label>\n" +
    "                </div>\n" +
    "                <div ng-repeat=\"(state, value) in debugState\" class=\"debug-item\" ng-if=\"test\">\n" +
    "                    <div class=\"checkbox\">\n" +
    "                        <label>\n" +
    "                            <input type=\"checkbox\" ng-model=\"debugState[state]\" ng-change=\"updateDebugState()\"/>\n" +
    "                            <span>{{dict.pages.update.versions.debug_options[state]}}</span>\n" +
    "                        </label>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</div>\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showProgress\" on-hide=\"goToPlanPageIfSuccess()\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.update.versions.process_dlg.header}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3>{{dict.pages.update.versions.process_dlg[progress]}}</h3>\n" +
    "        <progress-bar current=\"progressNow\" total=\"7\"></progress-bar>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showDownload\" on-hide=\"\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" ng-if=\"downloadStatus === 'Downloading'\">{{dict.pages.update.versions.download_title}}</h4>\n" +
    "        <h4 class=\"modal-title\" ng-if=\"downloadStatus === 'Merging'\">{{dict.pages.update.versions.merge_title}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3 ng-if=\"downloadStatus === 'Downloading'\">{{dict.pages.update.versions.download_progress}}</h3>\n" +
    "        <h3 ng-if=\"downloadStatus === 'Merging'\">{{dict.pages.update.versions.merge_progress}}</h3>\n" +
    "        <h4 ng-if=\"downloadStatus === 'Downloading'\">{{dspDownloadProgress}}</h4>\n" +
    "        <h4 ng-if=\"downloadStatus === 'Merging'\">{{mergeTimeMsg}}</h4>\n" +
    "        <div class=\"progress progress-striped active\">\n" +
    "            <div class=\"progress-bar\" role=\"progressbar\" style=\"width:100%;\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\" dialog-show=\"showUpgradeCiuDialog\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" id=\"myModalLabel\">{{dict.pages.update.versions.self_dlg_2.header}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <div class=\"row\">\n" +
    "            <div class=\"col-md-12\">\n" +
    "                <h4>{{dict.pages.config.self_update.versions.latest}}</h4>\n" +
    "                <loading ng-hide=\"ciulatest\"></loading>\n" +
    "                <div class=\"well row\" ng-if=\"ciulatest\">\n" +
    "                    <div class=\"col-md-7\">\n" +
    "                        <dl>\n" +
    "                            <dt>{{dict.pages.config.self_update.versions.version_number}}</dt>\n" +
    "                            <dd>{{ciulatest.name}}</dd>\n" +
    "                            <dt>{{dict.pages.config.self_update.versions.release_date}}</dt>\n" +
    "                            <dd>{{ciulatest.releaseDate}}</dd>\n" +
    "                        </dl>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div  class=\"col-md-5\">\n" +
    "                        <button ng-if =\"!ciulatest.remoteResource\" class=\"btn btn-primary btn-sm self_update_button\" ng-click = \"selfUpdate(ciulatest.name)\" ng-disabled = \"ciucurrent.name == ciulatest.name\"  >\n" +
    "                            {{dict.pages.config.self_update.versions.update_button}}\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div  class=\"col-md-5\">\n" +
    "                        <button ng-if =\"ciulatest.remoteResource\" class=\"btn btn-primary btn-sm self_update_button\" ng-click = \"downloadCiu(ciulatest.name)\" ng-disabled = \"ciucurrent.name == ciulatest.name\"  >\n" +
    "                            {{dict.pages.config.self_update.versions.download_button}}\n" +
    "                        </button>\n" +
    "                    </div>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-default\" ng-click=\"hideUpgradeCiuDialog()\">{{dict.common.cancel}}</button>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-primary\"\n" +
    "        dialog-show=\"showSelfUpd\" on-hide=\"\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\">{{dict.pages.update.versions.self_dlg_2.header}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <h3>{{dict.pages.update.versions.self_dlg_2.p}}</h3>\n" +
    "\n" +
    "        <div class=\"progress progress-striped active\">\n" +
    "            <div class=\"progress-bar\" role=\"progressbar\" style=\"width:100%;\"></div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</dialog>\n" +
    "\n" +
    "<dialog class=\"dialog-color dialog-error\" dialog-show=\"showErrorDialog\">\n" +
    "    <div class=\"modal-header\">\n" +
    "        <h4 class=\"modal-title\" id=\"myCiuModalLabel\">{{dict.pages.update.progress.error_occur}}</h4>\n" +
    "    </div>\n" +
    "    <div class=\"modal-body\">\n" +
    "        <pre ng-repeat=\"selfUpErrorInfo in selfUpdateErrorList\">\n" +
    "            {{selfUpErrorInfo}}\n" +
    "        </pre>\n" +
    "    </div>\n" +
    "    <div class=\"modal-footer\">\n" +
    "        <button type=\"button\" class=\"btn btn-primary\" ng-click=\"hideDialog()\">{{dict.common.ok}}</button>\n" +
    "    </div>\n" +
    "</dialog>");
}]);

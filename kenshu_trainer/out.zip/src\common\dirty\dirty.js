angular.module('dirty', ['uiTools', 'ui.router'])
  .factory('dirtyCheckService', function () {
    var map = {};
    var idCounter = 0;
    var add = function (obj) {
      idCounter++;
      map[idCounter] = {
        ori: angular.toJson(obj),
        dirty: false
      };
      return idCounter;
    };
    var remove = function (id) {
      delete map[id];
    };
    var check = function (id, obj) {
      if (map[id]) {
        map[id].dirty = angular.toJson(obj) !== map[id].ori;
        return map[id].dirty;
      }
    };
    var dirty = function () {
      for (var i in map) {
        if (map[i].dirty) {
          return true;
        }
      }
      return false;
    };

    return {
      add: add,
      remove: remove,
      check: check,
      dirty: dirty
    };
  })
  .directive('dirtyCheck', ["dirtyCheckService", function (dirtyCheckService) {

    var link = function (scope, element) {
      scope.dirty = false;

      var id = dirtyCheckService.add(scope.dirtyCheck || scope.model);

      scope.$watch(scope.dirtyCheck ? 'dirtyCheck' : 'model', function (newValue) {
          scope.dirty = dirtyCheckService.check(id, newValue);
          if (scope.dirty) {
            element.addClass('dirty');
          } else {
            element.removeClass('dirty');
          }
        }, true
      );

      scope.$on('$destroy',
        function () {
          dirtyCheckService.remove(id);
        });
    };

    return {
      restrict: 'AE',
      link: link,
      scope: {
        model: '=',
        dirtyCheck: '='
      }
    };
  }])
  .
  directive('dirtyHandler', ["dirtyCheckService", "$state", function (dirtyCheckService, $state) {
    var link = function (scope) {

      var off = scope.$on('$stateChangeStart',
        function (event, toState, toParams) {
          if (dirtyCheckService.dirty()) {
            event.preventDefault();
            scope.handler().then(function () {
              off();
              $state.go(toState, toParams);
            });
          }
        });

      window.onbeforeunload = function(e) {
        console.log(e);
        if (dirtyCheckService.dirty()) {
          return "unsaved change";
        }
      };

    };
    return {
      restrict: 'E',
      link: link,
      scope: {
        handler: '='
      }
    };
  }]);
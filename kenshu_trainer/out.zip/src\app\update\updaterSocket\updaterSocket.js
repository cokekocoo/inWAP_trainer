angular.module('updater.update.socket', [])
  .factory('ws', ["$http", function ($http) {
    var stompClient;
    var timeOut = 5000;
    var stop = false;

    var connect = function () {
      console.log('updater web socket connect');
      var socket = new SockJS("/updaterSocket");

      stompClient = Stomp.over(socket);
      stompClient.debug = null;

      stompClient.connect({}, function () {

        stompClient.subscribe('/topic/state', function (msg) {
          var data = JSON.parse(msg.body);
          addLog(data);
          if (stateListener) {
            stateListener(data);
          }
        });

        stompClient.subscribe('/topic/progress', function (msg) {
          var data = JSON.parse(msg.body);
          addLog(data);
          if (progressListener) {
            progressListener(data);
          }
        });

        stompClient.subscribe('/topic/success', function (msg) {
          var data = JSON.parse(msg.body);
          addLog(data);
          if (successListener) {
            successListener(data);
          }
        });

        stompClient.subscribe('/topic/multiple_progress', function (msg) {
            var data = JSON.parse(msg.body);
            if (multipleApplyListener) {
                multipleApplyListener(data);
            }
        });

        stompClient.subscribe('/topic/error', function (msg) {
          var error = JSON.parse(msg.body);
          if (errorListener) {
            errorListener(error);
          }
        });

        stompClient.subscribe('/topic/connect', function (msg) {
          var error = JSON.parse(msg.body);
          if (connectListener) {
            connectListener(error);
          }
        });

        stompClient.subscribe('/topic/adminLogin', function (msg) {
          var data = msg.body;
          if (adminLoginListener) {
            adminLoginListener(data);
          }
        });
        $('#connecting').hide();
      }, function () {
        if (!stop) {
          console.log("Web socket fail, reconnect now");
          $('#connecting').show();
          reconnect();
        }
      });
    };

    var reconnect = function() {
      $http.get('/users/login').then(function () {
        connect();
        location.reload();
      }, function() {
        setTimeout(reconnect, timeOut);
      });
    };

    var stateListener = null;
    var progressListener = null;
    var successListener = null;
    var multipleApplyListener = null;
    var errorListener = null;
    var connectListener = null;
    var progressRecord = [];

    var addLog = function (data) {
      if (data && data.n === progressRecord.length) {
        progressRecord.push(data);
      } else {
        $http.get('/progress_log').success(function (data) {
          progressRecord.splice(0, progressRecord.length);
          for (var i = 0; i < data.length; i++) {
            progressRecord.push(data[i]);
          }
        });
      }
    };

    var socketManager = {
      setStateListener: function (f) {
        stateListener = f;
        return this;
      },
      setProgressListener: function (f) {
        progressListener = f;
        return this;
      },
      setSuccessListener: function (f) {
        successListener = f;
        return this;
      },
      setMultipleApplyListener:function(f){
          multipleApplyListener = f;
          return this;
      },
      setErrorListener: function (f) {
        errorListener = f;
        return this;
      },
      setConnectListener: function (f) {
        connectListener = f;
        return this;
      },
      setAdminLoginListener: function (f) {
        adminLoginListener = f;
        return this;
      },
      reset: function () {
        stateListener = null;
        progressListener = null;
        errorListener = null;
        connectListener = null;
        multipleApplyListener = null;
        return this;
      },
      resetProgress: function () {
        progressRecord.splice(0, progressRecord.length);
      },
      getProgress: function () {
        return progressRecord;
      },
      connect: connect,
      stop: function () {
        stop = true;
        if (stompClient) {
          stompClient.disconnect();
        }
      }
    };
    addLog();

    return socketManager;
  }]);
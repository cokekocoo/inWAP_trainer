angular.module('updater.config.env.one', ['ui.router', 'uiTools', 'angularFileUpload', 'helpText'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('config.env.one', {
      url: '/one/:id',
      controller: 'configEnvOneCtrl',
      templateUrl: 'config/env/one/one.tpl.html',
      data: {}
    });
  }])
  .run(["$anchorScroll", function ($anchorScroll) {
    $anchorScroll.yOffset = 70; // $bootstrap-nav-padding
  }])
  .controller('configEnvOneCtrl', ["$scope", "$http", "$state", "$stateParams", "$window", "$anchorScroll", "$location", "uiTools", function ($scope, $http, $state, $stateParams, $window, $anchorScroll, $location, uiTools) {
    $scope._ = $window._;
    // build empty configurations
    var configKeys = $scope.configKeys = {
      'CPY_BATCH': ['HOME'],
      'CPY_CAB': ['HOME'],
      'CWS_AP': ['HOME', 'PROFILE_ROOT', 'ENTERPRISE_APNAME', 'AP_EAR_NAME', 'STANDBY'],
      'CWS_WEB': ['HOME', "IHS_SERVICE_NAME", 'DOC_ROOT', 'STANDBY'],
      'CWS_DB': ['SYS_DBA', 'SYS_DBA_PASS', 'CWS_INITIALIZE'],
      'CWS_DL': ['HOME', 'CONTROL_TYPE'],
      'CWS_DL_ADMIN': ['HOME', 'CONTROL_TYPE'],
      'VER_AP': ['HOME', 'PROFILE_ROOT', 'ENTERPRISE_APNAME', 'AP_EAR_NAME', 'STANDBY'],
      'VER_WEB': ['HOME', "IHS_SERVICE_NAME", 'DOC_ROOT', 'STANDBY'],
      'VER_DB': ['SYS_DBA', 'SYS_DBA_PASS'],
      'VER_DAEMON': ['HOME'],
      'SRLT_CL': ['HOME'],
       // for csr time data exe,added by Tamagawa_s
       'CSR_TDIMP': ['HOME']
    };
    $scope.errorMsg = [];
    $scope.addTypes = Object.keys(configKeys).reduce(function (types, i) {
      var p = i.indexOf('_');
      var productCode = i.substring(0, p);
      var serverName = i.substring(p + 1);
      types[productCode] = types[productCode] || [];
      types[productCode].push(serverName);
      return types;
    }, {});
    var dbSchemaKeys = $scope.dbSchemaKeys = ['DB_URL', 'DB_USER', 'DB_PASS', 'EXP_USER', 'EXP_PASS','EXP_DIRECTORY_OBJECT_NAME'];
    var schemas = {
      'CWS_DB': ['S_CWS'],
      'VER_DB': ['S_CJK_COM']
    };
    var buildEmptyServer = function (serverType) {
      var temp = {};
      configKeys[serverType].forEach(function (e) {
        temp[e] = '';
      });
      return temp;
    };
    var buildEmptyDB = function (serverType) {
      var temp = {};
      schemas[serverType].forEach(function (e) {
        temp[e] = {};
        dbSchemaKeys.forEach(function (k) {
          temp[e][k] = '';
        });
      });
      return temp;
    };
    // load data
    $scope.env_id = $stateParams.id;
    $scope.loadEnvironment = function () {
      return $http.get('/admin/environments/' + $scope.env_id).success(function (environment) {
        $scope.environment = environment;
      });
    };
    $scope.loadEnvironment();
    $scope.loadExecutors = function () {
      return $http.get('/admin/environments/' + $scope.env_id + '/executors').success(function (executors) {
          for(var i = 0; i < executors.length; i++){
              if(executors[i].envMstId === 0){
                  executors[i].envMstId = '';
              }
          }
        $scope.executors = executors;
        $scope.savedExecutors = angular.copy(executors);
      });
    };
    $scope.loadExecutors();
    $scope.loadGivenExecutor = function (index, executorId) {
      return $http.get('/admin/executors/' + executorId).success(function (executor) {
        $scope.executors[index] = executor;
      });
    };
    $scope.orderAnObject = function (obj, order) {
      var tmp = {};
      for (var i = 0; i < order.length; i++) {
        tmp[order[i]] = obj[order[i]];
      }
      return tmp;
    };
    $scope.selected = null;
    $scope.selectedIndex = -1;
    $scope.select = function (index) {
      $scope.selectedIndex = index;
      $scope.selected = $scope.executors[index];
      $scope.errorList = [];
      $scope.validHostAndPort($scope.selected.host, $scope.selected.port, index);
      $scope.validEnvMstId($scope.selected.envMstId, index);
    };
    $scope.addExecutor = function () {
      $scope.executors.push({
        executorId: -1,
        envMstId: "",
        host: "",
        port: 0,
        backupDir: "",
        backupFlag: 0,
        osType: 1,
        typeConfig: {}
      });
    };
    $scope.checkChange = function() {
        if ($scope.selectedIndex < 0) {
            return false;
        }
        return angular.equals($scope.savedExecutors[$scope.selectedIndex], $scope.executors[$scope.selectedIndex]);
    };
    $scope.removeExecutor = function () {
      uiTools.showConfirmDlg({
        type: 'dialog-error',
        title: $scope._.template($scope.dict.pages.config.environments.one.delete_msg, { 'host': $scope.selected.host, 'port': $scope.selected.port }),
        content: $scope.dict.common.are_you_sure
      }).then(function () {
        if ($scope.selected.executorId === -1) {
          for (var i = 0; i < $scope.executors.length; i++) {
            if ($scope.executors[i] === $scope.selected) {
              $scope.executors.splice(i, 1);
              $scope.savedExecutors.splice(i, 1);
              $scope.selected = null;
              $scope.selectedIndex = -1;
              break;
            }
          }
        } else {
          $http({method: 'DELETE', url: '/admin/executors/' + $scope.selected.executorId}).success(function () {
            $scope.selected = null;
            $scope.selectedIndex = -1;
            $scope.savedExecutors.splice(i, 1);
            $scope.loadExecutors();
          });
        }
      });
    };
    $scope.createExecutor = function (executor) {
      $scope.validConfiguration(executor, function(){
          var index = $scope._.indexOf($scope.executors, $scope.selected);
          $http.post('/admin/environments/' + $scope.env_id + '/executors', $scope.selected).success(function (newExecutorId) {
              $scope.loadGivenExecutor(index, newExecutorId).success(function () {
                  $scope.selected = $scope.executors[index];
                  $scope.selectedIndex = index;
                  $scope.savedExecutors.push(angular.copy($scope.executors[index]));
                  uiTools.showGrowl($scope.dict.common.success, 'success', 3000);
              });
          }).error(function () {
              uiTools.showGrowl($scope.dict.pages.config.environments.one.save.fail, 'danger', 2000);
          });
      });
    };
    $scope.saveExecutor = function (executor) {
      if (!isDbWithBatch($scope.selected)) {
        uiTools.showGrowl($scope.dict.pages.config.environments.one.valid.db_batch, 'danger', 10000);
        return;
      }
      $scope.validConfiguration(executor, function(){
          var index = $scope._.indexOf($scope.executors, $scope.selected);
          $http.put('/admin/environments/' + $scope.env_id + '/executors', $scope.selected).success(function () {
              $scope.loadGivenExecutor(index, $scope.selected.executorId).success(function () {
                  $scope.selected = $scope.executors[index];
                  $scope.savedExecutors[$scope.selectedIndex] = angular.copy($scope.executors[index]);
                  uiTools.showGrowl($scope.dict.common.success, 'success', 3000);
              });
          }).error(function () {
              uiTools.showGrowl($scope.dict.pages.config.environments.one.save.fail, 'danger', 2000);
          });
      });
    };
    /**
     * operation inside an executor, operate servers
     * @param server
     */
    $scope.addServer = function (server) {
      $scope.selected.typeConfig[server] = $scope.selected.typeConfig[server] || buildEmptyServer(server);
      if (server.indexOf('DB') >= 0) {
        if (!$scope.selected.typeDbConfig) {
          $scope.selected['typeDbConfig'] = {};
        }
        $scope.selected.typeDbConfig[server] = $scope.selected.typeDbConfig[server] || buildEmptyDB(server);
      }
    };
    $scope.removeServer = function (server) {
      delete $scope.selected.typeConfig[server];
      delete $scope.selected.typeDbConfig[server];
    };

    $scope.back = function () {
      // check whether there has been some change
      $state.go('config.env.list');
    };
    /**
     * valid the configuration of the given executor
     */
    $scope.errorList = [];
    function isDbWithBatch(executor) {
      return !(executor.typeConfig['VER_DB'] && !executor.typeConfig['CPY_BATCH']);
    }
  /*
   *****************************************
   * Combine it with save
   *****************************************
   */
    $scope.validConfiguration = function (executor, callbackFn) {
      // front end check first
      if (!isDbWithBatch(executor)) {
        $scope.errorMsg.push($scope.dict.pages.config.environments.one.db_with_batch);
        uiTools.showGrowl($scope.dict.pages.config.environments.one.valid.db_batch, 'danger', 10000);
      } else {
        $scope.progressNow = 1;
        $scope.showProgress = true;
        $http.post('/admin/config/check', executor).success(function (data) {
          $scope.showProgress = false;
          $scope.errorList = data;
          var errorDetails = data;
          var errorContent = [];
          errorDetails.forEach(function(message) {
              var messageParts = message.split(":");
              if (messageParts.length > 1) {
                  console.log(messageParts);
                  // if it is error message of database schema
                  if (messageParts[1].trim().indexOf("S_") === 0 && messageParts[0].trim().match("._DB$")) {
                      errorContent.push($scope.serverTypeDict(messageParts[0].trim()) + ":" + $scope.dict.pages.config.environments.one.server.schemas[messageParts[1].trim()]);
                  } else if (messageParts[1].trim().indexOf("SVC_") === 0 && messageParts[0].trim().match("._AP$")) {
                      errorContent.push($scope.dict.pages.config.environments.one.basic[message]);
                  } else if(messageParts[0].trim() === "NETWORK"){
                      errorContent.push($scope.dict.pages.config.environments.one.network[messageParts[1].trim()]);
                  } else if ($scope.dict.pages.config.environments.one.basic[messageParts[0].trim()]) {
                      errorContent.push($scope.dict.pages.config.environments.one.basic[messageParts[0].trim()]);
                  } else if(messageParts[1].trim() === "SRLT_EXECUTER" || messageParts[1].trim() === "TDI_EXE"){
                      errorContent.push($scope.serverTypeDict(messageParts[0].trim()) + ":" + $scope.dict.pages.config.environments.one.server.HOME.titles[messageParts[1].trim()]);
                  } else if (messageParts[1].trim().match("HOME")) {
                      errorContent.push($scope.serverTypeDict(messageParts[0].trim()) + ":" + $scope.dict.pages.config.environments.one.server.HOME.titles[messageParts[0].trim()]);
                  } else if ($scope.dict.pages.config.environments.one.server[messageParts[1].trim()]) {
                      errorContent.push($scope.serverTypeDict(messageParts[0].trim()) + ":" + $scope.dict.pages.config.environments.one.server[messageParts[1].trim()].title);
                  } else {
                      errorContent.push(message);
                  }
              } else {
                  console.log("Special message", message);
                  errorContent.push($scope.dict.pages.config.environments.one.basic[message]);
              }
          });
          if (data.length > 0) {
            var uniqueErrors = [];
            $.each(errorContent, function(i, el){
                if($.inArray(el, uniqueErrors) === -1) { uniqueErrors.push(el); }
            });
            $scope.errorMsg =  uniqueErrors;
            console.log($scope.errorMsg);
            uiTools.showGrowl($scope.dict.pages.config.environments.one.valid.fail, 'danger', 2000);
          } else {
            $scope.errorMsg = [];
            //uiTools.showGrowl($scope.dict.pages.config.environments.one.valid.success, 'success', 2000);
            if(callbackFn){
                callbackFn();
            }else{
                uiTools.showGrowl($scope.dict.common.success, 'success', 3000);
            }
          }
        });
      }
    };
    var formScope;
    $scope.setFormScope = function (scope) {
      formScope = scope;
    };
    Array.prototype.remove = function() {
      var what, a = arguments, L = a.length, ax;
      while (L && this.length) {
          what = a[--L];
          while ((ax = this.indexOf(what)) !== -1) {
              this.splice(ax, 1);
          }
      }
      return this;
    };
      var emptyHostAndPortErrors = function(){
          $scope.errorMsg.remove($scope.dict.pages.config.environments.one.host_empty);
          $scope.errorMsg.remove($scope.dict.pages.config.environments.one.ip_port_taken);
          $scope.errorMsg.remove($scope.dict.pages.config.environments.one.port_range);
      };
    $scope.validHostAndPort = function (host, port) {
      var count = 0;
      var executors = $scope.savedExecutors;
      if (!host || host === "") {
          $scope.errorMsg.push($scope.dict.pages.config.environments.one.host_empty);
          return false;
      }
      if (port === parseInt(port, 10) && port >=0 && port <= 65535) {
            if ($scope.selectedIndex < executors.length && executors[$scope.selectedIndex].host === $scope.executors[$scope.selectedIndex].host && executors[$scope.selectedIndex].port === $scope.executors[$scope.selectedIndex].port) {
                emptyHostAndPortErrors();
                return true;
            }
            for (var i = 0; i < executors.length; i++) {
              if (i != $scope.selectedIndex && executors[i].host === host && executors[i].port === port) {
                if (formScope != null) {
                    formScope.executorForm.$setValidity('unique', false);
                }
                  $scope.errorMsg.push($scope.dict.pages.config.environments.one.ip_port_taken);
                return false;
              }
            }
            emptyHostAndPortErrors();
            if (formScope != null) {
                formScope.executorForm.$setValidity('unique', true);
            }
            return true;
      } else {
          $scope.errorMsg.push($scope.dict.pages.config.environments.one.port_range);
          return false;
      }
    };

    var emptyEnvMstIdErrors = function(){
        $scope.errorMsg.remove($scope.dict.pages.config.environments.one.env_mst_id_invalid);
    };
    $scope.validEnvMstId = function (envMstId) {
      if (parseInt(envMstId, 10) && envMstId >0) {
          emptyEnvMstIdErrors();
          return true;
      } else {
          var errMsg = $scope.dict.pages.config.environments.one.env_mst_id_invalid;
          if(!$scope.errorMsg.includes(errMsg)){
              $scope.errorMsg.push(errMsg);
          }
          return false;
      }
    };
    $scope.scrollTo_typeId = function ($event, x) {
      $event.preventDefault();
      var newHash = 'type_id_' + x;
      if ($location.hash() !== newHash) {
        // set the $location.hash to `newHash` and
        // $anchorScroll will automatically scroll to it
        $location.hash('type_id_' + x);
      } else {
        // call $anchorScroll() explicitly,
        // since $location.hash hasn't changed
        $anchorScroll();
      }
    };
    $scope.scrollTo_server = function ($event) {
      $event.preventDefault();
      var newHash = 'server-config-home';
      if ($location.hash() !== newHash) {
        // set the $location.hash to `newHash` and
        // $anchorScroll will automatically scroll to it
        $location.hash('server-config-home');
      } else {
        // call $anchorScroll() explicitly,
        // since $location.hash hasn't changed
        $anchorScroll();
      }
    };
    $('#sidebar').affix();
    $(document.body).scrollspy({
      target: '#leftCol',
      offset: $anchorScroll.yOffset + 1
    });
  }]);
angular.module('updater.update.postUpdateCollect.one', ['ui.router', 'ngGrid'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateCollect.one', {
      url: '/onePostUpdateCollect/:key',
      controller: 'onePostUpdateCollectCtrl',
      templateUrl: 'update/manualPart/oneCollect/one_collect.tpl.html',
      data: {}
    });
  }])
  .controller('onePostUpdateCollectCtrl', ["$scope", "$http", "$state", "$stateParams", "ws", function ($scope, $http, $state, $stateParams, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(4);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;
    var key = $stateParams.key;

    $scope.exportUrl = '/post_update/' + env.id + '/' + product.code + '/' + version.id + '/collect/' + key + '/';

    // load data
    $scope.task = {};
    $http.get('/post_update/' + env.id + '/' + product.code + '/' + version.id + '/collect/' + key).success(function (data) {
      var task = $scope.task = data;

      for (var i = 0; i < task.questions.length; i++) {
        if (task.questions[i].type === 'TYPE_INPUT') {
          task.questions[i].validation = new RegExp(task.questions[i].validation);
        }
        if (task.questions[i].type === 'TYPE_GRID') {
          var q = task.questions[i];

          var columnDefs = [];

          for (var j = 0; j < q.columns.length; j++) {
            var c = {
              field: q.columns[j].field,
              displayName: q.columns[j].caption,
              //enableCellEdit: q.columns[j]['input']
              enableCellEdit: false
            };
            if (q.columns[j]['input'] && q.columns[j].inputType === 'COMBO') {
              c.cellTemplate =
                '<select required ng-class="col.colIndex()" ' +
                'ng-model="COL_FIELD" ng-input="COL_FIELD"' +
                'ng-options="k as v for (k, v) in task.questions[' + i + '].columns[' + j + '].options" ></select>';
            }
            if (q.columns[j]['input'] && q.columns[j].inputType === 'INPUT') {
              q.columns[j].validation = new RegExp(q.columns[j].validation);
              c.cellTemplate = '<input ng-pattern="task.questions[' + i + '].columns[' + j + '].validation" ng-class="col.colIndex()" ng-model="COL_FIELD" ng-input="COL_FIELD"  data-ng-required="true"/>';
            }
            columnDefs.push(c);
          }

          q.gridOptions = {
            data: 'task.questions[' + i + '].rows',
            enableRowSelection: false,
            enableCellEdit: true,
            columnDefs: columnDefs
          };
        }
      }
    });

    // import and export
    $scope.importOneGrid = function ($index, $file) {
      $scope.upload = $upload.upload({
        url: $scope.exportUrl + $index,
        file: $file
      }).success(function (data) {
        if(data) {
          $scope.task.questions[$index].rows = data;
          uiTools.showConfirmDlg({
            type: 'dialog-primary',
            title: $scope.dict.pages.update.manual.collect.import.success_title,
            content: $scope.dict.pages.update.manual.collect.import.success_content
          });
        } else {
          uiTools.showConfirmDlg({
            type: 'dialog-error',
            title: $scope.dict.pages.update.manual.collect.import.fail_title,
            content: $scope.dict.pages.update.manual.collect.import.fail_content
          });
        }
      });
    };

    // button logic
    $scope.cancelBtnClick = function () {
      $state.go('update.postUpdateCollect.list');
    };

    $scope.saveBtnClick = function () {
      var answer = [];
      for (var i = 0; i < $scope.task.questions.length; i++) {
        if ($scope.task.questions[i].type === 'TYPE_INPUT') {
          answer[i] = $scope.task.questions[i].value;
        }
        if ($scope.task.questions[i].type === 'TYPE_COMBO') {
          answer[i] = $scope.task.questions[i].value;
        }
        if ($scope.task.questions[i].type === 'TYPE_GRID') {
          answer[i] = $scope.task.questions[i].rows;
        }
      }
      $http.post('/post_update/' + env.id + '/' + product.code + '/' + version.id + '/collect/' + key, answer).success(function (data) {
        if (data) {
          $scope.cancelBtnClick();
        }
      });
    };
  }]);
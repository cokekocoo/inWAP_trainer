angular.module('dictSpan', [])
  .directive('dictSpan', ["$window", function ($window) {

    var link = function(scope) {
      scope._ = $window._;

    };

    return {
      restrict: 'E',
      replace: false,
      link: link,
      scope: {
        template: '@',
        templateData: '='
      },
      templateUrl: 'dictSpan/dictSpan.tpl.html'
    };
  }]);
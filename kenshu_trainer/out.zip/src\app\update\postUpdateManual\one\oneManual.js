angular.module('updater.update.postUpdateManual.one', ['ui.router', 'ngSanitize'])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateManual.one', {
      url: '/one_manual/:key',
      controller: 'onePostUpdateManualCtrl',
      templateUrl: 'update/manualPart/oneManual/one_manual.tpl.html',
      data: {}
    });
  }])
  .controller('onePostUpdateManualCtrl', ["$scope", "$http", "$state", "$stateParams", "ws", function ($scope, $http, $state, $stateParams, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(4);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;
    var key = $stateParams.key;

    // load data
    var loadTask = function () {
      $http.get('/post_update/' + env.id + '/' + product.code + '/' + version.id + '/manual/' + key).success(function (data) {
        $scope.task = data;
      });
    };
    loadTask();

    // button logic
    $scope.cancelBtnClick = function () {
      $state.go('update.postUpdateManual.list');
    };

    $scope.testBtnClick = function () {
      $http.post('/post_update/' + env.id + '/' + product.code + '/' + version.id + '/manual/' + key, {}).success(function () {
        loadTask();
      });
    };
  }]);
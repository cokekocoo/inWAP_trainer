
angular.module('updater.update.postUpdateCollect', [
  'updater.update.postUpdateCollect.list',
  'updater.update.postUpdateCollect.one',
  'ui.router',
  'loading'
])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateCollect', {
      url: '/postUpdateCollect',
      controller: 'postUpdateCollectCtrl',
      templateUrl: 'update/postUpdateCollect/postUpdateCollect.tpl.html',
      data: {}
    });
  }])
  .controller('postUpdateCollectCtrl', ["$scope", "$http", "$state", "ws", function ($scope, $http, $state, ws) {
    $state.go('update.postUpdateCollect.list');
  }]);
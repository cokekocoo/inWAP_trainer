angular.module('updater.update.postUpdateManual.list', [
  'ui.router',
  'loading'
])
  .config(["$stateProvider", function ($stateProvider) {
    $stateProvider.state('update.postUpdateManual.list', {
      url: '/postUpdateManualList',
      controller: 'postUpdateManualListCtrl',
      templateUrl: 'update/postUpdateManual/list/listManual.tpl.html',
      data: {}
    });
  }])
  .controller('postUpdateManualListCtrl', ["$scope", "$http", "$state", "ws", function ($scope, $http, $state, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(4);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;

    // load data
    $http.get('/post_update_manual/' + env.id + '/' + product.code + '/' + version.id).success(function (data) {
      $scope.tasks = data;
      if (data.manual.length === 0) {
        $scope.nextBtnClick();
      }
    });

    // task select logic
    $scope.oneTaskClick = function (type, task) {
      $state.go('update.postUpdateManual.one', {key: task.taskKey});
    };

    // next logic
    $scope.canNext = function () {
      return true;
    };

    $scope.nextBtnClick = function () {
      $http.post('/next/success/ct.post-update-manual.wait', {}).success(function () {
        $state.go('update.progress');
      });
    };

    $scope.progressRptBtnClick = function () {
      $state.go('update.report', {status: 'postUpdateManual'});
    };
  }]);
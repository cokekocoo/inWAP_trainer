angular.module('updater.update.manual.oneFast', ['ui.router'])
  .config(["$stateProvider", function($stateProvider) {
    $stateProvider.state('update.manual.oneFast', {
      url: '/one_fast/:key',
      controller: 'oneFastCtrl',
      templateUrl: 'update/manualPart/oneFast/one_fast.tpl.html',
      data: {}
    });
  }])
  .controller('oneFastCtrl', ["$scope", "$http", "$state", "$stateParams", "ws", function ($scope, $http, $state, $stateParams, ws) {

    if (!$scope.checkEnv()) {
      return;
    }

    ws.reset();
    $scope.setCurrentStep(3);

    var env = $scope.env = $scope.updateData.env;
    var product = $scope.updateData.product;
    var version = $scope.updateData.version;
    var key = $stateParams.key;

    // load data
    $http.get('/manual_part/' + env.id + '/' + product.code + '/' + version.id + '/fast/' + key).success(function (data) {
      $scope.task = data;
      for (var i in $scope.task.fastReleaseFiles) {
        if($scope.task.fastReleaseFiles[i].operation === 0) {
          $scope.task.fastReleaseFiles[i].operation = null;
        }
      }
    });

    // button logic
    $scope.cancelBtnClick = function () {
      $state.go('update.manual.list');
    };

    $scope.saveBtnClick = function () {
      $http.post('/manual_part/' + env.id + '/' + product.code + '/' + version.id + '/fast/' + key,
        $scope.task.fastReleaseFiles).success(function (data) {
          if (data) {
            $scope.cancelBtnClick();
          }
        });
    };

  }]);